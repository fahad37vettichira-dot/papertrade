"use client";

import Link from "next/link";
import { Icon } from "@/components/icons";
import { useSim } from "@/components/providers";
import { PageHeader, PageLoading, Empty, PanelHeader, Pill } from "@/components/ui";
import { PortfolioChart } from "@/components/portfolio-chart";
import { HoldingsTable } from "@/components/holdings-table";
import { TimeTravelCard } from "@/components/time-travel";
import { SymbolBadge, NewsCard } from "@/components/widgets";
import { Sparkline } from "@/components/charts";
import { fmtMoney, fmtSignedPct, toneClass } from "@/lib/format";

export default function Overview() {
  const { snapshot, loading, openCash } = useSim();
  if (loading && !snapshot) return <PageLoading/>;
  if (!snapshot) return <Empty title="Let’s reconnect." hint="Use Try again above to load your practice account."/>;
  const watched = snapshot.tickers.filter(t => t.watched).slice(0, 4);
  const cashParts = fmtMoney(snapshot.account.cash).split(".");
  return <><PageHeader title="Your portfolio, at a glance." subtitle="A little practice today. A little more confidence tomorrow." actions={<Link href="/markets" className="btn !bg-white"><Icon name="search" size={14}/> Explore stocks <Icon name="chevronRight" size={13}/></Link>}/>
    <div className="page-stack"><div className="overview-grid"><PortfolioChart/><div className="overview-aside flex flex-col gap-[22px]"><section className="panel cash-card p-[22px]"><div className="flex items-center justify-between"><span className="text-[11px] text-[#8a9a78]">Cash to invest</span><Icon name="wallet" size={17} className="text-[#93a37a]"/></div><p className="tnum mt-4 text-[29px] font-medium tracking-[-.05em] text-[#4f6840]">{cashParts[0]}<span className="text-[#a8b694]">.{cashParts[1]}</span></p><p className="mt-2 text-[10px] text-[#93a17f]">Virtual cash, ready for your next move.</p><button className="section-link mt-5 !text-[11px]" onClick={() => openCash("deposit")}>Add a little more <Icon name="plus" size={12}/></button></section><TimeTravelCard/></div></div>
    <div className="learning-strip"><span className="hidden h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#e4ebda] text-[#8aa16c] sm:flex"><Icon name="bolt" size={18}/></span><div className="flex-1"><p className="text-[12px] font-medium">All the experience. None of the risk.</p><p className="mt-1 text-[10px] text-[#8d9983]">Your example account starts with $100,000 and a few sample stocks. Everything here is virtual.</p></div><Link href="/markets" className="section-link !text-[11px]">Make your next move <Icon name="arrowUpRight" size={13}/></Link></div>
    <div className="overview-lower"><HoldingsTable preview/><section className="panel overflow-hidden"><PanelHeader title="On your radar" action={<Link href="/markets?view=watchlist" className="section-link">View all <Icon name="chevronRight" size={12}/></Link>}/>{watched.length ? watched.map(t => <Link key={t.symbol} href={`/markets/${t.symbol}`} className="ticker-row"><SymbolBadge symbol={t.symbol} size={31}/><div className="min-w-0 flex-1"><p className="stock-name">{t.symbol}</p><p className="stock-ticker truncate">{t.name.replace(" Inc.", "").replace(" Corp.", "")}</p></div><Sparkline values={t.spark} width={43} height={24}/><div className="text-right"><p className="tnum text-[11px] font-medium">{fmtMoney(t.price)}</p><p className={`tnum mt-1 text-[9px] ${toneClass(t.changePct)}`}>{fmtSignedPct(t.changePct)}</p></div></Link>) : <Empty title="Keep an eye on a favorite." hint="Tap the star next to a stock to add it to your watchlist."/>}</section></div>
    <section className="panel"><PanelHeader title="A little market context" subtitle="Fictional news. Real lessons about how markets move." action={<Link href="/news" className="section-link">More stories <Icon name="chevronRight" size={12}/></Link>}/><div className="grid gap-6 px-6 pb-6 md:grid-cols-2">{snapshot.news.slice(0, 2).map(n => <NewsCard key={n.id} item={n} epoch={snapshot.market.epoch} compact/>)}{!snapshot.news.length && <p className="hint">New stories arrive as you move the simulated clock forward.</p>}</div><div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--line)] px-6 py-4"><p className="flex items-center gap-2 text-[11px] text-[#8b9784]"><Icon name="brain" size={14}/> Model outlook <Pill tone={snapshot.outlook.score > 15 ? "up" : snapshot.outlook.score < -15 ? "warn" : "neutral"}>{snapshot.outlook.label}</Pill><span className="hidden text-[10px] text-[#a8b09f] sm:inline">A perspective, not a prediction.</span></p><Link href="/simulations" className="section-link !text-[11px]">What could the future look like? <Icon name="arrowUpRight" size={12}/></Link></div></section>
    </div></>;
}
