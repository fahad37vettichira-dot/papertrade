"use client";

import { useState } from "react";
import { useSim } from "@/components/providers";
import { Icon } from "@/components/icons";
import { Empty, PageHeader, PageLoading, Segmented } from "@/components/ui";
import { NewsCard } from "@/components/widgets";

export default function NewsPage() {
  const { snapshot, loading, advance, busy } = useSim();
  const [filter, setFilter] = useState<"all" | "held" | "watch">("all");
  const [visible, setVisible] = useState(8);
  if (loading && !snapshot) return <PageLoading/>;
  if (!snapshot) return <Empty title="The newsroom is taking a moment." hint="Use Try again above to reconnect."/>;
  const headlines = snapshot.news.filter(n => filter === "all" || (n.symbol && (filter === "held" ? snapshot.holdings.some(h => h.symbol === n.symbol) : snapshot.watchlist.includes(n.symbol))));
  return <><PageHeader title="A little context for your next move." subtitle="See how news can move a market. Every story here is fictional and part of your practice world."/><div className="page-stack"><div className="learning-strip !border-[#efe7d2] !bg-[#fbf8ed]"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#f2ebd7] text-[#b6a16d]"><Icon name="bolt" size={19}/></span><div className="flex-1"><h2 className="text-xs font-medium">Markets don’t always go to plan.</h2><p className="hint mt-1">Surprise events happen as time moves. You can also try one now—it advances one trading day and changes prices.</p></div><button type="button" disabled={busy} className="btn !border-[#e7dcc0] !bg-[#fffdf7] !text-[#9a8551]" onClick={() => void advance(1, true)}>Try a surprise <Icon name="arrowUpRight" size={13}/></button></div>
    <div className="flex flex-wrap items-center justify-between gap-3"><Segmented options={[{ value: "all", label: "All stories" }, { value: "held", label: "My investments" }, { value: "watch", label: "My watchlist" }]} value={filter} onChange={v => { setFilter(v); setVisible(8); }}/><span className="text-[10px] text-[var(--muted)]">{headlines.length} recent stories</span></div>
    <div className="grid gap-5 md:grid-cols-2">{headlines.slice(0, visible).map(n => <NewsCard key={n.id} item={n} epoch={snapshot.market.epoch}/>)}</div>{!headlines.length && <div className="panel"><Empty title="A quiet moment in the market." hint="Try another filter, or skip ahead to see new fictional stories." icon={<Icon name="news" size={20}/>}/></div>}{visible < headlines.length && <div className="text-center"><button className="btn" onClick={() => setVisible(v => v + 8)}>Read a few more stories <Icon name="chevronDown" size={13}/></button></div>}<p className="hint text-center !text-[10px]">Headlines are simulation templates, not reports of actual events. They aren’t investment recommendations.</p></div></>;
}
