import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SimProvider } from "@/components/providers";
import { AppShell } from "@/components/shell";

export const metadata: Metadata = {
  title: "Paper Trade — Virtual Stock Market Simulator",
  description:
    "Trade stocks with virtual money, fast-forward up to five years of market history, run Monte Carlo projections and compare transparent model-based signals. No real money involved.",
  applicationName: "Paper Trade",
};

export const viewport: Viewport = {
  themeColor: "#f6f8f7",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <SimProvider>
          <AppShell>{children}</AppShell>
        </SimProvider>
      </body>
    </html>
  );
}
