import { buildSnapshot } from "@/lib/server/market";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const snapshot = await buildSnapshot();
    return Response.json(snapshot, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to load state";
    return Response.json({ error: message }, { status: 500 });
  }
}
