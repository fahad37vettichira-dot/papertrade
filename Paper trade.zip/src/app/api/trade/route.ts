import { buildSnapshot, executeTrade } from "@/lib/server/market";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      symbol?: string;
      side?: string;
      qty?: number;
      orderType?: string;
      limitPrice?: number;
    };
    if (!body.symbol) throw new Error("Choose a symbol to trade.");
    if (body.side !== "buy" && body.side !== "sell") throw new Error("Side must be buy or sell.");
    const orderType = body.orderType === "limit" ? "limit" : body.orderType === "stop" ? "stop" : "market";
    const result = await executeTrade({
      symbol: body.symbol,
      side: body.side,
      qty: Number(body.qty ?? 0),
      orderType,
      limitPrice: body.limitPrice !== undefined ? Number(body.limitPrice) : undefined,
    });
    const snapshot = await buildSnapshot();
    return Response.json({ message: result.message, snapshot }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Order rejected";
    return Response.json({ error: message }, { status: 400 });
  }
}
