import { getSymbolDetail } from "@/lib/server/market";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ symbol: string }> }) {
  try {
    const { symbol } = await params;
    const detail = await getSymbolDetail(symbol);
    if (!detail) return Response.json({ error: "Symbol not found" }, { status: 404 });
    return Response.json(detail, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to load symbol";
    return Response.json({ error: message }, { status: 500 });
  }
}
