import { adjustCash, buildSnapshot } from "@/lib/server/market";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      action?: string;
      amount?: number;
      settleTax?: boolean;
    };
    if (body.action !== "deposit" && body.action !== "withdraw") throw new Error("Unknown cash action.");
    const result = await adjustCash({
      action: body.action,
      amount: Number(body.amount ?? 0),
      settleTax: Boolean(body.settleTax),
    });
    const snapshot = await buildSnapshot();
    return Response.json({ message: result.message, snapshot }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Cash action failed";
    return Response.json({ error: message }, { status: 400 });
  }
}
