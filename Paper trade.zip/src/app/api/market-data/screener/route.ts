import { UNIVERSE } from "@/lib/universe";
import { getRealMarketSummary } from "@/lib/realMarket";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  try {
    const rows: Array<Awaited<ReturnType<typeof getRealMarketSummary>> & { sector: string }> = [];
    const unavailable: string[] = [];
    let cursor = 0;

    const workers = Array.from({ length: 4 }, async () => {
      while (cursor < UNIVERSE.length) {
        const index = cursor++;
        const ticker = UNIVERSE[index];
        try {
          const analysis = await getRealMarketSummary(ticker.symbol);
          rows.push({
            ...analysis,
            sector: ticker.sector,
          });
        } catch (error) {
          console.warn(`Real market screener skipped ${ticker.symbol}:`, error);
          unavailable.push(ticker.symbol);
        }
      }
    });
    await Promise.all(workers);

    rows.sort((a, b) => b.score - a.score);
    if (!rows.length) {
      return Response.json({ error: "The real historical feed did not return data for any supported symbol. No simulated prices were used in this scan." }, { status: 503 });
    }
    return Response.json({
      rows,
      unavailable,
      source: "Yahoo Finance historical chart",
      sourceType: "Unofficial daily feed; may be delayed.",
      latestDate: rows.map(row => row.latestDate).sort().at(-1),
      disclaimer: "Signals are model output from historical prices, not financial advice or a promise of future returns.",
    }, { headers: { "cache-control": "private, max-age=300, stale-while-revalidate=900" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Market scan could not be completed.";
    console.error("Actual-data stock screener failed:", error);
    return Response.json({ error: message }, { status: 503, headers: { "cache-control": "no-store" } });
  }
}
