import { getRealMarketAnalysis } from "@/lib/realMarket";
import { captureAndEvaluateForecasts } from "@/lib/modelHistory";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET(_request: Request, { params }: { params: Promise<{ symbol: string }> }) {
  try {
    const { symbol } = await params;
    const analysis = await getRealMarketAnalysis(symbol);
    const predictionHistory = await captureAndEvaluateForecasts(analysis);
    return Response.json({ ...analysis, predictionHistory }, {
      headers: {
        "cache-control": "private, max-age=600, stale-while-revalidate=1800",
        "x-data-source": "Yahoo Finance historical chart; daily data; unofficial feed",
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Historical stock data is unavailable.";
    const status = message.includes("supported practice-stock") ? 404 : message.includes("ticker") ? 404 : 503;
    console.error("Historical market-data request failed:", error);
    return Response.json({ error: message }, { status, headers: { "cache-control": "no-store" } });
  }
}
