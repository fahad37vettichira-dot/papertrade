import { getStockActualProjection } from "@/lib/realMarket";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function POST(request: Request, { params }: { params: Promise<{ symbol: string }> }) {
  try {
    const { symbol } = await params;
    const body = await request.json() as { startValue?: unknown; horizonDays?: unknown; monthlyContribution?: unknown };
    const startValue = Number(body.startValue);
    const horizonDays = Number(body.horizonDays);
    const monthlyContribution = Number(body.monthlyContribution ?? 0);
    if (!Number.isFinite(startValue) || startValue <= 0 || startValue > 5_000_000) {
      return Response.json({ error: "Choose a starting amount from $0.01 to $5,000,000." }, { status: 400 });
    }
    if (![63, 252, 756, 1260].includes(horizonDays)) {
      return Response.json({ error: "Choose a 3-month, 1-year, 3-year, or 5-year forecast." }, { status: 400 });
    }
    if (!Number.isFinite(monthlyContribution) || monthlyContribution < 0 || monthlyContribution > 100_000) {
      return Response.json({ error: "Monthly additions must be between $0 and $100,000." }, { status: 400 });
    }
    const forecast = await getStockActualProjection(symbol, startValue, horizonDays, monthlyContribution);
    return Response.json(forecast, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Actual-history projection is unavailable.";
    console.error("Single-stock projection failed:", error);
    return Response.json({ error: message }, { status: 503, headers: { "cache-control": "no-store" } });
  }
}
