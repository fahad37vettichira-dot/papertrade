import { getRealHistory } from "@/lib/realMarket";
import { backtestStrategy, BACKTEST_STRATEGIES, type BacktestStrategyId } from "@/lib/backtest";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function POST(request: Request, { params }: { params: Promise<{ symbol: string }> }) {
  try {
    const { symbol } = await params;
    const body = await request.json() as { strategy?: unknown; lookback?: unknown; budget?: unknown; feeBps?: unknown };
    const strategy = String(body.strategy ?? "rsi") as BacktestStrategyId;
    if (!BACKTEST_STRATEGIES.some(s => s.id === strategy)) {
      return Response.json({ error: "Choose a supported backtest strategy." }, { status: 400 });
    }
    const lookback = Number(body.lookback ?? 252);
    const budget = Number(body.budget ?? 10_000);
    const feeBps = Number(body.feeBps ?? 10);
    if (![63, 252, 504, 756, 1260].includes(lookback)) {
      return Response.json({ error: "Choose a 3-month, 1-year, 2-year, 3-year, or 5-year backtest." }, { status: 400 });
    }
    if (!Number.isFinite(budget) || budget <= 0 || budget > 5_000_000) {
      return Response.json({ error: "Choose a budget from $0.01 to $5,000,000." }, { status: 400 });
    }
    if (!Number.isFinite(feeBps) || feeBps < 0 || feeBps > 100) {
      return Response.json({ error: "Choose a fee from 0 to 100 basis points." }, { status: 400 });
    }
    const { history } = await getRealHistory(symbol);
    const result = backtestStrategy({ symbol, history, strategy, lookback, budget, feeBps });
    return Response.json(result, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Backtest could not be completed.";
    console.error("Strategy backtest failed:", error);
    return Response.json({ error: message }, { status: 503, headers: { "cache-control": "no-store" } });
  }
}
