import { buildSnapshot, cancelOrder } from "@/lib/server/market";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { id?: number };
    if (!body.id) throw new Error("Order id required");
    await cancelOrder(Number(body.id));
    const snapshot = await buildSnapshot();
    return Response.json({ message: "Order cancelled", snapshot }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to cancel order";
    return Response.json({ error: message }, { status: 400 });
  }
}
