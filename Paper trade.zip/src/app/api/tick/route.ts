import { advanceMarket, buildSnapshot } from "@/lib/server/market";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request: Request) {
  try {
    const body = await request.json() as { days?: unknown; triggerEvent?: boolean };
    const value = Number(body.days ?? 1);
    if (!Number.isFinite(value) || value < 1 || value > 1260) return Response.json({ error: "Choose between 1 trading day and 5 years." }, { status: 400 });
    const days = Math.round(value);
    await advanceMarket(days, body.triggerEvent === true);
    const snapshot = await buildSnapshot();
    return Response.json({ snapshot, advanced: days }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    console.error("Simulation advance failed", error);
    return Response.json({ error: "We couldn’t advance the simulation. Your account is safe; please try again." }, { status: 500 });
  }
}
