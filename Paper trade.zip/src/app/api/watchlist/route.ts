import { buildSnapshot, toggleWatch } from "@/lib/server/market";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { symbol?: string };
    if (!body.symbol) throw new Error("Symbol required");
    const result = await toggleWatch(body.symbol);
    const snapshot = await buildSnapshot();
    return Response.json({ ...result, snapshot }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Watchlist update failed";
    return Response.json({ error: message }, { status: 400 });
  }
}
