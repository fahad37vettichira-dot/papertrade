import { desc } from "drizzle-orm";
import { db } from "@/db";
import { transactions, markets } from "@/db/schema";
import { ensureSeed } from "@/lib/server/market";
import { dayToISO } from "@/lib/time";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeed();
    const [market] = await db.select().from(markets).limit(1);
    const rows = await db.select().from(transactions).orderBy(desc(transactions.id));
    const quote = (value: unknown) => `"${String(value ?? "").replace(/"/g, '""')}"`;
    const lines = [["Date", "Type", "Symbol", "Shares", "Price", "Cash flow", "Realized profit/loss", "Note"].map(quote).join(","), ...rows.map(t => [dayToISO(t.day, market.epoch), t.kind, t.symbol, t.shares || "", t.price || "", t.amount.toFixed(2), t.realized.toFixed(2), t.note].map(quote).join(","))];
    return new Response(lines.join("\r\n"), { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": 'attachment; filename="paper-trade-activity.csv"', "cache-control": "no-store" } });
  } catch (error) {
    console.error("Activity export failed", error);
    return Response.json({ error: "Couldn’t export your activity. Please try again." }, { status: 500 });
  }
}
