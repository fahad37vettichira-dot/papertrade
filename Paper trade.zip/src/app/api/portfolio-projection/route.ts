import { getPortfolioActualReturns, makePortfolioProjection } from "@/lib/realMarket";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function POST(request: Request) {
  try {
    const body = await request.json() as {
      startValue?: unknown;
      horizonDays?: unknown;
      positions?: unknown;
      monthlyContribution?: unknown;
    };
    const startValue = Number(body.startValue);
    const horizonDays = Number(body.horizonDays);
    if (!Number.isFinite(startValue) || startValue <= 0 || startValue > 100_000_000) {
      return Response.json({ error: "Choose a valid current portfolio value." }, { status: 400 });
    }
    if (![252, 756, 1260].includes(horizonDays)) {
      return Response.json({ error: "Choose a one, three, or five-year portfolio projection." }, { status: 400 });
    }
    const monthlyContribution = Number(body.monthlyContribution ?? 0);
    if (!Number.isFinite(monthlyContribution) || monthlyContribution < 0 || monthlyContribution > 100_000) {
      return Response.json({ error: "Monthly additions must be between $0 and $100,000." }, { status: 400 });
    }
    if (!Array.isArray(body.positions) || body.positions.length > 26) {
      return Response.json({ error: "Portfolio positions are invalid." }, { status: 400 });
    }
    const positions = body.positions.map((item) => {
      if (!item || typeof item !== "object") throw new Error("A portfolio position is invalid.");
      const row = item as { symbol?: unknown; weight?: unknown };
      return { symbol: String(row.symbol ?? "").toUpperCase(), weight: Number(row.weight) };
    });

    const actual = await getPortfolioActualReturns(positions);
    const seed = positions.reduce((n, p) => n + p.symbol.split("").reduce((x, c) => x * 31 + c.charCodeAt(0), 1), Math.round(startValue * 100)) + horizonDays;
    const projection = makePortfolioProjection({
      returns: actual.returns,
      startValue,
      horizonDays,
      monthlyContribution,
      seed,
    });
    return Response.json({
      ...projection,
      startValue,
      horizonDays,
      latestHistoryDate: actual.latestDate,
      dataSymbols: actual.dataSymbols,
      investedWeight: actual.investedWeight,
      cashWeight: Math.max(0, 1 - actual.investedWeight),
      source: "Yahoo Finance historical chart",
      sourceType: "Unofficial daily historical feed; may be delayed.",
      method: "2,000 Monte Carlo paths generated from your current paper-portfolio weights and overlapping historical daily stock returns. Cash is assumed to earn 0%; requested monthly contributions are invested in the same stock weights.",
    }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Portfolio projection is unavailable.";
    console.error("Portfolio projection failed:", error);
    return Response.json({ error: message }, { status: 503, headers: { "cache-control": "no-store" } });
  }
}
