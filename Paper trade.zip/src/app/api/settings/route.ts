import { buildSnapshot, resetAccount, updateSettings } from "@/lib/server/market";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      taxEnabled?: boolean;
      taxRate?: number;
      longTermTaxRate?: number;
      speed?: number;
    };
    await updateSettings({
      taxEnabled: typeof body.taxEnabled === "boolean" ? body.taxEnabled : undefined,
      taxRate: typeof body.taxRate === "number" ? body.taxRate : undefined,
      longTermTaxRate: typeof body.longTermTaxRate === "number" ? body.longTermTaxRate : undefined,
      speed: typeof body.speed === "number" ? body.speed : undefined,
    });
    const snapshot = await buildSnapshot();
    return Response.json({ snapshot }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Settings update failed";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function DELETE() {
  try {
    await resetAccount();
    const snapshot = await buildSnapshot();
    return Response.json({ message: "Simulation reset", snapshot }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Reset failed";
    return Response.json({ error: message }, { status: 500 });
  }
}
