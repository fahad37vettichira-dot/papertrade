"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { Icon } from "@/components/icons";
import { useSim } from "@/components/providers";
import { Empty, InfoRow, PanelHeader, Segmented, Skeleton } from "@/components/ui";
import { AiSignalCard, NewsCard, SymbolBadge, TradeTicket } from "@/components/widgets";
import { CandlestickChart, LineChart } from "@/components/charts";
import { MarketResearch } from "@/components/market-research";
import type { SymbolDetail } from "@/lib/api-types";
import { fmtCompactNum, fmtMoney, fmtPct, fmtShares, fmtSignedPct, toneClass } from "@/lib/format";
import { fmtDayShort } from "@/lib/time";

export default function StockPage() {
  const params = useParams<{ symbol: string }>();
  const symbol = params.symbol.toUpperCase();
  const { snapshot, watch, busy, openQuickTrade } = useSim();
  const [detail, setDetail] = useState<SymbolDetail | null>(null);
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);
  const [range, setRange] = useState(63);
  const [mode, setMode] = useState<"line" | "candles">("line");
  const day = snapshot?.market.day;
  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/market/${encodeURIComponent(symbol)}`, { signal: controller.signal, cache: "no-store" }).then(async r => { const d = await r.json(); if (!r.ok) throw new Error(d.error || "This stock isn’t available."); return d as SymbolDetail; }).then(d => { setDetail(d); setError(""); }).catch(e => { if (e.name !== "AbortError") setError(e.message); });
    return () => controller.abort();
  }, [symbol, day, retry]);
  const chart = useMemo(() => {
    if (!detail) return [];
    const bars = range ? detail.history.filter(p => p.day >= detail.market.day - range) : detail.history;
    const step = Math.max(1, Math.ceil(bars.length / (mode === "candles" ? 95 : 240)));
    return bars.filter((_, i) => i % step === 0 || i === bars.length - 1);
  }, [detail, range, mode]);
  if (error && !detail) return <div className="panel p-6"><Empty title={error}/><div className="mb-4 flex justify-center gap-3"><button className="btn" onClick={() => setRetry(v => v + 1)}>Try again</button><Link className="btn btn-primary" href="/markets">Explore stocks</Link></div></div>;
  if (!detail || detail.ticker.symbol !== symbol) return <div className="page-stack"><Skeleton className="h-24"/><div className="stock-detail-grid"><Skeleton className="h-96"/><Skeleton className="h-96"/></div></div>;
  const ticker = snapshot?.tickers.find(t => t.symbol === symbol) || detail.ticker;
  const position = snapshot?.holdings.find(h => h.symbol === symbol);
  const labels = chart.map(b => fmtDayShort(b.day, detail.market.epoch));
  return <><Link href="/markets" className="section-link mb-6"><Icon name="chevronRight" size={12} className="rotate-180"/> Back to stocks</Link><div className="mb-7 flex flex-wrap items-start justify-between gap-5"><div className="flex items-center gap-4"><SymbolBadge symbol={symbol} size={48}/><div><h1 className="text-[26px] font-medium tracking-[-.04em]">{ticker.name}</h1><p className="mt-1 text-[11px] text-[var(--muted)]">{symbol} · {ticker.sector} · Practice price only</p></div></div><div className="flex flex-wrap gap-2"><button className="btn btn-primary mobile-stock-action" onClick={() => openQuickTrade(symbol, "buy")}><Icon name="markets" size={14}/> Buy / sell</button><button className="btn" disabled={busy} aria-pressed={ticker.watched} onClick={() => void watch(symbol)}><Icon name="star" filled={ticker.watched} size={14} className={ticker.watched ? "text-[#bca269]" : ""}/>{ticker.watched ? "On your watchlist" : "Add to watchlist"}</button></div></div>
    <div className="stock-detail-grid"><div className="page-stack"><section className="panel"><div className="flex flex-wrap items-start justify-between gap-4 px-6 pt-6"><div><p className="card-label">Simulated practice price (not a real quote)</p><p className="tnum mt-2 text-[37px] font-medium tracking-[-.05em]">{fmtMoney(ticker.price)}</p><p className={`tnum mt-2 text-xs ${toneClass(ticker.changePct)}`}>{fmtSignedPct(ticker.changePct)} <span className="text-[10px] text-[var(--muted)]">in the latest simulated day</span></p></div><Segmented options={[{ value: 21, label: "1M" }, { value: 63, label: "3M" }, { value: 252, label: "1Y" }, { value: 0, label: "All" }]} value={range} onChange={setRange}/></div><div className="px-6 pt-7 pb-6">{mode === "line" ? <LineChart series={[{ name: symbol, values: chart.map(b => b.close), color: "#739a58", fill: true }]} labels={labels} height={230} formatValue={v => fmtMoney(v, 0)} formatTooltip={fmtMoney}/> : <CandlestickChart bars={chart} labels={labels} height={230}/>}</div><details className="border-t border-[var(--line)] px-6 py-4"><summary className="cursor-pointer text-[11px] text-[var(--muted)]">More chart options</summary><div className="mt-4 flex flex-wrap items-center justify-between gap-3"><span className="hint">Candles show each day’s open, high, low and close.</span><Segmented value={mode} onChange={setMode} options={[{ value: "line", label: "Simple line" }, { value: "candles", label: "Candlesticks" }]}/></div></details>{error && <p className="hint px-6 pb-4 down">Couldn’t refresh the latest chart. Showing the last saved view.</p>}</section>
    <MarketResearch symbol={symbol}/>
    <section className="panel p-6"><h2 className="panel-title">A little about {ticker.name.replace(" Inc.", "").replace(" Corp.", "")}</h2><p className="hint mt-3">{detail.ticker.description}</p><div className="mt-5 grid gap-x-8 sm:grid-cols-2"><InfoRow label="Sector" value={ticker.sector}/><InfoRow label="Dividend yield" value={fmtPct(ticker.dividendYield, 2)}/><InfoRow label="Lowest price in last year" value={fmtMoney(detail.indicators.low52)}/><InfoRow label="Highest price in last year" value={fmtMoney(detail.indicators.high52)}/></div>{position && <div className="note mt-5">You own <strong className="font-medium">{fmtShares(position.shares)} shares</strong> worth {fmtMoney(position.value)}, bought at an average of {fmtMoney(position.avgCost)} each.</div>}</section>
    <details className="details"><summary>Technical details, if you’re curious</summary><div className="details-body"><InfoRow label="Average price over 20 trading days" value={detail.indicators.sma20 ? fmtMoney(detail.indicators.sma20) : "Not enough history"}/><InfoRow label="Average price over 50 trading days" value={detail.indicators.sma50 ? fmtMoney(detail.indicators.sma50) : "Not enough history"}/><InfoRow label="RSI (recent buying vs. selling pressure)" value={detail.indicators.rsi14?.toFixed(1) || "—"}/><InfoRow label="Annual price volatility" value={fmtPct(detail.indicators.vol, 1)}/><InfoRow label="Shares traded in the latest day" value={fmtCompactNum(ticker.volume)}/><p className="hint mt-3">These are optional learning tools. You don’t need them to make a practice investment.</p></div></details>
    <section className="panel"><PanelHeader title="Stories about this company" subtitle="Fictional headlines used by the simulation."/><div className="grid gap-5 px-6 pb-6">{detail.news.slice(0, 2).map(n => <NewsCard key={n.id} item={n} epoch={detail.market.epoch} compact/>)}{!detail.news.length && <p className="hint">No company stories yet. New events may arrive as you skip forward.</p>}</div></section></div>
    <div className="page-stack"><section className="panel p-6 desktop-trade-ticket"><TradeTicket key={symbol} symbol={symbol} name={ticker.name} price={ticker.price} shares={position?.shares || 0} cash={snapshot?.account.cash || detail.cash}/></section><AiSignalCard signal={detail.signal} symbol={symbol}/><Link href={`/simulations?symbol=${symbol}`} className="learning-strip !gap-3"><Icon name="flask" size={18} className="shrink-0 text-[#8aa16c]"/><span className="flex-1 text-xs">What might the future hold?</span><Icon name="chevronRight" size={14}/></Link></div></div></>;
}
