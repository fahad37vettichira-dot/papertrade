"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useMemo, useState } from "react";
import { Icon } from "@/components/icons";
import { useSim } from "@/components/providers";
import { Empty, PageHeader, PageLoading, Segmented } from "@/components/ui";
import { SignalPill, SymbolBadge } from "@/components/widgets";
import { Sparkline } from "@/components/charts";
import { fmtMoney, fmtPct, fmtSignedPct, toneClass } from "@/lib/format";
import { SECTORS } from "@/lib/universe";
import type { AiSignalLabel } from "@/lib/engine";
import type { TickerView } from "@/lib/api-types";

type RealSignalRow = {
  symbol: string;
  companyName: string;
  sector: string;
  latestDate: string;
  latestClose: number;
  signal: AiSignalLabel;
  score: number;
  modelAgreement: number;
  rsi14: number | null;
  trend: string;
  volumeRatio: number | null;
  threeMonthRange: { low: number; median: number; high: number };
};
type ScreenerResult = { rows: RealSignalRow[]; unavailable: string[]; latestDate: string; source: string; sourceType: string; disclaimer: string };

export default function ExplorePage() { return <Suspense fallback={<PageLoading/>}><StockList/></Suspense>; }

function StockList() {
  const params = useSearchParams();
  const { snapshot, loading, watch, openQuickTrade, busy } = useSim();
  const [view, setView] = useState<"all" | "watchlist">(params.get("view") === "watchlist" ? "watchlist" : "all");
  const [query, setQuery] = useState("");
  const [sector, setSector] = useState("All");
  const [sort, setSort] = useState("name");
  const [page, setPage] = useState(0);
  const [scan, setScan] = useState<ScreenerResult | null>(null);
  const [scanBusy, setScanBusy] = useState(false);
  const [scanError, setScanError] = useState("");
  const [signalFilter, setSignalFilter] = useState("All signals");

  const stocks = useMemo(() => (snapshot?.tickers || [])
    .filter(t => (view !== "watchlist" || t.watched) && (sector === "All" || t.sector === sector) && `${t.symbol} ${t.name}`.toLowerCase().includes(query.toLowerCase().trim()))
    .sort((a, b) => sort === "gainers" ? b.changePct - a.changePct : sort === "losers" ? a.changePct - b.changePct : a.name.localeCompare(b.name)), [snapshot, view, sector, sort, query]);

  if (loading && !snapshot) return <PageLoading/>;
  if (!snapshot) return <Empty title="Your stock list is taking a moment." hint="Use Try again above to reconnect."/>;
  const pages = Math.max(1, Math.ceil(stocks.length / 10));
  const current = Math.min(page, pages - 1);
  const visibleSignals = scan?.rows.filter(row => signalFilter === "All signals" || row.signal === signalFilter) ?? [];

  const runRealScan = async () => {
    if (scanBusy) return;
    setScanBusy(true);
    setScanError("");
    try {
      const response = await fetch("/api/market-data/screener", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Real-history scan is unavailable right now.");
      setScan(result as ScreenerResult);
    } catch (reason) {
      setScanError(reason instanceof Error ? reason.message : "Couldn’t scan historical prices. Try again later.");
    } finally {
      setScanBusy(false);
    }
  };

  return <><PageHeader title="Find your next possibility." subtitle="Start with a company you know. Every investment here is a practice run."/>
    <div className="page-stack">
      <section className="panel overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="max-w-xl"><div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-lg bg-[#f1f5ed] text-[#79966d]"><Icon name="activity" size={16}/></span><h2 className="text-sm font-medium">Real-history stock signals <span className="ml-1 text-[10px] font-normal text-[var(--muted)]">Optional</span></h2></div><p className="hint mt-2">Scan the supported companies using reported daily market prices. This is separate from your practice prices.</p></div>
          <button type="button" className="btn" disabled={scanBusy} onClick={() => void runRealScan()}>{scanBusy ? <><span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-[#dbe7d2] border-t-[#739a58]"/>Checking daily history…</> : <><Icon name="search" size={14}/>{scan ? "Refresh real-data scan" : "Scan market signals"}</>}</button>
        </div>
        {scanError && <p className="mx-5 mb-5 rounded-lg border border-[#f1dfd7] bg-[#fff9f6] p-3 text-xs text-[#a86a59]" role="alert">{scanError}</p>}
        {scan && <div className="border-t border-[var(--line)]"><div className="flex flex-wrap items-center justify-between gap-3 bg-[#fafbf8] px-5 py-3"><div><p className="text-[11px] font-medium">{scan.rows.length} actual-data signal{scan.rows.length === 1 ? "" : "s"} · latest daily close {scan.latestDate}</p><p className="mt-1 text-[9px] text-[var(--muted)]">{scan.source} · {scan.sourceType}{scan.unavailable.length ? ` · No data: ${scan.unavailable.join(", ")}` : ""}</p></div><select aria-label="Filter actual signals" className="select !w-auto !min-h-[34px] !py-1.5 !text-[10px]" value={signalFilter} onChange={e => setSignalFilter(e.target.value)}><option>All signals</option>{["Strong Buy", "Buy", "Hold", "Sell", "Strong Sell"].map(label => <option key={label}>{label}</option>)}</select></div>
          <div className="table-scroll"><table className="data-table"><thead><tr><th>Company</th><th>Historical-data signal</th><th className="text-right">Latest daily close</th><th className="text-right">Model agreement</th><th className="hidden text-right md:table-cell">3-month Monte Carlo range</th><th/></tr></thead><tbody>{visibleSignals.map(row => <tr key={row.symbol}><td><Link href={`/markets/${row.symbol}`} className="flex items-center gap-3"><SymbolBadge symbol={row.symbol} size={31}/><span><span className="stock-name block">{row.companyName}</span><span className="stock-ticker block">{row.symbol} · {row.sector}</span></span></Link></td><td><div className="flex flex-wrap items-center gap-2"><SignalPill label={row.signal}/><span className="tnum text-[9px] text-[var(--muted)]">{row.trend}</span></div></td><td className="tnum text-right text-xs">{fmtMoney(row.latestClose)}</td><td className="tnum text-right text-xs">{row.modelAgreement}%</td><td className="hidden text-right md:table-cell"><p className="tnum text-[10px]">{fmtMoney(row.threeMonthRange.low)}–{fmtMoney(row.threeMonthRange.high)}</p><p className="tnum mt-1 text-[9px] text-[var(--muted)]">median {fmtMoney(row.threeMonthRange.median)}</p></td><td className="text-right"><button className="btn btn-xs" onClick={() => openQuickTrade(row.symbol, "buy")}>Practice <Icon name="plus" size={11}/></button></td></tr>)}</tbody></table></div>
          {!visibleSignals.length && <p className="p-5 text-center text-xs text-[var(--muted)]">No stocks match this signal. Try another filter.</p>}
          <p className="px-5 pb-4 text-[9px] text-[var(--muted)]">{scan.disclaimer} Historical signal estimates do not change your simulated order price.</p>
        </div>}
      </section>

      <div className="simple-tabs" role="tablist" aria-label="Stock lists"><button role="tab" aria-selected={view === "all"} onClick={() => { setView("all"); setPage(0); }}>All stocks <span className="ml-2 text-[9px] text-[#aab3a6]">{snapshot.tickers.length}</span></button><button role="tab" aria-selected={view === "watchlist"} onClick={() => { setView("watchlist"); setPage(0); }}>Your watchlist <span className="ml-2 text-[9px] text-[#aab3a6]">{snapshot.watchlist.length}</span></button></div>
      <section className="panel overflow-hidden"><div className="flex flex-wrap items-center gap-3 p-5"><label className="relative min-w-[200px] flex-1"><Icon name="search" size={17} className="absolute top-1/2 left-3.5 -translate-y-1/2 text-[#a6b2a2]"/><input aria-label="Search stocks" className="input !pl-10" placeholder="Search a company or symbol…" value={query} onChange={e => { setQuery(e.target.value); setPage(0); }}/></label><select aria-label="Filter by sector" className="select !w-auto min-w-[139px] !text-[11px]" value={sector} onChange={e => { setSector(e.target.value); setPage(0); }}><option value="All">All sectors</option>{SECTORS.map(s => <option key={s}>{s}</option>)}</select><select aria-label="Sort stocks" className="select !w-auto min-w-[140px] !text-[11px]" value={sort} onChange={e => { setSort(e.target.value); setPage(0); }}><option value="name">Company A–Z</option><option value="gainers">Biggest gainers</option><option value="losers">Biggest declines</option></select></div>
        <div className="table-scroll desktop-stock-table"><table className="data-table"><thead><tr><th className="w-7"/><th>Company</th><th className="text-right">Practice price</th><th className="text-right">Simulated</th><th className="hidden text-right md:table-cell">Recent simulated trend</th><th className="text-right">Make a move</th></tr></thead><tbody>{stocks.slice(current * 10, current * 10 + 10).map(t => <tr key={t.symbol}><td><button disabled={busy} className="btn btn-ghost btn-icon !h-7 !min-h-7 !w-7" aria-label={`${t.watched ? "Remove" : "Add"} ${t.symbol} ${t.watched ? "from" : "to"} watchlist`} aria-pressed={t.watched} onClick={() => void watch(t.symbol)}><Icon name="star" size={15} filled={t.watched} className={t.watched ? "text-[#bca269]" : "text-[#c8cec5]"}/></button></td><td><Link href={`/markets/${t.symbol}`} className="flex items-center gap-3"><SymbolBadge symbol={t.symbol}/><span><span className="stock-name block whitespace-nowrap">{t.name}</span><span className="stock-ticker block">{t.symbol} <span className="hidden sm:inline">· {t.sector}</span>{t.shares > 0 && <span className="ml-2 text-[#8baf70]">Owned</span>}</span></span></Link></td><td className="tnum whitespace-nowrap text-right font-medium">{fmtMoney(t.price)}</td><td className={`tnum whitespace-nowrap text-right ${toneClass(t.changePct)}`}>{fmtSignedPct(t.changePct)}</td><td className="hidden text-right md:table-cell"><Sparkline values={t.spark} width={88} height={28} className="ml-auto"/></td><td className="text-right"><button className="btn btn-sm !border-[#dfe9d7] !bg-[#f5f8ef] !text-[#6e8955]" onClick={() => openQuickTrade(t.symbol, "buy")}>Buy <Icon name="plus" size={12}/></button></td></tr>)}</tbody></table></div>
        <MobileStockList stocks={stocks.slice(current * 10, current * 10 + 10)}/>
        {!stocks.length && <Empty title={view === "watchlist" ? "Nothing here just yet." : "No companies found."} hint={view === "watchlist" ? "Tap the star next to a company to keep it close." : "Try another company name, symbol, or sector."}/>}<div className="flex items-center justify-between border-t border-[var(--line)] px-5 py-4"><span className="text-[10px] text-[#9da897]">{stocks.length ? `${current * 10 + 1}–${Math.min((current + 1) * 10, stocks.length)} of ${stocks.length} companies` : "No matching companies"}</span><div className="flex items-center gap-3"><button type="button" className="btn btn-xs" disabled={current === 0} aria-label="Previous page" onClick={() => setPage(current - 1)}><Icon name="chevronRight" size={12} className="rotate-180"/></button><span className="text-[10px] text-[var(--muted)]">{current + 1} / {pages}</span><button type="button" className="btn btn-xs" disabled={current >= pages - 1} aria-label="Next page" onClick={() => setPage(current + 1)}><Icon name="chevronRight" size={12}/></button></div></div>
      </section>
      <div className="note flex items-start gap-3"><Icon name="info" size={15} className="mt-1 shrink-0"/><p>Practice prices move inside this sandbox and do not change to actual quotes. The optional real-data screener above uses reported daily prices for analysis only.</p></div>
    </div></>;
}

function MobileStockList({ stocks }: { stocks: TickerView[] }) {
  const { openQuickTrade, watch, busy } = useSim();
  return <div className="mobile-stock-list">{stocks.map(t => <article key={t.symbol} className="grid grid-cols-[36px_minmax(0,1fr)_auto] items-center gap-x-3 gap-y-2 border-t border-[var(--line)] px-5 py-4"><div className="row-span-2"><SymbolBadge symbol={t.symbol}/></div><Link href={`/markets/${t.symbol}`} className="min-w-0"><p className="stock-name truncate">{t.name}</p><p className="stock-ticker">{t.symbol}{t.shares > 0 && <span className="ml-2 text-[#8baf70]">Owned</span>}</p></Link><button className="btn btn-ghost btn-icon !h-7 !min-h-7 !w-7 justify-self-end" disabled={busy} aria-label={`${t.watched ? "Remove" : "Add"} ${t.symbol} ${t.watched ? "from" : "to"} watchlist`} aria-pressed={t.watched} onClick={() => void watch(t.symbol)}><Icon name="star" size={15} filled={t.watched} className={t.watched ? "text-[#bca269]" : "text-[#c8cec5]"}/></button><div className="flex flex-wrap items-center gap-x-3 gap-y-1"><span className="tnum text-xs font-medium">{fmtMoney(t.price)}</span><span className={`tnum text-[10px] ${toneClass(t.changePct)}`}>{fmtSignedPct(t.changePct)} practice</span></div><button className="btn btn-xs !border-[#dfe9d7] !bg-[#f5f8ef] !text-[#6e8955]" onClick={() => openQuickTrade(t.symbol, "buy")}>Buy <Icon name="plus" size={12}/></button></article>)}</div>;
}
