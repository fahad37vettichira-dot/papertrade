import {
  boolean,
  doublePrecision,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Single virtual trading account (id = 1). No real money is ever involved. */
export const accounts = pgTable("accounts", {
  id: integer("id").primaryKey(),
  name: text("name").notNull().default("Paper Trader"),
  cash: doublePrecision("cash").notNull().default(100_000),
  startingCash: doublePrecision("starting_cash").notNull().default(100_000),
  netDeposits: doublePrecision("net_deposits").notNull().default(100_000),
  realizedPnl: doublePrecision("realized_pnl").notNull().default(0),
  taxEnabled: boolean("tax_enabled").notNull().default(false),
  taxRate: doublePrecision("tax_rate").notNull().default(0.24), // short-term rate
  longTermTaxRate: doublePrecision("long_term_tax_rate").notNull().default(0.15),
  taxLiability: doublePrecision("tax_liability").notNull().default(0),
  taxPaid: doublePrecision("tax_paid").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Global simulated market clock + regime. */
export const markets = pgTable("markets", {
  id: integer("id").primaryKey(),
  day: integer("day").notNull().default(0),
  epoch: text("epoch").notNull(),
  seed: integer("seed").notNull().default(42),
  indexLevel: doublePrecision("index_level").notNull().default(100),
  prevIndexLevel: doublePrecision("prev_index_level").notNull().default(100),
  regime: text("regime").notNull().default("bull"),
  regimeDays: integer("regime_days").notNull().default(0),
  speed: doublePrecision("speed").notNull().default(0),
  lastTickAt: timestamp("last_tick_at", { withTimezone: true }).notNull().defaultNow(),
});

export const tickers = pgTable("tickers", {
  symbol: text("symbol").primaryKey(),
  name: text("name").notNull(),
  sector: text("sector").notNull(),
  description: text("description").notNull(),
  price: doublePrecision("price").notNull(),
  prevClose: doublePrecision("prev_close").notNull(),
  dayOpen: doublePrecision("day_open").notNull(),
  dayHigh: doublePrecision("day_high").notNull(),
  dayLow: doublePrecision("day_low").notNull(),
  volume: doublePrecision("volume").notNull().default(0),
  annualDrift: doublePrecision("annual_drift").notNull(),
  annualVol: doublePrecision("annual_vol").notNull(),
  beta: doublePrecision("beta").notNull(),
  dividendYield: doublePrecision("dividend_yield").notNull().default(0),
  updatedDay: integer("updated_day").notNull().default(0),
});

export const priceHistory = pgTable(
  "price_history",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    day: integer("day").notNull(),
    open: doublePrecision("open").notNull().default(0),
    high: doublePrecision("high").notNull().default(0),
    low: doublePrecision("low").notNull().default(0),
    close: doublePrecision("close").notNull(),
    volume: doublePrecision("volume").notNull().default(0),
  },
  (t) => [uniqueIndex("price_history_symbol_day_idx").on(t.symbol, t.day), index("price_history_day_idx").on(t.day)],
);

export const indexHistory = pgTable("index_history", {
  day: integer("day").primaryKey(),
  level: doublePrecision("level").notNull(),
});

export const accountHistory = pgTable(
  "account_history",
  {
    id: serial("id").primaryKey(),
    day: integer("day").notNull(),
    value: doublePrecision("value").notNull(),
    cash: doublePrecision("cash").notNull(),
    invested: doublePrecision("invested").notNull(),
  },
  (t) => [uniqueIndex("account_history_day_idx").on(t.day)],
);

export const newsItems = pgTable(
  "news_items",
  {
    id: serial("id").primaryKey(),
    day: integer("day").notNull(),
    kind: text("kind").notNull(), // market | company | event | earnings | analyst
    headline: text("headline").notNull(),
    summary: text("summary").notNull(),
    symbol: text("symbol"),
    sector: text("sector"),
    sentiment: doublePrecision("sentiment").notNull().default(0),
    impact: doublePrecision("impact").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("news_day_idx").on(t.day), index("news_symbol_idx").on(t.symbol)],
);

export const holdings = pgTable(
  "holdings",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    shares: doublePrecision("shares").notNull(),
    avgCost: doublePrecision("avg_cost").notNull(),
    openedDay: integer("opened_day").notNull(),
  },
  (t) => [uniqueIndex("holdings_symbol_idx").on(t.symbol)],
);

export const transactions = pgTable(
  "transactions",
  {
    id: serial("id").primaryKey(),
    day: integer("day").notNull(),
    kind: text("kind").notNull(), // buy | sell | deposit | withdraw | dividend | tax
    symbol: text("symbol"),
    shares: doublePrecision("shares").notNull().default(0),
    price: doublePrecision("price").notNull().default(0),
    amount: doublePrecision("amount").notNull().default(0),
    realized: doublePrecision("realized").notNull().default(0),
    note: text("note").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("transactions_day_idx").on(t.day)],
);

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    side: text("side").notNull(), // buy | sell
    orderType: text("order_type").notNull().default("limit"), // limit | stop
    qty: doublePrecision("qty").notNull(),
    limitPrice: doublePrecision("limit_price").notNull(),
    status: text("status").notNull().default("open"), // open | filled | cancelled | rejected
    createdDay: integer("created_day").notNull(),
    filledDay: integer("filled_day"),
    fillPrice: doublePrecision("fill_price"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("orders_status_idx").on(t.status)],
);

export const watchlist = pgTable(
  "watchlist",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("watchlist_symbol_idx").on(t.symbol)],
);

/** One forecast per real-data date/model/horizon; future values are filled when observed. */
export const modelForecastHistory = pgTable(
  "model_forecast_history",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    modelId: text("model_id").notNull(),
    horizon: text("horizon").notNull(),
    horizonDays: integer("horizon_days").notNull(),
    forecastDate: text("forecast_date").notNull(),
    targetDate: text("target_date").notNull(),
    referencePrice: doublePrecision("reference_price").notNull(),
    predictedLow: doublePrecision("predicted_low").notNull(),
    predictedMedian: doublePrecision("predicted_median").notNull(),
    predictedHigh: doublePrecision("predicted_high").notNull(),
    actualPrice: doublePrecision("actual_price"),
    errorPct: doublePrecision("error_pct"),
    directionCorrect: boolean("direction_correct"),
    evaluatedAt: timestamp("evaluated_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("model_forecast_identity_idx").on(t.symbol, t.modelId, t.forecastDate, t.horizon),
    index("model_forecast_symbol_date_idx").on(t.symbol, t.forecastDate),
  ],
);
