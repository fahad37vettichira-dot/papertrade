import type { SVGProps } from "react";

export type IconName =
  | "dashboard"
  | "markets"
  | "portfolio"
  | "sim"
  | "news"
  | "activity"
  | "wallet"
  | "plus"
  | "arrowUpRight"
  | "arrowDownRight"
  | "star"
  | "starFilled"
  | "clock"
  | "play"
  | "pause"
  | "bolt"
  | "shield"
  | "search"
  | "chevronDown"
  | "chevronRight"
  | "close"
  | "check"
  | "info"
  | "trash"
  | "settings"
  | "brain"
  | "scale"
  | "target"
  | "flask"
  | "download"
  | "upload";

const PATHS: Record<IconName, string[]> = {
  dashboard: ["M3 3h7v7H3z", "M14 3h7v7h-7z", "M14 14h7v7h-7z", "M3 14h7v7H3z"],
  markets: ["M3 17l6-6 4 4 7-7", "M14 8h7v7"],
  portfolio: ["M3 7h18v13H3z", "M8 7V4h8v3", "M3 12h18", "M10 12v2h4v-2"],
  sim: ["M4 20V10", "M10 20V4", "M16 20v-7", "M22 20H2"],
  news: ["M4 5h12v14H4z", "M16 9h4v10h-4", "M7 9h6", "M7 12h6", "M7 15h4"],
  activity: ["M3 12h4l3 8 4-16 3 8h4"],
  wallet: ["M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M3 7V5a2 2 0 0 1 2-2h12", "M17 13h.01"],
  plus: ["M12 5v14", "M5 12h14"],
  arrowUpRight: ["M7 17L17 7", "M8 7h9v9"],
  arrowDownRight: ["M7 7l10 10", "M17 8v9H8"],
  star: ["M12 3.5l2.6 5.3 5.9.9-4.3 4.2 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.5 9.7l5.9-.9z"],
  starFilled: ["M12 3.5l2.6 5.3 5.9.9-4.3 4.2 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.5 9.7l5.9-.9z"],
  clock: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z", "M12 7v5l3 2"],
  play: ["M8 5l11 7-11 7z"],
  pause: ["M8 5h3v14H8z", "M14 5h3v14h-3z"],
  bolt: ["M13 2L4 14h6l-1 8 9-12h-6z"],
  shield: ["M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"],
  search: ["M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z", "M21 21l-4.3-4.3"],
  chevronDown: ["M6 9l6 6 6-6"],
  chevronRight: ["M9 6l6 6-6 6"],
  close: ["M6 6l12 12", "M18 6L6 18"],
  check: ["M4 12l5 5L20 6"],
  info: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z", "M12 11v6", "M12 7.5h.01"],
  trash: ["M4 7h16", "M9 7V4h6v3", "M6 7l1 13h10l1-13", "M10 11v6", "M14 11v6"],
  settings: ["M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z", "M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.5-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4a2 2 0 1 1 4 0 1.7 1.7 0 0 0 2.9 1.5l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4z"],
  brain: ["M9 3a3 3 0 0 0-3 3 3 3 0 0 0-1 5.8V15a3 3 0 0 0 4 2.8V21", "M15 3a3 3 0 0 1 3 3 3 3 0 0 1 1 5.8V15a3 3 0 0 1-4 2.8V21", "M12 5v14"],
  scale: ["M12 4v16", "M6 8h12", "M6 8l-3 7h6z", "M18 8l-3 7h6z"],
  target: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z", "M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z", "M12 12h.01"],
  flask: ["M9 3h6", "M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 18l-5-9V3", "M7.5 14h9"],
  download: ["M12 4v11", "M7 11l5 5 5-5", "M5 20h14"],
  upload: ["M12 20V9", "M7 13l5-5 5 5", "M5 4h14"],
};

export function Icon({
  name,
  size = 18,
  filled = false,
  ...props
}: { name: IconName; size?: number; filled?: boolean } & Omit<SVGProps<SVGSVGElement>, "name">) {
  const isFilled = filled || name === "starFilled";
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill={isFilled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      {...props}
    >
      {PATHS[name].map((d, i) => (
        <path key={i} d={d} />
      ))}
    </svg>
  );
}

export function Logo({ size = 30 }: { size?: number }) {
  return <span className="inline-flex shrink-0 items-center justify-center" style={{ width: size, height: size }}><svg width={size} height={size} viewBox="0 0 36 36" fill="none" aria-hidden="true"><path d="M5 28V8l11 5v20L5 28Z" fill="#39784c"/><path d="M16 33V13l14-8v20l-14 8Z" fill="#8aaf66"/><path d="m5 8 14-8 11 5-14 8L5 8Z" fill="#c6dd9c"/></svg></span>;
}
