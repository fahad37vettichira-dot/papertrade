"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { Icon, Logo, type IconName } from "@/components/icons";
import { Modal, Pill, Segmented, InfoRow } from "@/components/ui";
import { TradeTicket } from "@/components/widgets";
import { TimeTravelCard } from "@/components/time-travel";
import { useSim } from "@/components/providers";
import { fmtDayMedium } from "@/lib/time";
import { fmtMoney, fmtSignedMoney, toneClass } from "@/lib/format";

const NAV: { href: string; label: string; short: string; icon: IconName }[] = [
  { href: "/", label: "Overview", short: "Home", icon: "dashboard" },
  { href: "/markets", label: "Explore stocks", short: "Stocks", icon: "markets" },
  { href: "/portfolio", label: "My portfolio", short: "Portfolio", icon: "portfolio" },
  { href: "/activity", label: "Activity & funds", short: "Activity", icon: "wallet" },
];
const TOOLS: typeof NAV = [
  { href: "/simulations", label: "Future simulator", short: "Simulator", icon: "flask" },
  { href: "/news", label: "Market news", short: "News", icon: "news" },
];

function FundsDialog() {
  const { funds, openCash, closeCash, snapshot, cash, busy } = useSim();
  const [raw, setRaw] = useState("10000");
  const [settle, setSettle] = useState(false);
  const [error, setError] = useState("");
  if (!snapshot || !funds) return null;
  const amount = Number(raw), reserve = settle && snapshot.account.taxEnabled && funds === "withdraw" ? snapshot.account.taxLiability : 0;
  const valid = Number.isFinite(amount) && amount > 0 && (funds === "deposit" ? amount <= 5_000_000 : amount + reserve <= snapshot.account.cash);
  return <Modal open onClose={closeCash} title={funds === "deposit" ? "A little more room to practice." : "Withdraw virtual cash"} subtitle="No bank details. No real transactions. Just practice money."><Segmented value={funds} options={[{ value: "deposit", label: "Add funds" }, { value: "withdraw", label: "Withdraw" }]} onChange={value => { setError(""); openCash(value); }} />
    <form onSubmit={async e => { e.preventDefault(); if (!valid) return; const result = await cash({ action: funds, amount, settleTax: settle }); if (result.ok) closeCash(); else setError(result.message); }} className="mt-5"><div className="flex items-center justify-between text-xs"><label className="label" htmlFor="fund-amount">{funds === "deposit" ? "How much would you like to add?" : "How much would you like to take out?"}</label></div><div className="relative mt-3"><span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl text-[#91a18d]">$</span><input id="fund-amount" className="input input-money" inputMode="decimal" value={raw} onChange={e => setRaw(e.target.value.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1"))}/></div><div className="mt-3 flex flex-wrap gap-2">{[1000, 10000, 25000].map(n => <button type="button" key={n} className="btn btn-xs" onClick={() => setRaw(String(n))}>{fmtMoney(n, 0)}</button>)}{funds === "withdraw" && <button type="button" className="btn btn-xs" onClick={() => setRaw(String(Math.max(0, Math.floor((snapshot.account.cash - reserve) * 100) / 100)))}>Max</button>}</div>
    {funds === "withdraw" && snapshot.account.taxEnabled && snapshot.account.taxLiability > 0 && <label className="hint mt-5 flex gap-2"><input type="checkbox" checked={settle} onChange={e => setSettle(e.target.checked)}/> Also settle {fmtMoney(snapshot.account.taxLiability)} of simulated tax</label>}
    <div className="mt-5 rounded-xl bg-[#f7f9f4] px-4 py-2"><InfoRow label="Cash available" value={fmtMoney(snapshot.account.cash)}/><InfoRow label="Cash after" value={fmtMoney(snapshot.account.cash + (funds === "deposit" ? amount || 0 : -(amount || 0) - reserve))}/></div>
    {funds === "withdraw" && <p className="hint mt-4">Your total profit or loss is <span className={toneClass(snapshot.totals.totalPnl)}>{fmtSignedMoney(snapshot.totals.totalPnl)}</span>. Withdrawing cash doesn’t change that result, except for any simulated tax you settle.</p>}
    {(error || (raw && !valid)) && <p className="mt-4 text-xs down" role="alert">{error || (funds === "withdraw" ? "Enter an amount within your available cash." : "Enter an amount between $0.01 and $5,000,000.")}</p>}
    <button className="btn btn-primary mt-5 w-full" disabled={busy || !valid} type="submit">{busy ? "Updating balance…" : funds === "deposit" ? `Add ${fmtMoney(amount || 0)} in virtual cash` : `Withdraw ${fmtMoney(amount || 0)}`}</button></form></Modal>;
}

function QuickTradeDialog() {
  const { snapshot, quickTrade, closeQuickTrade } = useSim();
  if (!quickTrade || !snapshot) return null;
  const ticker = snapshot.tickers.find(t => t.symbol === quickTrade.symbol);
  if (!ticker) return null;
  return <Modal open onClose={closeQuickTrade} title={quickTrade.side === "sell" ? "Make your next move." : "Let’s make a practice investment."} subtitle="A small step toward being a more confident investor."><TradeTicket key={`${ticker.symbol}-${quickTrade.side}`} symbol={ticker.symbol} name={ticker.name} price={ticker.price} cash={snapshot.account.cash} shares={ticker.shares} initialSide={quickTrade.side} onSuccess={closeQuickTrade}/></Modal>;
}

export function SpeedControl() {
  const { snapshot, openTime } = useSim();
  return <button type="button" onClick={openTime} className="btn btn-ghost gap-2 !text-[11px]" title="Change simulated time"><Icon name="clock" size={15}/><span className="header-date-label">{snapshot ? fmtDayMedium(snapshot.market.day, snapshot.market.epoch) : "Loading…"}</span><span className="hidden sm:inline text-[9px] text-[#a3ada3]">simulated</span></button>;
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { snapshot, error, refresh, openCash, funds, timeOpen, closeTime, toasts, dismissToast, reset, busy } = useSim();
  const [help, setHelp] = useState(false);
  const [more, setMore] = useState(false);
  const [resetConfirm, setResetConfirm] = useState(false);
  const active = (href: string) => href === "/" ? pathname === "/" : pathname.startsWith(href);
  const current = [...NAV, ...TOOLS].find(n => active(n.href));
  const navLink = (item: typeof NAV[number]) => <Link key={item.href} href={item.href} className="nav-item" data-active={active(item.href)} onClick={() => setMore(false)}><Icon name={item.icon} size={18}/><span>{item.label}</span></Link>;
  return <div><a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[150] focus:rounded focus:bg-white focus:p-3">Skip to content</a>
    <aside className="app-sidebar"><Link href="/" className="app-brand"><Logo size={29}/><span>papertrade<span className="text-[#8ca47e]">.</span></span></Link><div className="mx-2 mt-8 rounded-lg border border-[#edf0e8] bg-[#fafbf8] px-3 py-2.5"><p className="text-[11px] font-medium">My practice workspace</p><p className="mt-1 flex items-center gap-1.5 text-[9px] text-[#9aa68f]"><span className="dot text-[#90b26e]"/> Virtual account</p></div><p className="sidebar-group">Your workspace</p><nav className="space-y-1">{NAV.map(navLink)}</nav><p className="sidebar-group">Learn & experiment</p><nav className="space-y-1">{TOOLS.map(navLink)}</nav><div className="sidebar-guide"><span className="mb-3 grid h-8 w-8 place-items-center rounded-full bg-[#e2ecd6] text-[#7d9a65]"><Icon name="shield" size={16}/></span><p className="text-[12px] font-medium">Real practice. Zero risk.</p><p className="mt-2 text-[10px] leading-[1.8] text-[#8b977f]">Learn by doing, one virtual investment at a time.</p><button type="button" className="section-link mt-4 !text-[10px]" onClick={() => setHelp(true)}>How it works <Icon name="arrowUpRight" size={12}/></button></div><button type="button" className="mt-5 flex items-center gap-3 border-t border-[var(--line)] px-2 pt-5 text-left" onClick={() => setHelp(true)}><span className="grid h-8 w-8 place-items-center rounded-full bg-[#e9eee6] text-[10px] font-medium text-[#748569]">PT</span><span><span className="block text-[11px] font-medium">Paper Trader</span><span className="text-[9px] text-[#a0a99f]">Here to learn</span></span><Icon name="chevronDown" size={12} className="ml-auto text-[#9aab94]"/></button></aside>
    <div className="app-main"><header className="app-header"><div className="hidden items-center gap-3 text-[11px] text-[#a6b0a8] min-[1001px]:flex"><Icon name="dashboard" size={14}/><span>/</span><span className="text-[#65786a]">{current?.label || "Stock details"}</span></div><Link href="/" className="app-brand !p-0 !text-[17px] min-[1001px]:hidden"><Logo size={25}/><span>papertrade<span className="text-[#8ca47e]">.</span></span></Link><div className="flex items-center gap-2"><SpeedControl/><button type="button" className="btn btn-ghost btn-icon hidden sm:flex" onClick={() => setHelp(true)} aria-label="How Paper Trade works"><Icon name="info" size={17}/></button><span className="mx-2 hidden h-5 w-px bg-[#e5ebe4] sm:block"/><button type="button" className="btn btn-primary" onClick={() => openCash("deposit")}><Icon name="plus" size={14}/><span>Add funds</span></button></div></header>
    <div className="app-content">{error && <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#ecd0c6] bg-[#fff5ee] px-4 py-3 text-xs text-[#a46756]" role="alert">{error}<button className="btn btn-xs" onClick={() => void refresh()}>Try again</button></div>}<main id="main-content">{children}</main><footer className="app-footer"><span>Made for learning. Not for real-money trading.</span><span className="flex items-center gap-1.5"><Icon name="shield" size={11}/> All prices, news & funds are simulated.</span></footer></div></div>
    <nav className="mobile-bar" aria-label="Main navigation">{NAV.map(n => <Link key={n.href} href={n.href} data-active={active(n.href)}><Icon name={n.icon} size={18}/>{n.short}</Link>)}<button type="button" data-active={TOOLS.some(t => active(t.href))} onClick={() => setMore(true)}><Icon name="settings" size={18}/>More</button></nav>
    <QuickTradeDialog/>{funds && <FundsDialog key={funds}/>}<Modal open={timeOpen} onClose={closeTime} title="Skip the wait." subtitle="Move your simulated market forward and see what happens to your investments."><TimeTravelCard dialog/></Modal>
    <Modal open={more} onClose={() => setMore(false)} title="A little more to explore."><nav className="space-y-2">{TOOLS.map(navLink)}<button className="nav-item w-full" onClick={() => { setMore(false); setHelp(true); }}><Icon name="info" size={18}/> How it works</button></nav></Modal>
    <Modal open={help} onClose={() => { setHelp(false); setResetConfirm(false); }} title="Investing practice, made simple." subtitle="No bank account or real money required."><div className="space-y-5">{[{ title: "Find a company you know", body: "Go to Explore stocks. Open a company to see its price, or tap Buy to get started.", icon: "search" as const }, { title: "Make a virtual investment", body: "Enter an amount, review the details, and confirm. You can sell shares whenever you like.", icon: "portfolio" as const }, { title: "See what time changes", body: "Skip a day, a month, or up to five years. Fictional news can move prices unexpectedly.", icon: "clock" as const }].map((step, i) => <div key={step.title} className="flex gap-3"><span className="step-num shrink-0">{i + 1}</span><div><h3 className="text-sm font-medium">{step.title}</h3><p className="hint mt-1">{step.body}</p></div></div>)}<div className="note">Your example account starts with $100,000 and four sample investments. The market starts paused. All model suggestions are educational, not financial advice.</div><details className="details"><summary>Need a fresh start?</summary><div className="details-body"><p className="hint">Resetting removes your holdings, trades, cash changes and simulated progress. It restores the original example account.</p>{resetConfirm ? <div className="mt-4 flex gap-2"><button className="btn btn-danger" disabled={busy} onClick={async () => { await reset(); setHelp(false); setResetConfirm(false); }}>Yes, reset my account</button><button className="btn" onClick={() => setResetConfirm(false)}>Cancel</button></div> : <button className="btn mt-4" onClick={() => setResetConfirm(true)}>Reset practice account</button>}</div></details></div></Modal>
    <div className="pointer-events-none fixed bottom-[90px] right-4 left-4 z-[130] flex flex-col items-end gap-2 min-[1001px]:bottom-6" role="status" aria-live="polite">{toasts.map(t => <button type="button" key={t.id} className={`toast pointer-events-auto flex max-w-sm items-start gap-3 rounded-xl border bg-white px-4 py-3 text-left shadow-lg ${t.tone === "down" ? "border-[#ebd4c9]" : "border-[#dbe7d2]"}`} onClick={() => dismissToast(t.id)}><span className={`mt-0.5 ${t.tone === "down" ? "down" : "up"}`}><Icon name={t.tone === "up" ? "check" : "info"} size={16}/></span><span className="text-xs leading-relaxed">{t.message}</span></button>)}</div>
  </div>;
}

