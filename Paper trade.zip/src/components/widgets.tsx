"use client";

import Link from "next/link";
import { useState, type FormEvent, type ReactNode } from "react";
import { Icon } from "@/components/icons";
import { InfoRow, Pill, Segmented } from "@/components/ui";
import { useSim } from "@/components/providers";
import { fmtDayShort } from "@/lib/time";
import { fmtMoney, fmtShares, fmtSignedPct } from "@/lib/format";
import { sentimentLabel, sentimentTone, symbolColor } from "@/lib/palette";
import type { AiSignal, AiSignalLabel } from "@/lib/engine";
import type { NewsView } from "@/lib/api-types";

export function SymbolBadge({ symbol, size = 36 }: { symbol: string; size?: number }) {
  const color = symbolColor(symbol);
  return <span className="stock-icon" style={{ width: size, height: size, color, background: `${color}12`, fontSize: size > 40 ? 20 : 14 }}>{symbol === "MSFT" ? <span className="grid h-4 w-4 grid-cols-2 gap-[2px]"><i className="bg-[#cd8f78]"/><i className="bg-[#9ab77a]"/><i className="bg-[#81aabc]"/><i className="bg-[#d6bd7d]"/></span> : symbol === "NVDA" ? <span className="font-bold italic">N</span> : symbol.slice(0, 1)}</span>;
}
export function SignalPill({ label }: { label: AiSignalLabel }) { return <Pill tone={label.includes("Buy") ? "up" : label.includes("Sell") ? "down" : "neutral"}>{label}</Pill>; }

export function NewsCard({ item, epoch, compact = false }: { item: NewsView; epoch: string; compact?: boolean }) {
  return <article className={compact ? "news-mini" : "news-list-card"}><div className="flex flex-wrap items-center gap-2"><Pill tone={item.kind === "event" ? "warn" : "accent"}>{item.symbol || (item.kind === "event" ? "Market event" : item.sector || "Market news")}</Pill><span className="text-[10px] text-[var(--muted)]">{fmtDayShort(item.day, epoch)}</span></div><h3 className={compact ? "" : "mt-4 text-[16px] font-medium leading-relaxed tracking-tight"}>{item.symbol ? <Link className="hover:text-[var(--accent)]" href={`/markets/${item.symbol}`}>{item.headline}</Link> : item.headline}</h3>{!compact && <p className="hint mt-3">{item.summary}</p>}{!compact && <div className="mt-5 flex items-center gap-3"><Pill tone={sentimentTone(item.sentiment)}>{sentimentLabel(item.sentiment)}</Pill>{item.impact !== 0 && <span className="text-[10px] text-[var(--muted)]">Simulated price impact {fmtSignedPct(item.impact, 1)}</span>}</div>}</article>;
}

export function AiSignalCard({ signal, symbol, compact = false }: { signal: AiSignal; symbol: string; compact?: boolean }) {
  const verb = signal.label.includes("Buy") ? "buying" : signal.label.includes("Sell") ? "reducing exposure" : "waiting";
  return <div className="rounded-xl border border-[#e5e8dc] bg-[#f8f9f0] p-5"><div className="flex items-center justify-between gap-2"><span className="flex items-center gap-2 text-xs font-medium text-[#6a7955]"><Icon name="brain" size={16}/> Practice-market signal</span><SignalPill label={signal.label}/></div><p className="mt-4 text-sm leading-relaxed">The model leans toward <strong className="font-medium">{verb}</strong> {symbol}. This practice-only view uses generated sandbox prices; open the real-history analysis to compare results built from historical market data.</p><div className="mt-4 border-t border-[#e8ebde] pt-2"><InfoRow label="30-day model target" value={fmtMoney(signal.target)}/><InfoRow label="Possible price change" value={fmtSignedPct(signal.expectedReturn)} tone={signal.expectedReturn >= 0 ? "up" : "down"}/></div>{!compact && <details className="mt-3"><summary className="cursor-pointer text-[11px] text-[#7b896a]">Why does it think that?</summary><ul className="hint mt-3 list-disc space-y-2 pl-4">{signal.reasons.map(r => <li key={r}>{r}</li>)}</ul><p className="mt-3 text-[10px] text-[var(--muted)]">This is a rule-based simulation model, not a connected AI service. Its confidence score is not a verified prediction accuracy.</p></details>}<p className="mt-4 text-[10px] text-[#9ca48b]">A learning aid, not financial advice or a guarantee.</p></div>;
}

export function TradeTicket({ symbol, price, cash, shares, name, initialSide = "buy", compact = false, onSuccess }: { symbol: string; price: number; cash: number; shares: number; name?: string; initialSide?: "buy" | "sell"; compact?: boolean; onSuccess?: () => void }) {
  const { trade, busy, snapshot, setSpeed } = useSim();
  const [side, setSide] = useState<"buy" | "sell">(initialSide);
  const [unit, setUnit] = useState<"dollars" | "shares">(initialSide === "sell" ? "shares" : "dollars");
  const [raw, setRaw] = useState("");
  const [orderType, setOrderType] = useState<"market" | "limit" | "stop">("market");
  const [trigger, setTrigger] = useState(price.toFixed(2));
  const [step, setStep] = useState<"edit" | "review" | "done">("edit");
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState("");
  const live = snapshot?.tickers.find(t => t.symbol === symbol);
  const quote = Math.round((live?.price ?? price) * 10000) / 10000;
  const liveCash = snapshot?.account.cash ?? cash;
  const liveShares = snapshot?.holdings.find(h => h.symbol === symbol)?.shares ?? (snapshot ? 0 : shares);
  const effective = orderType === "market" ? quote : Number(trigger);
  const input = Number(raw);
  const qty = unit === "shares" ? Math.floor(input * 10000 + .000001) / 10000 : effective > 0 ? Math.floor(input / effective * 10000 + .000001) / 10000 : 0;
  const total = Math.round(qty * effective * 100) / 100;
  const valid = Number.isFinite(input) && Number.isFinite(qty) && Number.isFinite(total) && input > 0 && qty > 0 && total >= .01 && effective > 0 && (side === "buy" ? total <= liveCash : qty <= liveShares + .000001);
  const clean = (v: string) => v.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!valid || submitting) return;
    if (step === "edit") { if (snapshot?.market.speed) await setSpeed(0); setFeedback(""); setStep("review"); return; }
    setSubmitting(true);
    const result = await trade({ symbol, side, qty, orderType, ...(orderType !== "market" ? { limitPrice: effective } : {}) });
    setSubmitting(false);
    setFeedback(result.message);
    if (result.ok) setStep("done");
  };
  if (step === "done") return <div className="py-5 text-center"><span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#edf5e5] text-[#5e8a47]"><Icon name="check" size={25}/></span><h3 className="mt-5 text-lg font-medium">{orderType === "market" ? "Nicely done!" : "Your order is placed."}</h3><p className="hint mx-auto mt-2 max-w-xs">{feedback}</p><p className="hint mt-4">All money in this trade is virtual.</p><button type="button" className="btn btn-primary mt-6 w-full" onClick={() => { if (onSuccess) onSuccess(); else { setRaw(""); setStep("edit"); setFeedback(""); } }}>Done <Icon name="check" size={14}/></button></div>;
  return <form onSubmit={submit} className="min-w-0"><div className="mb-5 flex items-center justify-between"><div className="flex items-center gap-3"><SymbolBadge symbol={symbol} size={38}/><div><p className="text-sm font-medium">{name || symbol}</p><p className="mt-0.5 text-[11px] text-[var(--muted)]">{symbol} · {fmtMoney(quote)} per share</p></div></div></div>
    {step === "edit" ? <><Segmented options={[{ value: "buy", label: "Buy stock" }, { value: "sell", label: "Sell stock" }]} value={side} onChange={v => { setSide(v); setUnit(v === "buy" ? "dollars" : "shares"); setRaw(""); setFeedback(""); }} className="w-full [&_button]:flex-1"/>
    <div className="mt-5 flex items-center justify-between"><label className="label" htmlFor={`trade-amount-${symbol}`}>{unit === "dollars" ? side === "buy" ? "How much would you like to invest?" : "How much would you like to sell?" : "How many shares?"}</label></div><div className="relative mt-3"><span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl text-[#91a18d]">{unit === "dollars" ? "$" : "#"}</span><input id={`trade-amount-${symbol}`} className="input input-money" inputMode="decimal" placeholder="0.00" required autoComplete="off" value={raw} onChange={e => setRaw(clean(e.target.value))}/></div>
    <div className="mt-2 flex items-center justify-between"><span className="text-[10px] text-[var(--muted)]">{side === "buy" ? `${fmtMoney(liveCash)} available` : `${fmtShares(liveShares)} shares owned`}</span><button type="button" className="text-[10px] text-[var(--accent)]" onClick={() => { setUnit(unit === "dollars" ? "shares" : "dollars"); setRaw(""); }}>Use {unit === "dollars" ? "shares" : "dollars"} instead</button></div>
    <div className="mt-4 flex gap-2">{[100, 500, 1000].map(n => <button key={n} type="button" className="btn btn-xs flex-1" onClick={() => { setUnit("dollars"); setRaw(String(n)); }}>{fmtMoney(n, 0)}</button>)}<button type="button" className="btn btn-xs flex-1" onClick={() => { if (side === "sell") { setUnit("shares"); setRaw(String(liveShares)); } else { setUnit("dollars"); setRaw(String(liveCash)); } }}>Max</button></div>
    <details className="mt-5 text-[11px]"><summary className="cursor-pointer text-[var(--muted)]">Advanced order options {orderType !== "market" && `· ${orderType}`}</summary><div className="mt-3 space-y-3"><select aria-label="Order type" className="select" value={orderType} onChange={e => setOrderType(e.target.value as typeof orderType)}><option value="market">Market — trade now</option><option value="limit">Limit — choose your price</option><option value="stop">Stop — trigger at a price</option></select>{orderType !== "market" && <div className="field"><label className="label" htmlFor={`trigger-${symbol}`}>{orderType === "limit" ? "Your limit price" : "Stop trigger price"} ($)</label><input id={`trigger-${symbol}`} className="input" value={trigger} inputMode="decimal" onChange={e => setTrigger(clean(e.target.value))}/><p className="hint">The order waits until the simulated price reaches this level. Must be within 50% of today’s price.</p></div>}</div></details>
    <div className="my-5 border-t border-[var(--line)] pt-3"><InfoRow label="Estimated shares" value={Number.isFinite(qty) ? fmtShares(qty) : "0"}/><InfoRow label={side === "buy" ? "Estimated cost" : "Estimated proceeds"} value={fmtMoney(total || 0)}/></div>
    {input > 0 && !valid && <p className="mb-3 text-xs down" role="alert">{side === "sell" ? "You can only sell shares you own." : "Check your amount and available cash."}</p>}</> : <><Pill tone="accent">Review your virtual {side === "buy" ? "purchase" : "sale"}</Pill><div className="my-4 rounded-xl bg-[#f8faf6] px-4 py-2"><InfoRow label="Company" value={symbol}/><InfoRow label="Shares" value={fmtShares(qty)}/><InfoRow label="Price per share" value={fmtMoney(effective)}/><InfoRow label="Order type" value={orderType === "market" ? "Market (now)" : orderType === "limit" ? "Limit order" : "Stop order"}/><InfoRow label="Commission" value="$0.00"/><div className="divider my-1"/><InfoRow label="Estimated total" value={fmtMoney(total)}/></div><p className="hint mb-5">{orderType === "market" ? "Your trade will use the latest simulated price. No real money or securities are involved." : "Your order stays open until the market reaches your price. You can cancel it from Portfolio."}</p></>}
    {feedback && <p className="mb-3 text-xs down" role="alert">{feedback}</p>}
    <button type="submit" disabled={!valid || submitting || busy} className={`btn w-full ${side === "buy" ? "btn-primary" : "btn-down"}`}>{submitting ? "Placing your order…" : step === "review" ? `Confirm virtual ${side === "buy" ? "purchase" : "sale"}` : "Review order"}{!submitting && <Icon name="chevronRight" size={14}/>}</button>
    {step === "review" && <button type="button" className="btn btn-ghost mt-2 w-full" onClick={() => setStep("edit")}>Back to edit</button>}
    {!compact && <p className="mt-3 flex items-center justify-center gap-1.5 text-[10px] text-[#a0aa9c]"><Icon name="shield" size={11}/> Only virtual money. Always.</p>}
  </form>;
}

export function MiniStat({ label, value, tone }: { label: string; value: ReactNode; tone?: string }) { return <div className="rounded-xl border border-[var(--line)] bg-white p-4"><p className="text-[11px] text-[var(--muted)]">{label}</p><p className={`tnum mt-2 text-lg font-medium ${tone || ""}`}>{value}</p></div>; }
export function HoldingRowActions({ symbol }: { symbol: string; shares: number }) { const { openQuickTrade } = useSim(); return <button className="btn btn-xs" onClick={() => openQuickTrade(symbol, "sell")}>Trade <Icon name="chevronRight" size={12}/></button>; }
export function SentimentMeter({ value, count }: { value: number; count: number }) { return <div className="note">{count} fictional stories · News sentiment is {sentimentLabel(value).toLowerCase()}.</div>; }
export function DeltaText({ value }: { value: number }) { return <span className={value >= 0 ? "up" : "down"}>{fmtSignedPct(value)}</span>; }
