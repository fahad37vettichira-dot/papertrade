"use client";

import { useEffect, useMemo, useState } from "react";
import { CandlestickChart, LineChart } from "@/components/charts";
import { Icon } from "@/components/icons";
import { Empty, InfoRow, Pill, Segmented } from "@/components/ui";
import { SignalPill } from "@/components/widgets";
import { fmtCompactNum, fmtMoney, fmtPct, fmtShares } from "@/lib/format";
import type { RealCandle, RealMarketAnalysis, ForecastHorizonKey, ForecastPoint, ModelForecast, IndicatorReading } from "@/lib/realMarket";

const HORIZONS: Array<{ value: ForecastHorizonKey; label: string }> = [
  { value: "1D", label: "1 day" },
  { value: "1W", label: "1 week" },
  { value: "1M", label: "1 month" },
  { value: "3M", label: "3 months" },
];
type PredictionRecord = {
  id: number;
  modelId: string;
  horizon: string;
  forecastDate: string;
  targetDate: string;
  referencePrice: number;
  predictedLow: number;
  predictedMedian: number;
  predictedHigh: number;
  actualPrice: number | null;
  errorPct: number | null;
  directionCorrect: boolean | null;
  evaluatedAt: string | null;
};
type ResearchData = RealMarketAnalysis & { predictionHistory: PredictionRecord[] };

const chartRanges = [
  { value: "1M", days: 31, label: "1M" },
  { value: "1Y", days: 366, label: "1Y" },
  { value: "5Y", days: 5 * 366, label: "5Y" },
  { value: "10Y", days: 0, label: "10Y" },
] as const;

function dateLabel(date: string, full = false) {
  return new Date(`${date}T12:00:00Z`).toLocaleDateString("en-US", full ? { year: "numeric", month: "short", day: "numeric", timeZone: "UTC" } : { month: "short", day: "numeric", timeZone: "UTC" });
}

function ModelRange({ point, current }: { point: ForecastPoint; current: number }) {
  return <div className="min-w-[105px]"><p className="tnum text-[11px] font-medium">{fmtMoney(point.median)}</p><p className="tnum mt-1 text-[9px] text-[var(--muted)]">{fmtMoney(point.low)}–{fmtMoney(point.high)}</p><p className={`tnum mt-1 text-[9px] ${point.median >= current ? "up" : "down"}`}>{fmtPct(point.probabilityUp, 0)} chance higher (model)</p></div>;
}

function IndicatorRow({ item, label }: { item: IndicatorReading; label: string }) {
  return <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-1 border-b border-[var(--line)] py-3 last:border-0"><div className="flex min-w-[125px] items-center gap-2"><span className={`dot ${item.signal === "Bullish" ? "text-[#6b9a68]" : item.signal === "Bearish" ? "text-[#d49382]" : "text-[#c6ad76]"}`}/><span className="text-xs font-medium">{label}</span></div><span className="hint min-w-0 flex-1 text-right">{item.explanation}</span><span className={`min-w-[62px] text-right text-[10px] ${item.signal === "Bullish" ? "up" : item.signal === "Bearish" ? "down" : "text-[var(--muted)]"}`}>{item.signal}</span></div>;
}

export function MarketResearch({ symbol }: { symbol: string }) {
  const [data, setData] = useState<ResearchData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<{ symbol: string; message: string } | null>(null);
  const [retry, setRetry] = useState(0);
  const [range, setRange] = useState<(typeof chartRanges)[number]["value"]>("1Y");
  const [style, setStyle] = useState<"line" | "candle">("line");
  const [horizon, setHorizon] = useState<ForecastHorizonKey>("3M");
  const [modelFilter, setModelFilter] = useState("all");

  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/market-data/${encodeURIComponent(symbol)}`, { signal: controller.signal, cache: "no-store" })
      .then(async response => {
        const body = await response.json();
        if (!response.ok) throw new Error(body.error || "Historical market data is unavailable.");
        return body as ResearchData;
      })
      .then(result => { setData(result); setError(null); })
      .catch(reason => { if (reason?.name !== "AbortError") setError({ symbol, message: reason instanceof Error ? reason.message : "Real history could not be loaded." }); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [symbol, retry]);

  const displayedBars = useMemo(() => {
    if (!data) return [];
    const selected = chartRanges.find(option => option.value === range)!;
    const latestMs = new Date(`${data.latestDate}T12:00:00Z`).getTime();
    const cutoff = selected.days === 0 ? 0 : latestMs - selected.days * 86_400_000;
    const filtered = data.history.filter(bar => new Date(`${bar.date}T12:00:00Z`).getTime() >= cutoff);
    const sample = Math.max(1, Math.ceil(filtered.length / (style === "candle" ? 95 : 300)));
    return filtered.filter((_, index) => index % sample === 0 || index === filtered.length - 1);
  }, [data, range, style]);

  if ((!data || data.symbol !== symbol) && error?.symbol !== symbol) return <section className="panel p-6" aria-live="polite"><p className="card-label">Real market history</p><div className="mt-3 flex h-44 flex-col items-center justify-center gap-2"><span className="h-5 w-5 animate-spin rounded-full border-2 border-[#dbe7d2] border-t-[#739a58]"/><p className="text-xs text-[var(--muted)]">Loading up to 10 years of actual daily history for {symbol}…</p></div></section>;
  if (!data || data.symbol !== symbol) return <section className="panel overflow-hidden"><div className="flex items-start gap-3 border-b border-[var(--line)] bg-[#fffaf6] p-5"><Icon name="info" size={17} className="mt-0.5 shrink-0 text-[#bd826e]"/><div><h2 className="text-sm font-medium">Real market history isn’t available right now.</h2><p className="hint mt-1">{error?.message} No fabricated prices or forecasts are being shown. Your paper-trading account is still available and unchanged.</p><button type="button" className="btn btn-sm mt-3" onClick={() => setRetry(x => x + 1)}>Try real data again</button></div></div><div className="px-5 py-4 text-[10px] text-[var(--muted)]">Your practice price is simulated separately; it does not change to an actual market quote.</div></section>;

  const historyLabels = displayedBars.map(bar => dateLabel(bar.date));
  const chartBars = displayedBars.map((bar, index) => ({ day: index, open: bar.open, high: bar.high, low: bar.low, close: bar.close, volume: bar.volume }));
  const chosenModel = data.forecasts.find(model => model.id === modelFilter);
  const tableModels = chosenModel ? [chosenModel] : data.forecasts;
  const current = data.latestClose;
  const signal = data.signal;
  const actionTone = signal.label.includes("Buy") ? "up" : signal.label.includes("Sell") ? "down" : "warn";
  const valuation = signal.label.includes("Sell") ? "Sell / reduce (paper only)" : signal.label.includes("Buy") ? "Buy / add (paper only)" : "Hold / wait";

  return <section className="panel overflow-hidden">
    <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--line)] px-6 py-5">
      <div><div className="flex flex-wrap items-center gap-2"><h2 className="panel-title">Real market history & model outlook</h2><Pill tone="accent">Reported daily data</Pill></div><p className="hint mt-1">{data.companyName} · {data.coverageStart} to {dateLabel(data.latestDate, true)} · {data.barsReturned.toLocaleString()} daily sessions</p><p className="mt-1 text-[10px] text-[var(--muted)]">Source: {data.source}. This unofficial feed may be delayed or unavailable; not a live quote.</p></div>
      <div className="text-right"><p className="card-label">Latest adjusted daily close · {data.currency}</p><p className="tnum mt-1 text-xl font-medium">{fmtMoney(current)}</p><p className="hint mt-1">as of {dateLabel(data.latestDate, true)}</p></div>
    </div>

    <div className="px-6 pt-5">
      <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-xs font-medium">Actual daily stock-price history</p><p className="hint mt-1">This historical chart is separate from the practice-market quote above.</p></div><div className="flex flex-wrap items-center gap-2"><Segmented options={chartRanges.map(o => ({ value: o.value, label: o.label }))} value={range} onChange={setRange}/><details className="relative"><summary className="btn btn-sm !cursor-pointer">{style === "line" ? "Line chart" : "Candlesticks"}<Icon name="chevronDown" size={12}/></summary><div className="absolute right-0 top-10 z-20 min-w-36 rounded-xl border border-[var(--line)] bg-white p-2 shadow-lg"><button className="nav-item w-full" onClick={() => setStyle("line")}>Line chart</button><button className="nav-item w-full" onClick={() => setStyle("candle")}>Candlesticks</button></div></details></div></div>
      <div className="mt-4">{style === "line" ? <LineChart series={[{ name: "Actual daily close", values: displayedBars.map(b => b.adjustedClose), color: "#739a58", fill: true }]} labels={historyLabels} height={230} formatValue={v => fmtMoney(v, 0)} formatTooltip={fmtMoney}/> : <CandlestickChart bars={chartBars} labels={historyLabels} height={230}/>}</div>
    </div>

    <div className="mt-5 border-t border-[var(--line)] px-6 py-5">
      <div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex flex-wrap items-center gap-2"><h3 className="text-sm font-medium">A data-based paper-trading signal</h3><SignalPill label={signal.label}/></div><p className="hint mt-1">Calculated from actual daily prices and indicators—not randomized or hardcoded.</p></div><div className="rounded-lg bg-[#f6f8f3] px-3 py-2 text-right"><p className="text-[9px] text-[var(--muted)]">Agreement across five directional models</p><p className="tnum text-base font-medium text-[#5e8558]">{signal.modelAgreement}%</p></div></div>
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">{[{ label: "Reference entry", value: signal.suggestedEntry }, { label: "3-month target", value: signal.target }, { label: "Protective stop", value: signal.stopLoss }, { label: "90% simulated range · low", value: signal.expectedRangeLow }, { label: "90% simulated range · high", value: signal.expectedRangeHigh }].map(metric => <div key={metric.label} className="rounded-lg border border-[var(--line)] bg-white p-3"><p className="text-[9px] leading-relaxed text-[var(--muted)]">{metric.label}</p><p className="tnum mt-1 text-[13px] font-medium">{fmtMoney(metric.value)}</p></div>)}<div className="rounded-lg border border-[var(--line)] bg-white p-3"><p className="text-[9px] text-[var(--muted)]">Risk / reward</p><p className="tnum mt-1 text-[13px] font-medium">1 : {signal.riskReward.toFixed(2)}</p></div></div>
      <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1"><Pill tone={actionTone}>{valuation}</Pill><span className="hint">This is an educational model output using the last completed actual trading session; it is not a broker order or personal financial advice.</span></div>
      <div className="mt-4 grid gap-5 md:grid-cols-2"><div><p className="eyebrow mb-1">Why this signal?</p><ul className="space-y-2">{signal.reasons.map((reason, index) => <li key={index} className="hint flex gap-2"><span className="text-[#86a471]">•</span><span>{reason}</span></li>)}</ul></div><div><p className="eyebrow mb-1">Indicator signals</p><div>{signal.indicatorSummary.map((item, index) => <p className="hint mt-1" key={index}>{item}</p>)}</div></div></div>
    </div>

    <details className="border-t border-[var(--line)]">
      <summary className="flex flex-wrap items-center gap-3 px-6 py-4 text-xs font-medium"><span>Compare prediction methods</span><span className="pill">Actual history only</span><span className="ml-auto text-[10px] text-[var(--muted)]">{data.forecasts.length} methods</span></summary>
      <div className="px-6 pb-6">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3"><p className="hint">Each range is a model estimate, not a promise. Historical accuracy is a separate five-session walk-forward check.</p><div className="flex flex-wrap items-center gap-2"><Segmented options={HORIZONS} value={horizon} onChange={setHorizon}/><select className="select !w-auto !min-h-[34px] !py-1.5 !text-[10px]" aria-label="Filter prediction model" value={modelFilter} onChange={e => setModelFilter(e.target.value)}><option value="all">All models</option>{data.forecasts.map(model => <option key={model.id} value={model.id}>{model.name}</option>)}</select></div></div>
        <div className="table-scroll"><table className="data-table"><thead><tr><th>Method</th><th>Possible range · median</th><th>5-day historical test</th></tr></thead><tbody>{tableModels.map(model => { const point = model.forecasts[horizon]; return <tr key={model.id}><td className="min-w-[175px]"><p className="text-xs font-medium">{model.name}</p><p className="mt-1 max-w-[300px] text-[9px] leading-relaxed text-[var(--muted)]">{model.method}</p></td><td><ModelRange point={point} current={current}/></td><td className="min-w-[105px]">{model.accuracy5d === null ? <span className="text-[10px] text-[var(--muted)]">Not a direction model</span> : <><p className="tnum text-xs font-medium">{fmtPct(model.accuracy5d, 0)}</p><p className="mt-1 text-[9px] text-[var(--muted)]">{model.validationSamples} out-of-sample forecasts</p></>}</td></tr>; })}</tbody></table></div>
        <p className="hint mt-4">{data.validation.method} {data.validation.warning}</p>
        <p className="mt-2 text-[9px] leading-relaxed text-[var(--muted)]">This build includes Monte Carlo, linear regression, a trained random-forest regressor, ARIMA(1,1,0), a recent-trend baseline and GARCH(1,1) volatility. XGBoost and LSTM are not wired to a validated training service here, so no results for those methods are invented.</p>
      </div>
    </details>

    <details className="border-t border-[var(--line)]" open>
      <summary className="flex items-center gap-3 px-6 py-4 text-xs font-medium">Prediction accuracy tracker <span className="ml-auto text-[10px] text-[var(--muted)]">{data.predictionHistory.filter(row => row.actualPrice !== null).length} saved forecasts evaluated</span></summary>
      <div className="px-6 pb-6">
        <p className="hint">Two checks are shown: a chronological five-session walk-forward test on historical data, and saved forecasts that are scored when their target date arrives.</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {data.forecasts.map(model => {
            const saved = data.predictionHistory.filter(row => row.modelId === model.id && row.actualPrice !== null);
            const hitRate = saved.length ? saved.filter(row => row.directionCorrect).length / saved.length : null;
            const mae = saved.length ? saved.reduce((sum, row) => sum + (row.errorPct ?? 0), 0) / saved.length : null;
            const coverage = saved.length ? saved.filter(row => row.actualPrice! >= row.predictedLow && row.actualPrice! <= row.predictedHigh).length / saved.length : null;
            return <div key={model.id} className="rounded-xl border border-[var(--line)] bg-white p-4">
              <div className="flex items-center justify-between gap-2"><p className="text-xs font-medium">{model.name}</p>{model.accuracy5d !== null && <Pill tone={model.accuracy5d >= 0.55 ? "up" : model.accuracy5d < 0.45 ? "down" : "neutral"}>{fmtPct(model.accuracy5d, 0)} 5-day test</Pill>}</div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-[#eef2ea]"><div className="h-full rounded-full bg-[#7aa56d]" style={{ width: `${Math.round((model.accuracy5d ?? 0) * 100)}%` }}/></div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-[10px] text-[var(--muted)]"><span>Walk-forward<br/><strong className="tnum text-[11px] text-[var(--text)]">{model.validationSamples || "—"}</strong></span><span>Saved hit rate<br/><strong className="tnum text-[11px] text-[var(--text)]">{hitRate === null ? "—" : fmtPct(hitRate, 0)}</strong></span><span>Saved MAE<br/><strong className="tnum text-[11px] text-[var(--text)]">{mae === null ? "—" : fmtPct(mae, 1)}</strong></span></div>
              <p className="mt-2 text-[9px] text-[var(--muted)]">{saved.length ? `${saved.length} saved forecasts scored · range coverage ${coverage === null ? "—" : fmtPct(coverage, 0)}` : "No saved forecasts have matured yet."}</p>
            </div>;
          })}
        </div>
        <p className="hint mt-4">Accuracy is measured only on completed historical tests. A higher historical hit rate does not guarantee future accuracy or profits.</p>
      </div>
    </details>

    <details className="border-t border-[var(--line)]">
      <summary className="flex items-center gap-3 px-6 py-4 text-xs font-medium">Previous model forecasts vs. actual closes <span className="ml-auto text-[10px] text-[var(--muted)]">{data.predictionHistory.filter(row => row.actualPrice !== null).length} evaluated</span></summary>
      <div className="px-6 pb-6">
        {data.predictionHistory.some(row => row.actualPrice !== null) ? <div className="table-scroll"><table className="data-table"><thead><tr><th>Model / horizon</th><th>Forecast date</th><th>Target date</th><th className="text-right">Predicted median</th><th className="text-right">Actual close</th><th className="text-right">Absolute error</th><th>Direction</th></tr></thead><tbody>{data.predictionHistory.filter(row => row.actualPrice !== null).slice(0, 35).map(row => <tr key={row.id}><td><span className="text-[11px] font-medium">{data.forecasts.find(model => model.id === row.modelId)?.name || row.modelId}</span><span className="ml-1 text-[9px] text-[var(--muted)]">{row.horizon}</span></td><td className="text-[10px] text-[var(--muted)]">{dateLabel(row.forecastDate, true)}</td><td className="text-[10px] text-[var(--muted)]">{dateLabel(row.targetDate, true)}</td><td className="tnum text-right text-xs">{fmtMoney(row.predictedMedian)}</td><td className="tnum text-right text-xs">{fmtMoney(row.actualPrice!)}</td><td className="tnum text-right text-xs">{row.errorPct === null ? "—" : fmtPct(row.errorPct, 1)}</td><td><Pill tone={row.directionCorrect ? "up" : "down"}>{row.directionCorrect ? "Correct" : "Incorrect"}</Pill></td></tr>)}</tbody></table></div> : <div className="rounded-lg bg-[#f7f8f3] p-4"><p className="text-xs font-medium">Forecast tracking starts today.</p><p className="hint mt-2">The first forecast for each model and horizon is saved once per actual data date. When that target date has passed, the next visit compares the estimate with the first available actual close within seven calendar days. As a result, this table may be empty until a forecast matures.</p></div>}
        <p className="hint mt-4">This is a historical model audit, not a win-rate promise. Each forecast is one observation; results can be noisy and depend on the selected date range.</p>
      </div>
    </details>

    <details className="border-t border-[var(--line)]">
      <summary className="flex items-center gap-3 px-6 py-4 text-xs font-medium">Technical indicators, levels & volume <span className="ml-auto text-[10px] text-[var(--muted)]">Optional</span></summary>
      <div className="grid gap-6 px-6 pb-6 md:grid-cols-2"><div>{[["RSI (14)", data.indicators.rsi14], ["MACD", data.indicators.macd], ["Moving averages", data.indicators.movingAverages], ["Bollinger Bands", data.indicators.bollinger], ["VWAP · 20 sessions", data.indicators.vwap20], ["Stochastic RSI", data.indicators.stochasticRsi], ["ADX and +DI / −DI", data.indicators.adx14], ["Supertrend", data.indicators.supertrend], ["Volume", data.indicators.volume]].map(([label, reading]) => <IndicatorRow key={label as string} label={label as string} item={reading as IndicatorReading}/>)}</div><div><InfoRow label="Trend from daily price history" value={data.indicators.trend}/><InfoRow label="Recent pattern" value={data.indicators.pattern}/><InfoRow label="Nearest support estimate" value={fmtMoney(data.indicators.support)}/><InfoRow label="Nearest resistance estimate" value={fmtMoney(data.indicators.resistance)}/><InfoRow label="Average true range (14)" value={fmtMoney(data.indicators.atr14)}/><InfoRow label="Annualized historical volatility" value={fmtPct(data.indicators.annualizedVolatility, 1)}/><InfoRow label="Average daily volume (20 sessions)" value={fmtCompactNum(data.indicators.averageDailyVolume20)}/><div className="mt-4 rounded-lg bg-[#f7f8f3] p-3"><p className="text-[10px] font-medium">52-week Fibonacci reference levels</p>{data.indicators.fibLevels.map(level => <InfoRow key={level.label} label={level.label} value={fmtMoney(level.price)}/>)}</div></div></div>
    </details>

    <div className="border-t border-[var(--line)] bg-[#fafbf8] px-6 py-4"><p className="text-[10px] text-[var(--muted)]">Daily history is supplied by the Yahoo Finance chart endpoint. It is an unofficial, possibly delayed feed, may contain corporate-action adjustments, and is not guaranteed. Historical prices do not guarantee future results.</p></div>
  </section>;
}
