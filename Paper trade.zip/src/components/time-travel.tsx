"use client";

import { useState } from "react";
import { Icon } from "@/components/icons";
import { useSim, SPEED_OPTIONS } from "@/components/providers";
import { fmtDayMedium } from "@/lib/time";

export const TIME_JUMPS = [{ value: 1, label: "1 trading day" }, { value: 5, label: "1 week" }, { value: 21, label: "1 month" }, { value: 252, label: "1 year" }, { value: 1260, label: "5 years" }];

export function TimeTravelCard({ dialog = false }: { dialog?: boolean }) {
  const { snapshot, advance, ticking, busy, setSpeed } = useSim();
  const [days, setDays] = useState(21);
  const [confirm, setConfirm] = useState(false);
  const selection = TIME_JUMPS.find(j => j.value === days)!;
  const skip = async () => {
    if (days >= 252 && !confirm) { setConfirm(true); return; }
    if (snapshot?.market.speed) await setSpeed(0);
    await advance(days);
    setConfirm(false);
  };
  return <div className={dialog ? "" : "panel time-card p-[22px]"}>
    {!dialog && <div className="mb-4 flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-lg bg-[#f3f0f7] text-[#a192b6]"><Icon name="clock" size={17}/></span><span className="text-[13px] font-medium">A little time travel</span></div>}
    <p className="hint">See how your investments change without waiting for the real world.</p>
    <div className="field mt-4"><label className="label" htmlFor={dialog ? "time-dialog" : "time-card"}>Skip ahead by</label><select id={dialog ? "time-dialog" : "time-card"} className="select" value={days} disabled={ticking} onChange={e => { setDays(Number(e.target.value)); setConfirm(false); }}>{TIME_JUMPS.map(j => <option key={j.value} value={j.value}>{j.label}</option>)}</select></div>
    {confirm && <p className="note mt-3" role="status">Move ahead {selection.label}? This can change prices and fill open orders. You can’t rewind the simulation. Years are approximate, using 252 trading days each.</p>}
    <button type="button" onClick={() => void skip()} disabled={busy || ticking || !snapshot} className={`btn mt-3 w-full ${dialog || confirm ? "btn-primary" : "btn-lime"}`}>{ticking ? "Moving through time…" : confirm ? `Yes, skip ${selection.label}` : "Skip ahead"}<Icon name="arrowUpRight" size={15}/></button>
    {confirm && <button type="button" onClick={() => setConfirm(false)} className="btn btn-ghost mt-1 w-full">Cancel</button>}
    <p className="mt-4 flex items-center justify-between text-[10px] text-[var(--muted)]"><span className="flex items-center gap-1.5"><span className={`dot ${snapshot?.market.speed ? "dot-live text-[#76a767]" : "text-[#b9c2b7]"}`}/>{snapshot?.market.speed ? "Auto-running" : "Paused"}</span><span>{snapshot ? fmtDayMedium(snapshot.market.day, snapshot.market.epoch) : "Loading…"}</span></p>
    {dialog && <details className="mt-5 border-t border-[var(--line)] pt-4"><summary className="cursor-pointer text-xs text-[var(--muted)]">Run time automatically instead</summary><div className="field mt-4"><label className="label" htmlFor="auto-time-speed">Automatic speed</label><select id="auto-time-speed" className="select" value={snapshot?.market.speed || 0} disabled={busy} onChange={e => void setSpeed(Number(e.target.value))}>{SPEED_OPTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}{snapshot?.market.speed && !SPEED_OPTIONS.some(s => s.value === snapshot.market.speed) ? <option value={snapshot.market.speed}>Current speed</option> : null}</select><p className="hint">Prices move while this tab is visible. Opening a trade or adding funds pauses time.</p></div></details>}
  </div>;
}
