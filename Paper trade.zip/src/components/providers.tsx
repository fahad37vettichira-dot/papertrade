"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Snapshot } from "@/lib/api-types";

export type ToastItem = { id: number; message: string; tone: "up" | "down" | "info" };
export type ActionResult = { ok: boolean; message: string };
export type QuickTradePreset = { symbol: string; side?: "buy" | "sell" } | null;
type TradeInput = { symbol: string; side: "buy" | "sell"; qty: number; orderType: "market" | "limit" | "stop"; limitPrice?: number };
type Settings = { taxEnabled?: boolean; taxRate?: number; longTermTaxRate?: number };
type Reply = { snapshot: Snapshot; message?: string; watched?: boolean; advanced?: number };
type CashInput = { action: "deposit" | "withdraw"; amount: number; settleTax?: boolean };

type SimContextValue = {
  snapshot: Snapshot | null;
  loading: boolean;
  ticking: boolean;
  busy: boolean;
  error: string | null;
  toasts: ToastItem[];
  quickTrade: QuickTradePreset;
  funds: "deposit" | "withdraw" | null;
  timeOpen: boolean;
  openQuickTrade: (symbol?: string, side?: "buy" | "sell") => void;
  closeQuickTrade: () => void;
  openCash: (action?: "deposit" | "withdraw") => void;
  closeCash: () => void;
  openTime: () => void;
  closeTime: () => void;
  notify: (message: string, tone?: ToastItem["tone"]) => void;
  dismissToast: (id: number) => void;
  refresh: () => Promise<void>;
  advance: (days: number, triggerEvent?: boolean) => Promise<void>;
  setSpeed: (speed: number) => Promise<void>;
  trade: (input: TradeInput) => Promise<ActionResult>;
  cash: (input: CashInput) => Promise<ActionResult>;
  watch: (symbol: string) => Promise<void>;
  cancelOrder: (id: number) => Promise<void>;
  updateSettings: (input: Settings) => Promise<ActionResult>;
  reset: () => Promise<void>;
};

const SimContext = createContext<SimContextValue | null>(null);
export const SPEED_OPTIONS = [
  { value: 0, label: "Paused", hint: "Take your time. Prices stay where they are." },
  { value: 1, label: "Day by day", hint: "One trading day every 3 seconds" },
  { value: 21, label: "Month by month", hint: "One trading month every 3 seconds" },
] as const;

async function fetchJson(url: string, body?: unknown, method = "POST"): Promise<Reply> {
  const response = await fetch(url, { method, cache: "no-store", ...(body !== undefined ? { headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {}) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

export function SimProvider({ children }: { children: ReactNode }) {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [ticking, setTicking] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [quickTrade, setQuickTrade] = useState<QuickTradePreset>(null);
  const [funds, setFunds] = useState<"deposit" | "withdraw" | null>(null);
  const [timeOpen, setTimeOpen] = useState(false);
  const latest = useRef<Snapshot | null>(null);
  const queue = useRef<Promise<unknown>>(Promise.resolve());
  const tickingRef = useRef(false);
  const id = useRef(0);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  const dismissToast = useCallback((toastId: number) => setToasts(prev => prev.filter(t => t.id !== toastId)), []);
  const notify = useCallback((message: string, tone: ToastItem["tone"] = "info") => {
    const toastId = ++id.current;
    setToasts(prev => [...prev.slice(-2), { id: toastId, message, tone }]);
    timers.current.push(setTimeout(() => dismissToast(toastId), 5500));
  }, [dismissToast]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  // A single queue prevents stale responses from overwriting newer account changes.
  const request = useCallback((url: string, body?: unknown, method = "POST") => {
    const next = queue.current.then(async () => {
      setBusy(true);
      try {
        const data = await fetchJson(url, body, method);
        if (data.snapshot) { latest.current = data.snapshot; setSnapshot(data.snapshot); }
        setError(null);
        return data;
      } finally { setBusy(false); }
    });
    queue.current = next.catch(() => undefined);
    return next;
  }, []);

  const refresh = useCallback(async () => {
    try {
      const next = queue.current.then(async () => {
        const response = await fetch("/api/state", { cache: "no-store" });
        if (!response.ok) throw new Error("We couldn’t load your account. Please try again.");
        const data: Snapshot = await response.json();
        latest.current = data;
        setSnapshot(data);
        setError(null);
      });
      queue.current = next.catch(() => undefined);
      await next;
    } catch (err) { setError(err instanceof Error ? err.message : "Connection unavailable."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  const advance = useCallback(async (days: number, triggerEvent = false, quiet = false) => {
    if (tickingRef.current) return;
    tickingRef.current = true;
    setTicking(true);
    const previousDay = latest.current?.market.day ?? 0;
    try {
      const result = await request("/api/tick", { days, triggerEvent });
      if (triggerEvent) {
        const event = result.snapshot.news.find(n => n.kind === "event" && n.day > previousDay);
        notify(event ? `Surprise event: ${event.headline}` : "A surprise event has moved the market. See Market news.", "info");
      } else if (days > 1 && !quiet) {
        const years = days >= 252 ? `${Math.round(days / 252)} year${days >= 504 ? "s" : ""}` : days >= 21 ? `${Math.round(days / 21)} month${days >= 42 ? "s" : ""}` : `${days} trading days`;
        notify(`You’ve skipped ahead ${years}. Your portfolio is up to date.`, "info");
      }
    } catch (err) { notify(err instanceof Error ? err.message : "Couldn’t move time forward.", "down"); }
    finally { setTicking(false); tickingRef.current = false; }
  }, [request, notify]);

  const setSpeed = useCallback(async (speed: number) => {
    try { await request("/api/settings", { speed }); }
    catch (err) { notify(err instanceof Error ? err.message : "Couldn’t change the clock.", "down"); }
  }, [request, notify]);
  const speed = snapshot?.market.speed || 0;
  useEffect(() => {
    if (!speed) return;
    const timer = setInterval(() => {
      if (document.hidden || tickingRef.current) return;
      void advance(speed, false, true);
    }, 3000);
    return () => clearInterval(timer);
  }, [speed, advance]);

  const action = useCallback(async (url: string, input: unknown, fallback: string): Promise<ActionResult> => {
    try {
      const data = await request(url, input);
      const message = data.message || fallback;
      notify(message, "up");
      return { ok: true, message };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Please try again.";
      notify(message, "down");
      return { ok: false, message };
    }
  }, [request, notify]);
  const trade = useCallback((input: TradeInput) => action("/api/trade", input, "Your virtual trade is complete."), [action]);
  const cash = useCallback((input: CashInput) => action("/api/cash", input, "Your virtual balance is updated."), [action]);
  const watch = useCallback(async (symbol: string) => {
    try { const data = await request("/api/watchlist", { symbol }); notify(`${symbol} ${data.watched ? "added to" : "removed from"} your watchlist.`); }
    catch (err) { notify(err instanceof Error ? err.message : "Couldn’t update your watchlist.", "down"); }
  }, [request, notify]);
  const cancelOrder = useCallback(async (orderId: number) => { await action("/api/orders", { id: orderId }, "Order cancelled."); }, [action]);
  const updateSettings = useCallback(async (input: Settings): Promise<ActionResult> => {
    try { await request("/api/settings", input); return { ok: true, message: "Settings saved." }; }
    catch (err) { const message = err instanceof Error ? err.message : "Couldn’t save settings."; notify(message, "down"); return { ok: false, message }; }
  }, [request, notify]);
  const reset = useCallback(async () => {
    try { await request("/api/settings", undefined, "DELETE"); notify("Fresh start! Your example account has been restored."); }
    catch (err) { notify(err instanceof Error ? err.message : "Reset failed.", "down"); }
  }, [request, notify]);

  const openQuickTrade = useCallback((symbol = "AAPL", side: "buy" | "sell" = "buy") => {
    if (latest.current?.market.speed) void setSpeed(0);
    setQuickTrade({ symbol, side });
  }, [setSpeed]);
  const closeQuickTrade = useCallback(() => setQuickTrade(null), []);
  const openCash = useCallback((type: "deposit" | "withdraw" = "deposit") => { if (latest.current?.market.speed) void setSpeed(0); setFunds(type); }, [setSpeed]);
  const closeCash = useCallback(() => setFunds(null), []);
  const openTime = useCallback(() => setTimeOpen(true), []);
  const closeTime = useCallback(() => setTimeOpen(false), []);

  const value = useMemo(() => ({ snapshot, loading, ticking, busy, error, toasts, quickTrade, funds, timeOpen, openQuickTrade, closeQuickTrade, openCash, closeCash, openTime, closeTime, notify, dismissToast, refresh, advance, setSpeed, trade, cash, watch, cancelOrder, updateSettings, reset }), [snapshot, loading, ticking, busy, error, toasts, quickTrade, funds, timeOpen, openQuickTrade, closeQuickTrade, openCash, closeCash, openTime, closeTime, notify, dismissToast, refresh, advance, setSpeed, trade, cash, watch, cancelOrder, updateSettings, reset]);
  return <SimContext.Provider value={value}>{children}</SimContext.Provider>;
}

export function useSim(): SimContextValue { const context = useContext(SimContext); if (!context) throw new Error("Use SimProvider to access your practice account."); return context; }
