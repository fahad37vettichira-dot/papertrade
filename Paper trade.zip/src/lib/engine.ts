export const DAYS_PER_YEAR = 252;

/* ------------------------------------------------------------------ random */

export function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function gaussian(rng: () => number): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/* ----------------------------------------------------------------- regimes */

export type Regime = "bull" | "bear" | "volatile" | "crash";

export const REGIME_META: Record<
  Regime,
  { label: string; drift: number; volMul: number; tone: string; blurb: string }
> = {
  bull: {
    label: "Bull Expansion",
    drift: 0.095,
    volMul: 0.88,
    tone: "up",
    blurb: "Trend followers in control; pullbacks find institutional demand and breadth expands.",
  },
  bear: {
    label: "Bear Contraction",
    drift: -0.11,
    volMul: 1.18,
    tone: "down",
    blurb: "Distribution days dominate, rallies fade into resistance and leadership narrows.",
  },
  volatile: {
    label: "High Volatility",
    drift: 0.015,
    volMul: 1.75,
    tone: "warn",
    blurb: "Two-way intraday swings are elevated as macro catalysts drive positioning.",
  },
  crash: {
    label: "Risk-Off Shock",
    drift: -0.36,
    volMul: 2.25,
    tone: "down",
    blurb: "Liquidity thins and cross-asset correlations spike during rapid deleveraging.",
  },
};

const REGIME_TRANSITIONS: Record<Regime, Array<[Regime, number]>> = {
  bull: [
    ["bull", 0.9935],
    ["volatile", 0.0045],
    ["bear", 0.002],
  ],
  bear: [
    ["bear", 0.992],
    ["bull", 0.005],
    ["volatile", 0.0025],
    ["crash", 0.0005],
  ],
  volatile: [
    ["volatile", 0.968],
    ["bull", 0.022],
    ["bear", 0.008],
    ["crash", 0.002],
  ],
  crash: [
    ["crash", 0.86],
    ["volatile", 0.1],
    ["bull", 0.04],
  ],
};

export function stepRegime(current: Regime, rng: () => number): Regime {
  const roll = rng();
  let acc = 0;
  for (const [next, p] of REGIME_TRANSITIONS[current]) {
    acc += p;
    if (roll <= acc) return next;
  }
  return current;
}

/* -------------------------------------------------------------- indicators */

export function sma(values: number[], period: number): number | null {
  if (values.length < period) return null;
  let sum = 0;
  for (let i = values.length - period; i < values.length; i++) sum += values[i];
  return sum / period;
}

export function bollingerBands(
  values: number[],
  period = 20,
  mult = 2,
): { mid: number; upper: number; lower: number } | null {
  if (values.length < period) return null;
  const slice = values.slice(-period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((a, b) => a + (b - mean) ** 2, 0) / period;
  const sd = Math.sqrt(variance);
  return {
    mid: mean,
    upper: mean + mult * sd,
    lower: Math.max(0.01, mean - mult * sd),
  };
}

export function rsi(values: number[], period = 14): number | null {
  if (values.length < period + 1) return null;
  let gains = 0;
  let losses = 0;
  for (let i = values.length - period; i < values.length; i++) {
    const diff = values[i] - values[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / period / (losses / period);
  return 100 - 100 / (1 + rs);
}

export function dailyReturns(closes: number[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    out.push(closes[i] / closes[i - 1] - 1);
  }
  return out;
}

export function annualizedVol(closes: number[]): number {
  const rets = dailyReturns(closes);
  if (rets.length < 5) return 0.3;
  const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
  const variance = rets.reduce((a, b) => a + (b - mean) ** 2, 0) / (rets.length - 1);
  return Math.sqrt(variance) * Math.sqrt(DAYS_PER_YEAR);
}

export function maxDrawdown(values: number[]): number {
  let peak = values[0] ?? 0;
  let worst = 0;
  for (const v of values) {
    if (v > peak) peak = v;
    if (peak > 0) worst = Math.min(worst, v / peak - 1);
  }
  return worst;
}

export function sharpeRatio(returns: number[], riskFree = 0.04): number {
  if (returns.length < 10) return 0;
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((a, b) => a + (b - mean) ** 2, 0) / (returns.length - 1);
  const sd = Math.sqrt(variance);
  if (sd === 0) return 0;
  return (mean * DAYS_PER_YEAR - riskFree) / (sd * Math.sqrt(DAYS_PER_YEAR));
}

export function periodReturn(values: number[], days: number): number {
  if (values.length < 2) return 0;
  const from = values[Math.max(0, values.length - 1 - days)];
  const to = values[values.length - 1];
  if (!from) return 0;
  return to / from - 1;
}

export function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (sorted[base + 1] !== undefined) {
    return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
  }
  return sorted[base];
}

export function downsample<T>(arr: T[], maxPoints: number): T[] {
  if (arr.length <= maxPoints) return arr;
  const step = arr.length / maxPoints;
  const out: T[] = [];
  for (let i = 0; i < maxPoints; i++) {
    out.push(arr[Math.floor(i * step)]);
  }
  return out;
}

/* ------------------------------------------------------------ monte carlo */

export type MonteCarloConfig = {
  startValue: number;
  annualDrift: number;
  annualVol: number;
  beta: number;
  marketVol: number;
  days: number;
  runs: number;
  monthlyContribution?: number;
  seed?: number;
};

export type MonteCarloResult = {
  steps: Array<{ day: number; p5: number; p25: number; p50: number; p75: number; p95: number; mean: number }>;
  terminal: { p5: number; p25: number; p50: number; p75: number; p95: number; mean: number };
  probProfit: number;
  probDouble: number;
  var95: number;
  expectedShortfall: number;
  best: number;
  worst: number;
  histogram: Array<{ from: number; to: number; count: number }>;
  samplePaths: number[][];
  runs: number;
  horizonDays: number;
  startValue: number;
  totalContributed: number;
};

export function monteCarlo(cfg: MonteCarloConfig): MonteCarloResult {
  const runs = clamp(Math.round(cfg.runs), 100, 4000);
  const days = clamp(Math.round(cfg.days), 5, 1305);
  const monthlyContrib = Math.max(0, cfg.monthlyContribution ?? 0);
  const rng = mulberry32(
    cfg.seed ?? hashString(`${cfg.startValue}-${cfg.annualDrift}-${days}-${runs}-${monthlyContrib}`),
  );
  const marketVol = cfg.marketVol ?? 0.18;
  const marketFactor = clamp(cfg.beta * marketVol, -cfg.annualVol, cfg.annualVol);
  const betaPart = marketFactor / Math.sqrt(DAYS_PER_YEAR);
  const idioVar = Math.max(cfg.annualVol ** 2 - marketFactor ** 2, 0);
  const idioPart = Math.sqrt(idioVar) / Math.sqrt(DAYS_PER_YEAR);
  const driftStep = (cfg.annualDrift - cfg.annualVol ** 2 / 2) / DAYS_PER_YEAR;

  const terminals: number[] = [];
  const columns: number[][] = Array.from({ length: days + 1 }, () => []);
  const samples: number[][] = [];
  const sampleCount = 10;
  const totalContributed = cfg.startValue + Math.floor(days / 21) * monthlyContrib;

  for (let r = 0; r < runs; r++) {
    let value = cfg.startValue;
    const path: number[] = [value];
    columns[0].push(value);
    for (let d = 1; d <= days; d++) {
      const shock = driftStep + betaPart * gaussian(rng) + idioPart * gaussian(rng);
      value = Math.max(0.01, value * Math.exp(shock));
      if (monthlyContrib > 0 && d % 21 === 0) value += monthlyContrib;
      columns[d].push(value);
      path.push(value);
    }
    if (samples.length < sampleCount) samples.push(path);
    terminals.push(value);
  }

  const steps = columns.map((values, day) => {
    const sorted = [...values].sort((a, b) => a - b);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return {
      day,
      p5: quantile(sorted, 0.05),
      p25: quantile(sorted, 0.25),
      p50: quantile(sorted, 0.5),
      p75: quantile(sorted, 0.75),
      p95: quantile(sorted, 0.95),
      mean,
    };
  });

  const sortedTerminals = [...terminals].sort((a, b) => a - b);
  const terminal = {
    p5: quantile(sortedTerminals, 0.05),
    p25: quantile(sortedTerminals, 0.25),
    p50: quantile(sortedTerminals, 0.5),
    p75: quantile(sortedTerminals, 0.75),
    p95: quantile(sortedTerminals, 0.95),
    mean: terminals.reduce((a, b) => a + b, 0) / terminals.length,
  };
  const profits = terminals.filter((v) => v > totalContributed).length;
  const doubled = terminals.filter((v) => v > totalContributed * 2).length;
  const cutoff = Math.floor(terminals.length * 0.05);
  const tail = sortedTerminals.slice(0, Math.max(1, cutoff));
  const expectedShortfall = tail.reduce((a, b) => a + b, 0) / tail.length;

  const min = sortedTerminals[0];
  const max = sortedTerminals[sortedTerminals.length - 1];
  const bucketCount = 24;
  const width = (max - min) / bucketCount || 1;
  const histogram = Array.from({ length: bucketCount }, (_, i) => ({
    from: min + i * width,
    to: min + (i + 1) * width,
    count: 0,
  }));
  for (const t of terminals) {
    const idx = clamp(Math.floor((t - min) / width), 0, bucketCount - 1);
    histogram[idx].count += 1;
  }

  return {
    steps,
    terminal,
    probProfit: profits / terminals.length,
    probDouble: doubled / terminals.length,
    var95: Math.max(0, totalContributed - terminal.p5),
    expectedShortfall,
    best: max,
    worst: min,
    histogram,
    samplePaths: samples,
    runs,
    horizonDays: days,
    startValue: cfg.startValue,
    totalContributed,
  };
}

/* --------------------------------------------------------------- AI brain */

export type AiSignalLabel = "Strong Buy" | "Buy" | "Hold" | "Sell" | "Strong Sell";

export type AiFactor = { name: string; score: number; weight: number; note: string };

export type AiSignal = {
  label: AiSignalLabel;
  score: number;
  confidence: number;
  target: number;
  stop: number;
  horizonDays: number;
  expectedReturn: number;
  risk: "Low" | "Moderate" | "High";
  reasons: string[];
  factors: AiFactor[];
  summary: string;
};

export function computeSignal(input: {
  symbol: string;
  name: string;
  price: number;
  closes: number[];
  marketCloses: number[];
  beta: number;
  drift: number;
  vol: number;
  regime: Regime;
  sentiment: number;
  newsCount: number;
  horizonDays?: number;
}): AiSignal {
  const horizonDays = input.horizonDays ?? 30;
  const closes = input.closes;
  const vol = input.vol || annualizedVol(closes);
  const dailyVol = vol / Math.sqrt(DAYS_PER_YEAR);
  const momentum20 = periodReturn(closes, 20);
  const momentum60 = periodReturn(closes, 60);
  const market60 = periodReturn(input.marketCloses, 60);
  const relStrength = momentum60 - market60;
  const rsi14 = rsi(closes, 14) ?? 50;
  const sma20 = sma(closes, 20) ?? input.price;
  const sma50 = sma(closes, 50) ?? input.price;
  const fromHigh = closes.length ? input.price / Math.max(...closes.slice(-252)) - 1 : 0;

  const norm = (value: number, scale: number) => clamp(value / (scale || 1), -1, 1);
  const trendScore = clamp((input.price / sma50 - 1) / (dailyVol * Math.sqrt(50) || 1), -1, 1);
  const momentumScore = norm(momentum20 * 0.6 + momentum60 * 0.4, dailyVol * Math.sqrt(40));
  const rsiScore = clamp((50 - rsi14) / 30, -1, 1);
  const relScore = norm(relStrength, dailyVol * Math.sqrt(60));
  const sentimentScore = clamp(input.sentiment, -1, 1);
  const valuationScore = clamp((fromHigh + 0.12) / 0.32, -1, 1);

  const regimeWeights: Record<Regime, number[]> = {
    bull: [0.3, 0.28, 0.1, 0.16, 0.08, 0.08],
    bear: [0.22, 0.14, 0.16, 0.1, 0.2, 0.18],
    volatile: [0.18, 0.12, 0.24, 0.08, 0.16, 0.22],
    crash: [0.14, 0.08, 0.3, 0.06, 0.2, 0.22],
  };
  const w = regimeWeights[input.regime];
  const factors: AiFactor[] = [
    { name: "Trend vs 50D", score: trendScore, weight: w[0], note: `Price is ${((input.price / sma50 - 1) * 100).toFixed(1)}% vs the 50-day average` },
    { name: "Momentum", score: momentumScore, weight: w[1], note: `20D ${(momentum20 * 100).toFixed(1)}% · 60D ${(momentum60 * 100).toFixed(1)}%` },
    { name: "Mean reversion", score: rsiScore, weight: w[2], note: `RSI(14) at ${rsi14.toFixed(0)} ${rsi14 < 30 ? "— oversold" : rsi14 > 70 ? "— overbought" : "— neutral"}` },
    { name: "Relative strength", score: relScore, weight: w[3], note: `${relStrength >= 0 ? "Outperforming" : "Lagging"} the index by ${Math.abs(relStrength * 100).toFixed(1)}% over 60D` },
    { name: "News sentiment", score: sentimentScore, weight: w[4], note: input.newsCount ? `${input.newsCount} recent stories, net sentiment ${(sentimentScore * 100).toFixed(0)}` : "No recent company-specific headlines" },
    { name: "Valuation range", score: -valuationScore, weight: w[5], note: `${(fromHigh * 100).toFixed(1)}% from the 52-week high` },
  ];

  const rawScore = factors.reduce((acc, f) => acc + f.score * f.weight, 0) * 100;
  const regimeBias = input.regime === "bull" ? 8 : input.regime === "bear" ? -8 : input.regime === "crash" ? -14 : 0;
  const score = clamp(rawScore + regimeBias, -100, 100);
  const label: AiSignalLabel =
    score >= 40 ? "Strong Buy" : score >= 14 ? "Buy" : score > -14 ? "Hold" : score > -40 ? "Sell" : "Strong Sell";

  const expectedReturn = clamp(
    (input.drift * horizonDays) / DAYS_PER_YEAR + (score / 100) * vol * Math.sqrt(horizonDays / DAYS_PER_YEAR) * 0.55,
    -0.4,
    0.7,
  );
  const target = input.price * (1 + expectedReturn);
  const stop = input.price * (1 - clamp(vol * Math.sqrt(horizonDays / DAYS_PER_YEAR) * 0.85, 0.04, 0.35));
  const confidence = Math.round(
    clamp(46 + Math.abs(score) * 0.42 + Math.min(input.newsCount, 5) * 1.6 + (sma20 ? 3 : 0), 42, 96),
  );
  const risk: AiSignal["risk"] = vol < 0.22 ? "Low" : vol < 0.36 ? "Moderate" : "High";

  const reasons: string[] = [];
  if (trendScore > 0.25) reasons.push(`Uptrend intact — trading above the 50-day average with ${input.regime === "bull" ? "supportive" : "mixed"} market conditions.`);
  if (trendScore < -0.25) reasons.push("Price is below its 50-day average, signaling sellers still control the tape.");
  if (rsi14 < 35) reasons.push(`RSI(14) at ${rsi14.toFixed(0)} indicates oversold exhaustion and rebound potential.`);
  if (rsi14 > 68) reasons.push(`RSI(14) at ${rsi14.toFixed(0)} flags short-term overbought extension.`);
  if (Math.abs(relStrength) > 0.02)
    reasons.push(`${relStrength > 0 ? "Positive relative strength" : "Negative relative strength"} — ${(relStrength * 100).toFixed(1)}% vs the index over 60 sessions.`);
  if (Math.abs(sentimentScore) > 0.15)
    reasons.push(`Headline flow is net ${sentimentScore > 0 ? "bullish" : "bearish"} across ${input.newsCount} recent stories.`);
  if (reasons.length < 2) reasons.push("Multi-factor signals are balanced; stagger entries or wait for breakout confirmation.");
  if (input.regime === "crash" || input.regime === "volatile")
    reasons.push(`Regime alert: ${REGIME_META[input.regime].label.toLowerCase()} widens expected ranges.`);

  const summary =
    label === "Strong Buy" || label === "Buy"
      ? `${input.symbol} screens constructive: the ensemble projects ${(expectedReturn * 100).toFixed(1)}% upside over ${horizonDays} sessions with ${risk.toLowerCase()} risk.`
      : label === "Hold"
        ? `${input.symbol} is range-bound in the model. Wait for a cleaner trend or a pullback toward the ${risk.toLowerCase()}-risk entry zone.`
        : `${input.symbol} screens weak: the ensemble favors trimming exposure with an expected ${(expectedReturn * 100).toFixed(1)}% ${horizonDays}-session move.`;

  return {
    label,
    score,
    confidence,
    target,
    stop,
    horizonDays,
    expectedReturn,
    risk,
    reasons: reasons.slice(0, 4),
    factors,
    summary,
  };
}

/* ---------------------------------------------------------- portfolio math */

export type HoldingLike = {
  symbol: string;
  name?: string;
  shares: number;
  price: number;
  beta: number;
  vol: number;
  drift: number;
};

export function portfolioParams(items: HoldingLike[]) {
  const value = items.reduce((a, h) => a + h.shares * h.price, 0);
  if (value <= 0) return { value: 0, drift: 0.08, vol: 0.18, beta: 1 };
  let drift = 0;
  let beta = 0;
  let marketPart = 0;
  let idioVar = 0;
  const marketVol = 0.17;
  for (const h of items) {
    const w = (h.shares * h.price) / value;
    drift += w * h.drift;
    beta += w * h.beta;
    marketPart += w * h.beta * marketVol;
    idioVar += w * w * Math.max(h.vol ** 2 - (h.beta * marketVol) ** 2, 0.0025);
  }
  const vol = Math.sqrt(marketPart ** 2 + idioVar);
  return { value, drift, vol, beta };
}

export function stressImpact(items: HoldingLike[], marketShock: number): number {
  return items.reduce((acc, h) => acc + h.shares * h.price * (h.beta * marketShock), 0);
}
