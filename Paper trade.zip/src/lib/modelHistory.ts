import { and, desc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { modelForecastHistory } from "@/db/schema";
import { FORECAST_HORIZONS, type RealMarketAnalysis } from "@/lib/realMarket";

const DAY_MS = 86_400_000;

function addTradingSessions(isoDate: string, sessions: number): string {
  const date = new Date(`${isoDate}T12:00:00.000Z`);
  let remaining = sessions;
  while (remaining > 0) {
    date.setUTCDate(date.getUTCDate() + 1);
    const weekday = date.getUTCDay();
    if (weekday !== 0 && weekday !== 6) remaining--;
  }
  return date.toISOString().slice(0, 10);
}

/** Save first forecasts for each daily source date, and score matured forecasts against actual closes. */
export async function captureAndEvaluateForecasts(analysis: RealMarketAnalysis) {
  const rows = analysis.forecasts.flatMap(model => FORECAST_HORIZONS.map(horizon => {
    const prediction = model.forecasts[horizon.key];
    return {
      symbol: analysis.symbol,
      modelId: model.id,
      horizon: horizon.key,
      horizonDays: horizon.days,
      forecastDate: analysis.latestDate,
      targetDate: addTradingSessions(analysis.latestDate, horizon.days),
      referencePrice: analysis.latestClose,
      predictedLow: prediction.low,
      predictedMedian: prediction.median,
      predictedHigh: prediction.high,
    };
  })).filter(row => [row.referencePrice, row.predictedLow, row.predictedMedian, row.predictedHigh].every(Number.isFinite));

  if (rows.length) {
    await db.insert(modelForecastHistory).values(rows).onConflictDoNothing();
  }

  const latestTime = Date.parse(`${analysis.latestDate}T23:59:59.999Z`);
  const pending = await db
    .select()
    .from(modelForecastHistory)
    .where(and(eq(modelForecastHistory.symbol, analysis.symbol), isNull(modelForecastHistory.actualPrice)))
    .orderBy(desc(modelForecastHistory.id))
    .limit(500);

  for (const prediction of pending) {
    const targetTime = Date.parse(`${prediction.targetDate}T00:00:00.000Z`);
    if (!Number.isFinite(targetTime) || targetTime > latestTime) continue;
    // Exchange holidays can move the realized target up to seven calendar days later.
    const realized = analysis.history.find(bar => {
      const barTime = Date.parse(`${bar.date}T00:00:00.000Z`);
      return barTime >= targetTime && barTime <= targetTime + 7 * DAY_MS;
    });
    if (!realized) continue;

    const actualPrice = realized.adjustedClose;
    const errorPct = prediction.predictedMedian > 0
      ? Math.abs(actualPrice - prediction.predictedMedian) / prediction.predictedMedian
      : null;
    const predictedUp = prediction.predictedMedian > prediction.referencePrice;
    const actualUp = actualPrice > prediction.referencePrice;

    await db
      .update(modelForecastHistory)
      .set({ actualPrice, errorPct, directionCorrect: predictedUp === actualUp, evaluatedAt: new Date() })
      .where(and(eq(modelForecastHistory.id, prediction.id), isNull(modelForecastHistory.actualPrice)));
  }

  return db
    .select()
    .from(modelForecastHistory)
    .where(eq(modelForecastHistory.symbol, analysis.symbol))
    .orderBy(desc(modelForecastHistory.id))
    .limit(80);
}
