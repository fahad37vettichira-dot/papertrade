import { and, asc, desc, eq, gte, notInArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  accountHistory,
  accounts,
  holdings,
  indexHistory,
  markets,
  newsItems,
  orders,
  priceHistory,
  tickers,
  transactions,
  watchlist,
} from "@/db/schema";
import {
  annualizedVol,
  bollingerBands,
  clamp,
  computeSignal,
  dailyReturns,
  DAYS_PER_YEAR,
  gaussian,
  hashString,
  maxDrawdown,
  monteCarlo,
  mulberry32,
  periodReturn,
  portfolioParams,
  quantile,
  REGIME_META,
  rsi,
  sharpeRatio,
  sma,
  stepRegime,
  type Regime,
} from "@/lib/engine";
import { NEWS_TEMPLATES, SECTORS, TICKER_BY_SYMBOL, UNIVERSE } from "@/lib/universe";
import { epochForToday } from "@/lib/time";
import type {
  AccountView,
  CurvePoint,
  HoldingView,
  MarketView,
  NewsView,
  OrderView,
  Snapshot,
  SymbolDetail,
  TickerSignalSummary,
  TickerView,
  TransactionView,
} from "@/lib/api-types";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type TickerRow = typeof tickers.$inferSelect;

const ACCOUNT_ID = 1;
const MARKET_ID = 1;
const WARMUP_DAYS = 540;
const MARKET_VOL = 0.17;
const DEFAULT_SEED = 20260214;
const MAX_DAY = WARMUP_DAYS + 1305;

const round2 = (n: number) => Math.round(n * 100) / 100;
const round4 = (n: number) => Math.round(n * 10000) / 10000;

/* ------------------------------------------------------------------ seeding */

let seedPromise: Promise<void> | null = null;

export async function ensureSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

async function runSeed(): Promise<void> {
  const existing = await db.select({ id: markets.id }).from(markets).limit(1);
  if (existing.length > 0) return;

  const epoch = epochForToday(WARMUP_DAYS);
  const baseRng = mulberry32(DEFAULT_SEED);
  const marketPath: number[] = [];
  const regimePath: Regime[] = [];
  let regime: Regime = "bull";
  let indexLevel = 100;
  let regimeDays = 0;

  for (let day = 0; day <= WARMUP_DAYS; day++) {
    if (day > 0) {
      const next = stepRegime(regime, baseRng);
      regimeDays = next === regime ? regimeDays + 1 : 1;
      regime = next;
      const meta = REGIME_META[regime];
      const shock =
        meta.drift / DAYS_PER_YEAR + (MARKET_VOL * meta.volMul * gaussian(baseRng)) / Math.sqrt(DAYS_PER_YEAR);
      indexLevel = indexLevel * (1 + shock);
    }
    regimePath.push(regime);
    marketPath.push(indexLevel);
  }
  const indexStart = marketPath[0];
  const normalizedIndex = marketPath.map((v) => round4((v / indexStart) * 100));

  const historyRows: Array<{
    symbol: string;
    day: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }> = [];
  const tickerValues: TickerRow[] = [];

  for (const def of UNIVERSE) {
    const rng = mulberry32(hashString(`${def.symbol}-${DEFAULT_SEED}`));
    const idioVol = Math.sqrt(Math.max(def.vol ** 2 - (def.beta * MARKET_VOL) ** 2, 0.0025));
    const closes: number[] = [];
    let price = def.price;
    for (let day = 0; day <= WARMUP_DAYS; day++) {
      if (day > 0) {
        const meta = REGIME_META[regimePath[day]];
        const marketReturn = normalizedIndex[day] / normalizedIndex[day - 1] - 1;
        const idio = (idioVol * meta.volMul * gaussian(rng)) / Math.sqrt(DAYS_PER_YEAR);
        const drift = ((1 - def.beta) * def.drift) / DAYS_PER_YEAR;
        const r = drift + def.beta * marketReturn + idio;
        price = Math.max(1, price * Math.exp(r));
      }
      closes.push(price);
    }

    const scale = def.price / closes[closes.length - 1];
    const scaled = closes.map((c) => round4(c * scale));
    const baseVol = Math.round(2_500_000 + rng() * 24_000_000);

    for (let day = 0; day <= WARMUP_DAYS; day++) {
      const c = scaled[day];
      const prev = day > 0 ? scaled[day - 1] : c;
      const o = round4(prev * (1 + (rng() - 0.5) * 0.005));
      const wick = c * def.vol * 0.014 * (0.35 + rng() * 0.85);
      const h = round4(Math.max(o, c) + wick * rng());
      const l = round4(Math.max(0.5, Math.min(o, c) - wick * rng()));
      const vol = Math.round(baseVol * (0.65 + rng() * 0.85));
      historyRows.push({ symbol: def.symbol, day, open: o, high: h, low: l, close: c, volume: vol });
    }

    const lastBar = historyRows[historyRows.length - 1];
    const prev = scaled[scaled.length - 2];
    tickerValues.push({
      symbol: def.symbol,
      name: def.name,
      sector: def.sector,
      description: def.description,
      price: lastBar.close,
      prevClose: prev,
      dayOpen: lastBar.open,
      dayHigh: lastBar.high,
      dayLow: lastBar.low,
      volume: lastBar.volume,
      annualDrift: def.drift,
      annualVol: def.vol,
      beta: def.beta,
      dividendYield: def.dividendYield,
      updatedDay: WARMUP_DAYS,
    });
  }

  await db
    .insert(accounts)
    .values({
      id: ACCOUNT_ID,
      name: "Paper Trader",
      cash: 100_000,
      startingCash: 100_000,
      netDeposits: 100_000,
      taxRate: 0.24,
      longTermTaxRate: 0.15,
    })
    .onConflictDoNothing();

  await db
    .insert(markets)
    .values({
      id: MARKET_ID,
      day: WARMUP_DAYS,
      epoch,
      seed: DEFAULT_SEED,
      indexLevel: normalizedIndex[normalizedIndex.length - 1],
      prevIndexLevel: normalizedIndex[normalizedIndex.length - 2],
      regime: regimePath[regimePath.length - 1],
      regimeDays,
      speed: 0,
    })
    .onConflictDoNothing();

  await db.insert(tickers).values(tickerValues).onConflictDoNothing();

  for (let i = 0; i < historyRows.length; i += 1500) {
    await db.insert(priceHistory).values(historyRows.slice(i, i + 1500)).onConflictDoNothing();
  }

  await db
    .insert(indexHistory)
    .values(normalizedIndex.map((level, day) => ({ day, level })))
    .onConflictDoNothing();

  await db
    .insert(watchlist)
    .values(["AAPL", "NVDA", "TSLA", "JPM", "MSFT", "LLY"].map((symbol) => ({ symbol })))
    .onConflictDoNothing();

  // Starter portfolio opened 90 sessions ago so charts, risk and P/L are immediately alive
  const priceAt = new Map<string, number>();
  for (const row of historyRows) priceAt.set(`${row.symbol}:${row.day}`, row.close);
  const starterDay = WARMUP_DAYS - 90;
  const starters: Array<{ symbol: string; shares: number }> = [
    { symbol: "AAPL", shares: 40 },
    { symbol: "NVDA", shares: 60 },
    { symbol: "MSFT", shares: 20 },
    { symbol: "JPM", shares: 35 },
  ];
  const starterHoldings: Array<typeof holdings.$inferInsert> = [];
  const starterTx: Array<typeof transactions.$inferInsert> = [];
  let starterCost = 0;
  for (const item of starters) {
    const entry = priceAt.get(`${item.symbol}:${starterDay}`) ?? 100;
    const cost = round2(entry * item.shares);
    starterCost += cost;
    starterHoldings.push({ symbol: item.symbol, shares: item.shares, avgCost: entry, openedDay: starterDay });
    starterTx.push({
      day: starterDay,
      kind: "buy",
      symbol: item.symbol,
      shares: item.shares,
      price: entry,
      amount: -cost,
      note: "Starter portfolio allocation · $0 commission",
    });
  }
  await db.insert(holdings).values(starterHoldings).onConflictDoNothing();
  await db.insert(transactions).values(starterTx);

  const starterCash = 100_000 - starterCost;
  const curveRows: Array<{ day: number; value: number; cash: number; invested: number }> = [];
  for (let day = starterDay; day <= WARMUP_DAYS; day++) {
    let invested = 0;
    for (const item of starters) {
      invested += item.shares * (priceAt.get(`${item.symbol}:${day}`) ?? 0);
    }
    curveRows.push({ day, value: round2(starterCash + invested), cash: round2(starterCash), invested: round2(invested) });
  }
  if (curveRows.length) {
    await db.insert(accountHistory).values(curveRows).onConflictDoNothing();
  }

  await db
    .update(accounts)
    .set({ cash: round2(starterCash) })
    .where(eq(accounts.id, ACCOUNT_ID));

  const newsRng = mulberry32(DEFAULT_SEED + 77);
  const seededNews: Array<typeof newsItems.$inferInsert> = [];
  for (let day = WARMUP_DAYS - 40; day <= WARMUP_DAYS; day++) {
    if (newsRng() > 0.55) continue;
    const item = rollNews(newsRng, day, tickerValues, false);
    if (item) seededNews.push(item);
  }
  if (seededNews.length) {
    await db.insert(newsItems).values(seededNews.slice(-20));
  }
}

/* -------------------------------------------------------------------- news */

type GeneratedNews = {
  day: number;
  kind: string;
  headline: string;
  summary: string;
  symbol: string | null;
  sector: string | null;
  sentiment: number;
  impact: number;
};

function fillTemplate(text: string, values: Record<string, string>): string {
  return text.replace(/\{(\w+)\}/g, (_, key: string) => values[key] ?? key);
}

function rollNews(
  rng: () => number,
  day: number,
  tickerRows: Array<{ symbol: string; name: string; sector: string }>,
  forceMajorEvent = false,
): GeneratedNews | null {
  const roll = rng();
  const marketTemplates = NEWS_TEMPLATES.filter((t) => t.scope === "market");
  const sectorTemplates = NEWS_TEMPLATES.filter((t) => t.scope === "sector");
  const symbolTemplates = NEWS_TEMPLATES.filter((t) => t.scope === "symbol");

  if (forceMajorEvent) {
    const events = NEWS_TEMPLATES.filter((t) => t.kind === "event");
    const tpl = events[Math.floor(rng() * events.length)];
    if (tpl.scope === "symbol" && tickerRows.length) {
      const target = tickerRows[Math.floor(rng() * tickerRows.length)];
      const values = { name: target.name, symbol: target.symbol, sector: target.sector };
      return {
        day,
        kind: "event",
        headline: fillTemplate(tpl.headline, values),
        summary: fillTemplate(tpl.summary, values),
        symbol: target.symbol,
        sector: target.sector,
        sentiment: rngRange(rng, tpl.sentiment),
        impact: rngRange(rng, tpl.impact) * 1.25,
      };
    }
    return {
      day,
      kind: "event",
      headline: fillTemplate(tpl.headline, {}),
      summary: fillTemplate(tpl.summary, {}),
      symbol: null,
      sector: null,
      sentiment: rngRange(rng, tpl.sentiment),
      impact: rngRange(rng, tpl.impact) * 1.25,
    };
  }

  if (roll < 0.22) {
    const tpl = marketTemplates[Math.floor(rng() * marketTemplates.length)];
    return {
      day,
      kind: tpl.kind,
      headline: fillTemplate(tpl.headline, {}),
      summary: fillTemplate(tpl.summary, {}),
      symbol: null,
      sector: null,
      sentiment: rngRange(rng, tpl.sentiment),
      impact: rngRange(rng, tpl.impact),
    };
  }
  if (roll < 0.38 && sectorTemplates.length) {
    const tpl = sectorTemplates[Math.floor(rng() * sectorTemplates.length)];
    const pool = tpl.sectors ?? SECTORS.filter((s) => s !== "Communication");
    const sector = pool[Math.floor(rng() * pool.length)];
    return {
      day,
      kind: "market",
      headline: fillTemplate(tpl.headline, { sector }),
      summary: fillTemplate(tpl.summary, { sector }),
      symbol: null,
      sector,
      sentiment: rngRange(rng, tpl.sentiment),
      impact: rngRange(rng, tpl.impact),
    };
  }
  if (roll < 0.95 && tickerRows.length) {
    const target = tickerRows[Math.floor(rng() * tickerRows.length)];
    const tpl = symbolTemplates[Math.floor(rng() * symbolTemplates.length)];
    const values = { name: target.name, symbol: target.symbol, sector: target.sector };
    return {
      day,
      kind: tpl.kind,
      headline: fillTemplate(tpl.headline, values),
      summary: fillTemplate(tpl.summary, values),
      symbol: target.symbol,
      sector: target.sector,
      sentiment: rngRange(rng, tpl.sentiment),
      impact: rngRange(rng, tpl.impact),
    };
  }
  return null;
}

function rngRange(rng: () => number, [min, max]: [number, number]): number {
  return min + rng() * (max - min);
}

/* ------------------------------------------------------------------ ticking */

export async function advanceMarket(requestedDays: number, triggerEvent = false): Promise<void> {
  if (!Number.isFinite(requestedDays) || requestedDays < 1 || requestedDays > 1260) throw new Error("Choose between 1 trading day and 5 years.");
  const days = Math.round(requestedDays);
  await ensureSeed();

  await db.transaction(async (tx) => {
    const [market] = await tx.select().from(markets).where(eq(markets.id, MARKET_ID)).for("update");
    if (!market) throw new Error("Market not initialised");
    const [account] = await tx.select().from(accounts).where(eq(accounts.id, ACCOUNT_ID)).for("update");
    if (!account) throw new Error("Account not initialised");

    const tickerRows = await tx.select().from(tickers).orderBy(asc(tickers.symbol));
    const state = new Map<string, TickerRow>(tickerRows.map((t) => [t.symbol, { ...t }]));
    let holdingRows = await tx.select().from(holdings);
    let cash = account.cash;
    let realizedPnl = account.realizedPnl;
    let taxLiability = account.taxLiability;
    const openOrders = await tx.select().from(orders).where(eq(orders.status, "open"));

    let day = market.day;
    let regime = market.regime as Regime;
    let regimeDays = market.regimeDays;
    let indexLevel = market.indexLevel;
    let prevIndexLevel = market.prevIndexLevel;
    const startDay = day;
    const sampleEvery = 1; // Keep true daily observations even when jumping five years.

    const newHistory: Array<{
      symbol: string;
      day: number;
      open: number;
      high: number;
      low: number;
      close: number;
      volume: number;
    }> = [];
    const newIndexHistory: Array<{ day: number; level: number }> = [];
    const newAccountHistory: Array<{ day: number; value: number; cash: number; invested: number }> = [];
    const newTransactions: Array<typeof transactions.$inferInsert> = [];
    const newsLog: GeneratedNews[] = [];
    const filledOrderIds = new Map<number, { day: number; price: number }>();
    const rejectedOrderIds = new Set<number>();

    const executeOrderFill = (order: typeof orders.$inferSelect, fillPrice: number) => {
      if (order.side === "buy") {
        const cost = round2(order.qty * fillPrice);
        if (cost > cash + 1e-6) {
          rejectedOrderIds.add(order.id);
          return;
        }
        cash -= cost;
        const holding = holdingRows.find((h) => h.symbol === order.symbol);
        if (holding) {
          const newShares = holding.shares + order.qty;
          holding.avgCost = round4((holding.avgCost * holding.shares + cost) / newShares);
          holding.shares = newShares;
        } else {
          holdingRows = [
            ...holdingRows,
            { id: -order.id, symbol: order.symbol, shares: order.qty, avgCost: round4(fillPrice), openedDay: day },
          ];
        }
        newTransactions.push({
          day,
          kind: "buy",
          symbol: order.symbol,
          shares: order.qty,
          price: round4(fillPrice),
          amount: -cost,
          note: `${order.orderType === "stop" ? "Stop" : "Limit"} order filled`,
        });
        filledOrderIds.set(order.id, { day, price: fillPrice });
      } else {
        const holding = holdingRows.find((h) => h.symbol === order.symbol);
        if (!holding || holding.shares + 1e-6 < order.qty) {
          rejectedOrderIds.add(order.id);
          return;
        }
        const proceeds = round2(order.qty * fillPrice);
        const realized = round2(order.qty * (fillPrice - holding.avgCost));
        cash += proceeds;
        realizedPnl += realized;
        const heldDays = Math.max(0, day - (holding.openedDay ?? day));
        const rate = heldDays >= 252 ? account.longTermTaxRate : account.taxRate;
        if (account.taxEnabled && realized > 0) taxLiability += round2(realized * rate);
        holding.shares = round4(holding.shares - order.qty);
        if (holding.shares <= 1e-6) holdingRows = holdingRows.filter((h) => h.id !== holding.id);
        newTransactions.push({
          day,
          kind: "sell",
          symbol: order.symbol,
          shares: order.qty,
          price: round4(fillPrice),
          amount: proceeds,
          realized,
          note: `${order.orderType === "stop" ? "Stop-loss" : "Limit"} order filled`,
        });
        filledOrderIds.set(order.id, { day, price: fillPrice });
      }
    };

    const resolveOrder = (order: typeof orders.$inferSelect, openPrice: number, high: number, low: number) => {
      if (filledOrderIds.has(order.id) || rejectedOrderIds.has(order.id)) return;
      if (order.orderType === "stop") {
        if (order.side === "sell" && low <= order.limitPrice) {
          executeOrderFill(order, round4(Math.min(order.limitPrice, openPrice)));
        } else if (order.side === "buy" && high >= order.limitPrice) {
          executeOrderFill(order, round4(Math.max(order.limitPrice, openPrice)));
        }
        return;
      }
      if (order.side === "buy" && low <= order.limitPrice) {
        executeOrderFill(order, round4(Math.min(order.limitPrice, openPrice)));
      } else if (order.side === "sell" && high >= order.limitPrice) {
        executeOrderFill(order, round4(Math.max(order.limitPrice, openPrice)));
      }
    };

    for (let step = 0; step < days; step++) {
      day += 1;
      const rng = mulberry32(hashString(`${market.seed}-${day}-prices`));
      const nextRegime = stepRegime(regime, rng);
      regimeDays = nextRegime === regime ? regimeDays + 1 : 1;
      regime = nextRegime;
      const meta = REGIME_META[regime];
      const marketShock =
        meta.drift / DAYS_PER_YEAR + (MARKET_VOL * meta.volMul * gaussian(rng)) / Math.sqrt(DAYS_PER_YEAR);
      prevIndexLevel = indexLevel;
      indexLevel = Math.max(10, indexLevel * Math.exp(marketShock));
      const marketReturn = indexLevel / prevIndexLevel - 1;

      for (const row of state.values()) {
        row.prevClose = row.price;
        row.dayOpen = round4(row.price * (1 + (rng() - 0.5) * 0.005));
        const idioVol = Math.sqrt(Math.max(row.annualVol ** 2 - (row.beta * MARKET_VOL) ** 2, 0.0025));
        const idio = (idioVol * meta.volMul * gaussian(rng)) / Math.sqrt(DAYS_PER_YEAR);
        const drift = ((1 - row.beta) * row.annualDrift) / DAYS_PER_YEAR;
        const r = drift + row.beta * marketReturn + idio;
        row.price = Math.max(1, row.price * Math.exp(r));
      }

      const newsRng = mulberry32(hashString(`${day}-${market.seed}-news`));
      const eventsToday: GeneratedNews[] = [];
      const forceNow = triggerEvent && step === days - 1;
      let attempts = forceNow ? 1 : newsRng() < 0.48 ? 1 : 0;
      if (newsRng() < 0.1) attempts += 1;

      for (let n = 0; n < attempts; n++) {
        const item = rollNews(newsRng, day, [...state.values()], forceNow && n === 0);
        if (item && !eventsToday.some((e) => e.headline === item.headline && e.symbol === item.symbol)) {
          eventsToday.push(item);
        }
      }

      for (const item of eventsToday) {
        const targets = item.symbol
          ? [state.get(item.symbol)].filter(Boolean)
          : item.sector
            ? [...state.values()].filter((t) => t.sector === item.sector)
            : [...state.values()];
        for (const target of targets) {
          if (!target) continue;
          const scalar = item.symbol ? 1 : item.sector ? 0.85 : target.beta * 0.9;
          target.price = Math.max(1, target.price * (1 + item.impact * scalar));
        }
        if (!item.symbol && !item.sector) indexLevel = Math.max(10, indexLevel * (1 + item.impact));
        newsLog.push(item);
      }

      for (const row of state.values()) {
        row.price = round4(row.price);
        const wick = row.price * row.annualVol * 0.015 * (0.4 + rng());
        row.dayHigh = round4(Math.max(row.dayOpen, row.price) + wick * rng());
        row.dayLow = round4(Math.max(0.5, Math.min(row.dayOpen, row.price) - wick * rng()));
        const baseVolume = 2_500_000 + hashString(row.symbol) % 24_000_000;
        row.volume = Math.round(baseVolume * (0.65 + rng() * 0.85));
        row.updatedDay = day;
      }

      for (const order of openOrders) {
        const row = state.get(order.symbol);
        if (!row) continue;
        resolveOrder(order, row.dayOpen, row.dayHigh, row.dayLow);
      }

      // quarterly dividends
      if (day % 63 === 0 && holdingRows.length > 0) {
        for (const holdingRow of holdingRows) {
          const row = state.get(holdingRow.symbol);
          if (!row || row.dividendYield <= 0) continue;
          const amount = holdingRow.shares * row.price * (row.dividendYield / 4);
          if (amount < 0.01) continue;
          cash += amount;
          newTransactions.push({
            day,
            kind: "dividend",
            symbol: holdingRow.symbol,
            shares: holdingRow.shares,
            price: round4(row.price),
            amount: round2(amount),
            note: `Quarterly dividend · ${(row.dividendYield * 100).toFixed(2)}% yield`,
          });
        }
      }

      if ((day - startDay) % sampleEvery === 0 || step === days - 1) {
        for (const row of state.values()) {
          newHistory.push({
            symbol: row.symbol,
            day,
            open: row.dayOpen,
            high: row.dayHigh,
            low: row.dayLow,
            close: row.price,
            volume: row.volume,
          });
        }
        newIndexHistory.push({ day, level: round4(indexLevel) });
        const invested = holdingRows.reduce((acc, h) => acc + h.shares * (state.get(h.symbol)?.price ?? 0), 0);
        newAccountHistory.push({ day, value: round2(cash + invested), cash: round2(cash), invested: round2(invested) });
      }
    }

    for (const row of state.values()) {
      await tx
        .update(tickers)
        .set({
          price: row.price,
          prevClose: row.prevClose,
          dayOpen: row.dayOpen,
          dayHigh: row.dayHigh,
          dayLow: row.dayLow,
          volume: row.volume,
          updatedDay: row.updatedDay,
        })
        .where(eq(tickers.symbol, row.symbol));
    }

    for (let i = 0; i < newHistory.length; i += 1500) {
      await tx.insert(priceHistory).values(newHistory.slice(i, i + 1500)).onConflictDoNothing();
    }
    if (newIndexHistory.length) {
      await tx.insert(indexHistory).values(newIndexHistory).onConflictDoNothing();
    }
    if (newAccountHistory.length) {
      await tx.insert(accountHistory).values(newAccountHistory).onConflictDoNothing();
    }

    if (newsLog.length) {
      const sorted = [...newsLog].sort((a, b) => b.day - a.day || Math.abs(b.impact) - Math.abs(a.impact)).slice(0, 80).reverse();
      await tx.insert(newsItems).values(sorted);
    }

    for (const [orderId, fill] of filledOrderIds) {
      await tx
        .update(orders)
        .set({ status: "filled", filledDay: fill.day, fillPrice: round4(fill.price) })
        .where(eq(orders.id, orderId));
    }
    for (const orderId of rejectedOrderIds) {
      await tx.update(orders).set({ status: "rejected" }).where(eq(orders.id, orderId));
    }

    if (holdingRows.length) {
      for (const holdingRow of holdingRows) {
        await tx
          .insert(holdings)
          .values({
            symbol: holdingRow.symbol,
            shares: round4(holdingRow.shares),
            avgCost: round4(holdingRow.avgCost),
            openedDay: holdingRow.openedDay ?? day,
          })
          .onConflictDoUpdate({
            target: holdings.symbol,
            set: { shares: round4(holdingRow.shares), avgCost: round4(holdingRow.avgCost), openedDay: holdingRow.openedDay },
          });
      }
      const currentSymbols = holdingRows.map((h) => h.symbol);
      if (currentSymbols.length) {
        await tx.delete(holdings).where(notInArray(holdings.symbol, currentSymbols));
      } else {
        await tx.delete(holdings);
      }
    } else {
      await tx.delete(holdings);
    }

    if (newTransactions.length) {
      await tx.insert(transactions).values(newTransactions);
    }

    await tx
      .update(accounts)
      .set({
        cash: round2(cash),
        realizedPnl: round2(realizedPnl),
        taxLiability: round2(taxLiability),
      })
      .where(eq(accounts.id, ACCOUNT_ID));

    await tx
      .update(markets)
      .set({
        day,
        indexLevel: round4(indexLevel),
        prevIndexLevel: round4(prevIndexLevel),
        regime,
        regimeDays,
        lastTickAt: new Date(),
      })
      .where(eq(markets.id, MARKET_ID));
  });

  const [latest] = await db.select({ day: markets.day }).from(markets).where(eq(markets.id, MARKET_ID));
  const cutoff = (latest?.day ?? MAX_DAY) - 1560;
  await db.execute(sql`delete from price_history where day < ${cutoff}`);
  await db.execute(sql`delete from account_history where day < ${cutoff}`);
}

/* ------------------------------------------------------------------ actions */

export type TradeInput = {
  symbol: string;
  side: "buy" | "sell";
  qty: number;
  orderType: "market" | "limit" | "stop";
  limitPrice?: number;
};

export async function executeTrade(input: TradeInput): Promise<{ message: string }> {
  await ensureSeed();
  const qty = round4(input.qty);
  if (!Number.isFinite(qty) || qty <= 0) throw new Error("Enter a quantity greater than zero.");
  if (qty > 5_000_000) throw new Error("That order exceeds the simulation maximum.");

  return db.transaction(async (tx) => {
    const [account] = await tx.select().from(accounts).where(eq(accounts.id, ACCOUNT_ID)).for("update");
    if (!account) throw new Error("Account not found");
    const [market] = await tx.select().from(markets).where(eq(markets.id, MARKET_ID));
    const [ticker] = await tx.select().from(tickers).where(eq(tickers.symbol, input.symbol.toUpperCase()));
    if (!ticker) throw new Error("Unknown symbol");
    if (!market) throw new Error("Market not ready");

    let restingOrderType: "limit" | "stop" | null = null;
    let restingPrice: number | null = null;

    if (input.orderType === "limit" || input.orderType === "stop") {
      const targetPrice = round4(input.limitPrice ?? ticker.price);
      if (!Number.isFinite(targetPrice) || targetPrice <= 0) throw new Error("Enter a valid trigger/limit price.");
      if (round2(targetPrice * qty) < 0.01) throw new Error("The smallest virtual order is $0.01.");
      if (targetPrice > ticker.price * 1.5 || targetPrice < ticker.price * 0.5)
        throw new Error("Order price must be within ±50% of current market price.");

      const triggersImmediately =
        input.orderType === "limit"
          ? input.side === "buy"
            ? targetPrice >= ticker.price
            : targetPrice <= ticker.price
          : input.side === "sell"
            ? targetPrice >= ticker.price
            : targetPrice <= ticker.price;

      if (!triggersImmediately) {
        if (input.side === "buy" && targetPrice * qty > account.cash)
          throw new Error("Order notional exceeds available buying power.");
        if (input.side === "sell") {
          const [holding] = await tx.select().from(holdings).where(eq(holdings.symbol, ticker.symbol));
          if (!holding || holding.shares + 1e-6 < qty) throw new Error("You do not own enough shares for this sell order.");
        }
        await tx.insert(orders).values({
          symbol: ticker.symbol,
          side: input.side,
          orderType: input.orderType,
          qty,
          limitPrice: targetPrice,
          status: "open",
          createdDay: market.day,
        });
        await recordAccountPoint(tx, market.day);
        return {
          message: `${input.orderType === "stop" ? "Stop" : "Limit"} ${input.side} placed: ${qty} ${ticker.symbol} @ $${targetPrice.toFixed(2)}`,
        };
      }
      restingOrderType = input.orderType;
      restingPrice = targetPrice;
    }

    const price = round4(ticker.price);
    if (round2(qty * price) < 0.01) throw new Error("The smallest virtual trade is $0.01.");
    if (input.side === "buy") {
      const cost = round2(qty * price);
      if (cost > account.cash + 0.005) throw new Error("Insufficient buying power for this order.");
      const [holding] = await tx.select().from(holdings).where(eq(holdings.symbol, ticker.symbol));
      if (holding) {
        const newShares = round4(holding.shares + qty);
        await tx
          .update(holdings)
          .set({ shares: newShares, avgCost: round4((holding.avgCost * holding.shares + cost) / newShares) })
          .where(eq(holdings.id, holding.id));
      } else {
        await tx.insert(holdings).values({ symbol: ticker.symbol, shares: qty, avgCost: price, openedDay: market.day });
      }
      await tx.update(accounts).set({ cash: round2(account.cash - cost) }).where(eq(accounts.id, ACCOUNT_ID));
      await tx.insert(transactions).values({
        day: market.day,
        kind: "buy",
        symbol: ticker.symbol,
        shares: qty,
        price,
        amount: -cost,
        note: restingPrice !== null ? "Marketable order filled instantly" : "Market order · $0 commission",
      });
      if (restingOrderType && restingPrice !== null) {
        await tx.insert(orders).values({
          symbol: ticker.symbol,
          side: "buy",
          orderType: restingOrderType,
          qty,
          limitPrice: restingPrice,
          status: "filled",
          createdDay: market.day,
          filledDay: market.day,
          fillPrice: price,
        });
      }
      await recordAccountPoint(tx, market.day);
      return { message: `Bought ${qty.toLocaleString("en-US", { maximumFractionDigits: 4 })} ${ticker.symbol} at $${price.toFixed(2)}` };
    }

    const [holding] = await tx.select().from(holdings).where(eq(holdings.symbol, ticker.symbol));
    if (!holding || holding.shares + 1e-6 < qty) throw new Error("You do not own that many shares.");
    const proceeds = round2(qty * price);
    const realized = round2(qty * (price - holding.avgCost));
    const heldDays = Math.max(0, market.day - holding.openedDay);
    const appliedTaxRate = heldDays >= 252 ? account.longTermTaxRate : account.taxRate;

    const newShares = round4(holding.shares - qty);
    if (newShares <= 1e-6) {
      await tx.delete(holdings).where(eq(holdings.id, holding.id));
    } else {
      await tx.update(holdings).set({ shares: newShares }).where(eq(holdings.id, holding.id));
    }
    const taxDelta = account.taxEnabled && realized > 0 ? round2(realized * appliedTaxRate) : 0;
    await tx
      .update(accounts)
      .set({
        cash: round2(account.cash + proceeds),
        realizedPnl: round2(account.realizedPnl + realized),
        taxLiability: round2(account.taxLiability + taxDelta),
      })
      .where(eq(accounts.id, ACCOUNT_ID));
    await tx.insert(transactions).values({
      day: market.day,
      kind: "sell",
      symbol: ticker.symbol,
      shares: qty,
      price,
      amount: proceeds,
      realized,
      note:
        taxDelta > 0
          ? `Tax simulator reserved $${taxDelta.toFixed(2)} (${heldDays >= 252 ? "long-term" : "short-term"})`
          : "Market order · $0 commission",
    });
    if (restingOrderType && restingPrice !== null) {
      await tx.insert(orders).values({
        symbol: ticker.symbol,
        side: "sell",
        orderType: restingOrderType,
        qty,
        limitPrice: restingPrice,
        status: "filled",
        createdDay: market.day,
        filledDay: market.day,
        fillPrice: price,
      });
    }
    await recordAccountPoint(tx, market.day);
    return {
      message: `Sold ${qty.toLocaleString("en-US", { maximumFractionDigits: 4 })} ${ticker.symbol} at $${price.toFixed(2)} · ${realized >= 0 ? "+" : ""}$${realized.toFixed(2)} realized`,
    };
  });
}

async function recordAccountPoint(tx: Tx, day: number): Promise<void> {
  const [account] = await tx.select().from(accounts).where(eq(accounts.id, ACCOUNT_ID));
  if (!account) return;
  const holdingRows = await tx.select().from(holdings);
  const tickerRows = await tx.select().from(tickers);
  const priceMap = new Map(tickerRows.map((t) => [t.symbol, t.price]));
  const invested = holdingRows.reduce((acc, h) => acc + h.shares * (priceMap.get(h.symbol) ?? 0), 0);
  await tx
    .insert(accountHistory)
    .values({ day, value: round2(account.cash + invested), cash: round2(account.cash), invested: round2(invested) })
    .onConflictDoUpdate({
      target: accountHistory.day,
      set: { value: round2(account.cash + invested), cash: round2(account.cash), invested: round2(invested) },
    });
}

export async function cancelOrder(id: number): Promise<void> {
  await db.update(orders).set({ status: "cancelled" }).where(and(eq(orders.id, id), eq(orders.status, "open")));
}

export async function adjustCash(input: {
  action: "deposit" | "withdraw";
  amount: number;
  settleTax?: boolean;
}): Promise<{ message: string }> {
  await ensureSeed();
  const amount = round2(input.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter an amount greater than zero.");
  return db.transaction(async (tx) => {
    const [account] = await tx.select().from(accounts).where(eq(accounts.id, ACCOUNT_ID)).for("update");
    const [market] = await tx.select().from(markets).where(eq(markets.id, MARKET_ID));
    if (!account || !market) throw new Error("Account not ready");

    if (input.action === "deposit") {
      if (amount > 5_000_000) throw new Error("Single virtual deposits are capped at $5,000,000.");
      await tx
        .update(accounts)
        .set({ cash: round2(account.cash + amount), netDeposits: round2(account.netDeposits + amount) })
        .where(eq(accounts.id, ACCOUNT_ID));
      await tx.insert(transactions).values({
        day: market.day,
        kind: "deposit",
        amount,
        note: "Virtual funds added",
      });
      await recordAccountPoint(tx, market.day);
      return { message: `Added $${amount.toLocaleString()} in virtual cash` };
    }

    const taxSettle = input.settleTax && account.taxEnabled ? round2(account.taxLiability) : 0;
    const total = round2(amount + taxSettle);
    if (total > account.cash + 0.005) throw new Error("Withdrawal exceeds available cash.");
    await tx
      .update(accounts)
      .set({
        cash: round2(account.cash - total),
        netDeposits: round2(account.netDeposits - amount),
        taxLiability: round2(account.taxLiability - taxSettle),
        taxPaid: round2(account.taxPaid + taxSettle),
      })
      .where(eq(accounts.id, ACCOUNT_ID));
    await tx.insert(transactions).values({
      day: market.day,
      kind: "withdraw",
      amount: -amount,
      note: "Virtual funds withdrawn",
    });
    if (taxSettle > 0) {
      await tx.insert(transactions).values({
        day: market.day,
        kind: "tax",
        amount: -taxSettle,
        note: `Simulated capital gains tax settled`,
      });
    }
    await recordAccountPoint(tx, market.day);
    return {
      message: `Withdrew $${amount.toLocaleString()}${taxSettle > 0 ? ` and settled $${taxSettle.toFixed(2)} simulated tax` : ""}`,
    };
  });
}

export async function toggleWatch(symbol: string): Promise<{ watched: boolean }> {
  await ensureSeed();
  const upper = symbol.toUpperCase();
  if (!TICKER_BY_SYMBOL[upper]) throw new Error("Unknown symbol");
  const [existing] = await db.select().from(watchlist).where(eq(watchlist.symbol, upper));
  if (existing) {
    await db.delete(watchlist).where(eq(watchlist.symbol, upper));
    return { watched: false };
  }
  await db.insert(watchlist).values({ symbol: upper }).onConflictDoNothing();
  return { watched: true };
}

export async function updateSettings(input: {
  taxEnabled?: boolean;
  taxRate?: number;
  longTermTaxRate?: number;
  speed?: number;
}): Promise<void> {
  await ensureSeed();
  for (const value of [input.taxRate, input.longTermTaxRate]) {
    if (value !== undefined && (!Number.isFinite(value) || value < 0 || value > 0.5)) throw new Error("Tax rates must be between 0% and 50%.");
  }
  if (input.speed !== undefined && (!Number.isFinite(input.speed) || input.speed < 0 || input.speed > 300)) throw new Error("Choose a valid simulation speed.");
  const patch: Partial<typeof accounts.$inferInsert> = {};
  if (typeof input.taxEnabled === "boolean") patch.taxEnabled = input.taxEnabled;
  if (typeof input.taxRate === "number") patch.taxRate = clamp(input.taxRate, 0, 0.5);
  if (typeof input.longTermTaxRate === "number") patch.longTermTaxRate = clamp(input.longTermTaxRate, 0, 0.5);
  if (Object.keys(patch).length) {
    await db.update(accounts).set(patch).where(eq(accounts.id, ACCOUNT_ID));
  }
  if (typeof input.speed === "number") {
    await db.update(markets).set({ speed: clamp(input.speed, 0, 300) }).where(eq(markets.id, MARKET_ID));
  }
}

export async function resetAccount(): Promise<void> {
  await ensureSeed();
  await db.delete(transactions);
  await db.delete(orders);
  await db.delete(holdings);
  await db.delete(watchlist);
  await db.delete(accountHistory);
  await db.delete(priceHistory);
  await db.delete(indexHistory);
  await db.delete(newsItems);
  await db.delete(tickers);
  await db.delete(accounts);
  await db.delete(markets);
  seedPromise = null;
  await ensureSeed();
}

/* ---------------------------------------------------------------- snapshot */

export async function buildSnapshot(): Promise<Snapshot> {
  await ensureSeed();
  const [accountRow] = await db.select().from(accounts).where(eq(accounts.id, ACCOUNT_ID));
  const [marketRow] = await db.select().from(markets).where(eq(markets.id, MARKET_ID));
  if (!accountRow || !marketRow) throw new Error("Simulation not initialised");

  const [tickerRows, holdingRows, orderRows, watchRows, newsRows, txRows, equityRows, indexRows, sparkRows, moneyRows] =
    await Promise.all([
      db.select().from(tickers).orderBy(asc(tickers.symbol)),
      db.select().from(holdings),
      db.select().from(orders).where(eq(orders.status, "open")).orderBy(desc(orders.createdAt)),
      db.select().from(watchlist),
      db.select().from(newsItems).orderBy(desc(newsItems.day), desc(newsItems.id)).limit(50),
      db.select().from(transactions).orderBy(desc(transactions.id)).limit(100),
      db.select().from(accountHistory).orderBy(desc(accountHistory.day)).limit(1561),
      db.select().from(indexHistory).orderBy(asc(indexHistory.day)),
      db.select().from(priceHistory).where(gte(priceHistory.day, marketRow.day - 252)).orderBy(asc(priceHistory.day)),
      db.select({
        deposits: sql<number>`coalesce(sum(case when ${transactions.kind} = 'deposit' then ${transactions.amount} else 0 end), 0)`,
        withdrawals: sql<number>`coalesce(sum(case when ${transactions.kind} = 'withdraw' then -${transactions.amount} else 0 end), 0)`,
        dividends: sql<number>`coalesce(sum(case when ${transactions.kind} = 'dividend' then ${transactions.amount} else 0 end), 0)`,
      }).from(transactions),
    ]);

  const priceMap = new Map(tickerRows.map((t) => [t.symbol, t]));
  const watchSet = new Set(watchRows.map((w) => w.symbol));
  const historyBySymbol = new Map<string, number[]>();
  for (const row of sparkRows) {
    const list = historyBySymbol.get(row.symbol) ?? [];
    list.push(row.close);
    historyBySymbol.set(row.symbol, list);
  }

  const holdingViews: HoldingView[] = holdingRows.map((h) => {
    const t = priceMap.get(h.symbol);
    const price = t?.price ?? 0;
    const value = h.shares * price;
    const heldDays = Math.max(0, marketRow.day - h.openedDay);
    return {
      symbol: h.symbol,
      name: t?.name ?? h.symbol,
      sector: t?.sector ?? "—",
      shares: h.shares,
      avgCost: h.avgCost,
      price,
      prevClose: t?.prevClose ?? price,
      changePct: t && t.prevClose ? price / t.prevClose - 1 : 0,
      value,
      cost: h.shares * h.avgCost,
      pnl: value - h.shares * h.avgCost,
      pnlPct: h.avgCost ? price / h.avgCost - 1 : 0,
      dayPnl: t ? h.shares * (price - (h.openedDay >= marketRow.day ? h.avgCost : t.prevClose)) : 0,
      weight: 0,
      beta: t?.beta ?? 1,
      openedDay: h.openedDay,
      heldDays,
      isLongTerm: heldDays >= 252,
    };
  });

  const investedValue = holdingViews.reduce((a, h) => a + h.value, 0);
  const portfolioValue = accountRow.cash + investedValue;
  for (const h of holdingViews) h.weight = portfolioValue > 0 ? h.value / portfolioValue : 0;
  holdingViews.sort((a, b) => b.value - a.value);

  const dayPnl = holdingViews.reduce((a, h) => a + h.dayPnl, 0);
  const prevValue = portfolioValue - dayPnl;
  const totalPnl = portfolioValue - accountRow.netDeposits;
  const unrealized = holdingViews.reduce((a, h) => a + h.pnl, 0);

  const account: AccountView = {
    name: accountRow.name,
    cash: accountRow.cash,
    startingCash: accountRow.startingCash,
    netDeposits: accountRow.netDeposits,
    realizedPnl: accountRow.realizedPnl,
    taxEnabled: accountRow.taxEnabled,
    taxRate: accountRow.taxRate,
    longTermTaxRate: accountRow.longTermTaxRate,
    taxLiability: accountRow.taxLiability,
    taxPaid: accountRow.taxPaid,
    withdrawals: Number(moneyRows[0]?.withdrawals || 0),
    totalDeposits: accountRow.startingCash + Number(moneyRows[0]?.deposits || 0),
    dividends: Number(moneyRows[0]?.dividends || 0),
  };

  const market: MarketView = {
    day: marketRow.day,
    epoch: marketRow.epoch,
    startDay: WARMUP_DAYS,
    indexLevel: round2(marketRow.indexLevel),
    indexChange: round2(marketRow.indexLevel - marketRow.prevIndexLevel),
    indexChangePct: marketRow.prevIndexLevel ? marketRow.indexLevel / marketRow.prevIndexLevel - 1 : 0,
    regime: marketRow.regime,
    regimeLabel: REGIME_META[marketRow.regime as Regime]?.label ?? marketRow.regime,
    regimeBlurb: REGIME_META[marketRow.regime as Regime]?.blurb ?? "",
    speed: marketRow.speed,
    lastTickAt: marketRow.lastTickAt.toISOString(),
  };

  const indexCloses = indexRows.map((r) => r.level);
  const topSignals: TickerSignalSummary[] = [];

  const tickerView: TickerView[] = tickerRows.map((t) => {
    const closes = historyBySymbol.get(t.symbol) ?? [t.price];
    const shares = holdingRows.find((h) => h.symbol === t.symbol)?.shares ?? 0;
    const symNews = newsRows.filter((n) => n.symbol === t.symbol);
    const symSent = symNews.length ? symNews.reduce((a, n) => a + n.sentiment, 0) / symNews.length : 0;
    const sig = computeSignal({
      symbol: t.symbol,
      name: t.name,
      price: t.price,
      closes,
      marketCloses: indexCloses,
      beta: t.beta,
      drift: t.annualDrift,
      vol: t.annualVol,
      regime: marketRow.regime as Regime,
      sentiment: symSent,
      newsCount: symNews.length,
    });
    topSignals.push({
      symbol: t.symbol,
      name: t.name,
      sector: t.sector,
      price: t.price,
      changePct: t.prevClose ? t.price / t.prevClose - 1 : 0,
      label: sig.label,
      score: sig.score,
      confidence: sig.confidence,
      target: sig.target,
      stop: sig.stop,
      expectedReturn: sig.expectedReturn,
      risk: sig.risk,
      summary: sig.summary,
    });
    return {
      symbol: t.symbol,
      name: t.name,
      sector: t.sector,
      price: t.price,
      prevClose: t.prevClose,
      change: t.price - t.prevClose,
      changePct: t.prevClose ? t.price / t.prevClose - 1 : 0,
      volume: t.volume,
      beta: t.beta,
      vol: t.annualVol,
      dividendYield: t.dividendYield,
      spark: closes.slice(-42),
      watched: watchSet.has(t.symbol),
      shares,
      signalLabel: sig.label,
      signalScore: sig.score,
      targetPrice: sig.target,
    };
  });

  topSignals.sort((a, b) => Math.abs(b.score) - Math.abs(a.score));

  const news: NewsView[] = newsRows.map((n) => ({
    id: n.id,
    day: n.day,
    kind: n.kind,
    headline: n.headline,
    summary: n.summary,
    symbol: n.symbol,
    sector: n.sector,
    sentiment: n.sentiment,
    impact: n.impact,
  }));

  const transactionViews: TransactionView[] = txRows.map((t) => ({
    id: t.id,
    day: t.day,
    kind: t.kind,
    symbol: t.symbol,
    shares: t.shares,
    price: t.price,
    amount: t.amount,
    realized: t.realized,
    note: t.note,
  }));

  const orderViews: OrderView[] = orderRows.map((o) => ({
    id: o.id,
    symbol: o.symbol,
    side: o.side as "buy" | "sell",
    orderType: (o.orderType === "stop" ? "stop" : "limit") as "limit" | "stop",
    qty: o.qty,
    limitPrice: o.limitPrice,
    status: o.status,
    createdDay: o.createdDay,
    price: priceMap.get(o.symbol)?.price ?? 0,
  }));

  const equityCurve: CurvePoint[] = equityRows
    .slice()
    .reverse()
    .map((r) => ({ day: r.day, value: r.value }));
  if (equityCurve.length && equityCurve[equityCurve.length - 1].day !== marketRow.day) {
    equityCurve.push({ day: marketRow.day, value: round2(portfolioValue) });
  }

  const indexCurve: CurvePoint[] = indexRows.map((r) => ({ day: r.day, value: r.level }));

  const sectorMap = new Map<string, { total: number; count: number }>();
  for (const t of tickerView) {
    const entry = sectorMap.get(t.sector) ?? { total: 0, count: 0 };
    entry.total += t.changePct;
    entry.count += 1;
    sectorMap.set(t.sector, entry);
  }
  const sectors = [...sectorMap.entries()]
    .map(([sector, v]) => ({ sector, changePct: v.total / v.count, count: v.count }))
    .sort((a, b) => b.changePct - a.changePct);

  const recentNews = newsRows.filter((n) => n.day >= marketRow.day - 30);
  const sentiment = recentNews.length
    ? recentNews.reduce((a, n) => a + n.sentiment * (1 + Math.min(Math.abs(n.impact) * 10, 2)), 0) /
      recentNews.reduce((a, n) => a + (1 + Math.min(Math.abs(n.impact) * 10, 2)), 0)
    : 0;

  let above = 0;
  let momentumSum = 0;
  let counted = 0;
  for (const t of tickerRows) {
    const closes = historyBySymbol.get(t.symbol) ?? [];
    if (closes.length >= 30) {
      const avg = closes.reduce((a, b) => a + b, 0) / closes.length;
      if (t.price > avg) above += 1;
      momentumSum += periodReturn(closes, 20);
      counted += 1;
    }
  }
  const breadth = counted ? above / counted : 0.5;
  const avgMomentum = counted ? momentumSum / counted : 0;
  const regimeBias =
    marketRow.regime === "bull" ? 12 : marketRow.regime === "bear" ? -12 : marketRow.regime === "crash" ? -20 : -3;
  const outlookScore = clamp((breadth - 0.5) * 110 + avgMomentum * 320 + sentiment * 22 + regimeBias, -100, 100);
  const prediction = monteCarlo({
    startValue: marketRow.indexLevel,
    annualDrift: 0.085 + (marketRow.regime === "bull" ? 0.03 : marketRow.regime === "bear" ? -0.05 : 0),
    annualVol: indexCloses.length > 30 ? annualizedVol(indexCloses) : MARKET_VOL,
    beta: 1,
    marketVol: MARKET_VOL,
    days: 30,
    runs: 400,
    seed: 7,
  });
  const outlookLabel =
    outlookScore >= 45
      ? "Risk-on"
      : outlookScore >= 15
        ? "Constructive"
        : outlookScore > -15
          ? "Neutral"
          : outlookScore > -45
            ? "Cautious"
            : "Risk-off";
  const outlook = {
    score: outlookScore,
    label: outlookLabel,
    confidence: Math.round(clamp(52 + Math.abs(outlookScore) * 0.4, 50, 94)),
    bullets: [
      `${Math.round(breadth * 100)}% of tracked equities trade above their 30-day moving average.`,
      `Median 30-day index projection ${prediction.terminal.p50 >= marketRow.indexLevel ? "+" : ""}${((prediction.terminal.p50 / marketRow.indexLevel - 1) * 100).toFixed(1)}% (90% band ${((prediction.terminal.p5 / marketRow.indexLevel - 1) * 100).toFixed(1)}% to ${((prediction.terminal.p95 / marketRow.indexLevel - 1) * 100).toFixed(1)}%).`,
      `Headline flow is ${sentiment > 0.08 ? "net bullish" : sentiment < -0.08 ? "net bearish" : "balanced"} (${sentiment.toFixed(2)} weighted sentiment).`,
      `${market.regimeLabel}: ${market.regimeBlurb}`,
    ],
    prediction30: {
      low: prediction.terminal.p5 / marketRow.indexLevel - 1,
      median: prediction.terminal.p50 / marketRow.indexLevel - 1,
      high: prediction.terminal.p95 / marketRow.indexLevel - 1,
      probUp: prediction.probProfit,
    },
    breadth,
    sentiment,
    avgMomentum,
  };

  return {
    account,
    market,
    holdings: holdingViews,
    totals: {
      portfolioValue: round2(portfolioValue),
      investedValue: round2(investedValue),
      cash: round2(accountRow.cash),
      unrealized: round2(unrealized),
      realized: round2(accountRow.realizedPnl),
      totalPnl: round2(totalPnl),
      totalPnlPct: totalPnl / Math.max(account.totalDeposits, 1),
      dayPnl: round2(dayPnl),
      dayPnlPct: prevValue ? dayPnl / prevValue : 0,
      buyingPower: round2(accountRow.cash),
      positions: holdingRows.length,
    },
    tickers: tickerView,
    topSignals: topSignals.slice(0, 8),
    news,
    transactions: transactionViews,
    orders: orderViews,
    watchlist: watchRows.map((w) => w.symbol),
    equityCurve,
    indexCurve,
    sectors,
    outlook,
  };
}

export async function getSymbolDetail(symbol: string): Promise<SymbolDetail | null> {
  await ensureSeed();
  const upper = symbol.toUpperCase();
  const [ticker] = await db.select().from(tickers).where(eq(tickers.symbol, upper));
  if (!ticker) return null;
  const [accountRow] = await db.select().from(accounts).where(eq(accounts.id, ACCOUNT_ID));
  const [marketRow] = await db.select().from(markets).where(eq(markets.id, MARKET_ID));
  if (!accountRow || !marketRow) return null;

  const [historyRows, indexRows, newsRows, holdingRows, watchRows] = await Promise.all([
    db.select().from(priceHistory).where(eq(priceHistory.symbol, upper)).orderBy(asc(priceHistory.day)),
    db.select().from(indexHistory).orderBy(asc(indexHistory.day)),
    db.select().from(newsItems).where(eq(newsItems.symbol, upper)).orderBy(desc(newsItems.day)).limit(24),
    db.select().from(holdings).where(eq(holdings.symbol, upper)),
    db.select().from(watchlist).where(eq(watchlist.symbol, upper)),
  ]);

  const closes = historyRows.map((h) => h.close);
  const year = closes.slice(-252);
  const sentiment = newsRows.length ? newsRows.reduce((a, n) => a + n.sentiment, 0) / newsRows.length : 0;
  const signal = computeSignal({
    symbol: upper,
    name: ticker.name,
    price: ticker.price,
    closes,
    marketCloses: indexRows.map((r) => r.level),
    beta: ticker.beta,
    drift: ticker.annualDrift,
    vol: ticker.annualVol,
    regime: marketRow.regime as Regime,
    sentiment,
    newsCount: newsRows.length,
  });

  const bb = bollingerBands(closes, 20, 2);
  const rets = dailyReturns(closes);
  const holding = holdingRows[0];
  const heldDays = holding ? Math.max(0, marketRow.day - holding.openedDay) : 0;
  const position: HoldingView | null = holding
    ? {
        symbol: holding.symbol,
        name: ticker.name,
        sector: ticker.sector,
        shares: holding.shares,
        avgCost: holding.avgCost,
        price: ticker.price,
        prevClose: ticker.prevClose,
        changePct: ticker.prevClose ? ticker.price / ticker.prevClose - 1 : 0,
        value: holding.shares * ticker.price,
        cost: holding.shares * holding.avgCost,
        pnl: holding.shares * (ticker.price - holding.avgCost),
        pnlPct: holding.avgCost ? ticker.price / holding.avgCost - 1 : 0,
        dayPnl: holding.shares * (ticker.price - (holding.openedDay >= marketRow.day ? holding.avgCost : ticker.prevClose)),
        weight: 0,
        beta: ticker.beta,
        openedDay: holding.openedDay,
        heldDays,
        isLongTerm: heldDays >= 252,
      }
    : null;

  return {
    ticker: {
      symbol: ticker.symbol,
      name: ticker.name,
      sector: ticker.sector,
      description: ticker.description,
      price: ticker.price,
      prevClose: ticker.prevClose,
      change: ticker.price - ticker.prevClose,
      changePct: ticker.prevClose ? ticker.price / ticker.prevClose - 1 : 0,
      volume: ticker.volume,
      beta: ticker.beta,
      vol: ticker.annualVol,
      dividendYield: ticker.dividendYield,
      spark: closes.slice(-42),
      watched: watchRows.length > 0,
      shares: holding?.shares ?? 0,
      signalLabel: signal.label,
      signalScore: signal.score,
      targetPrice: signal.target,
      annualDrift: ticker.annualDrift,
      annualVol: ticker.annualVol,
      dayOpen: ticker.dayOpen,
      dayHigh: ticker.dayHigh,
      dayLow: ticker.dayLow,
    },
    history: historyRows.map((h) => ({
      day: h.day,
      open: h.open || h.close,
      high: h.high || h.close,
      low: h.low || h.close,
      close: h.close,
      volume: h.volume || ticker.volume,
    })),
    indicators: {
      rsi14: rsi(closes, 14),
      sma20: sma(closes, 20),
      sma50: sma(closes, 50),
      sma200: sma(closes, 200),
      bollingerUpper: bb?.upper ?? null,
      bollingerLower: bb?.lower ?? null,
      vol: ticker.annualVol,
      high52: year.length ? Math.max(...year) : ticker.price,
      low52: year.length ? Math.min(...year) : ticker.price,
      fromHigh: year.length ? ticker.price / Math.max(...year) - 1 : 0,
      maxDrawdown: maxDrawdown(year.length ? year : closes),
      sharpe: sharpeRatio(rets),
      beta: ticker.beta,
      momentum20: periodReturn(closes, 20),
      momentum60: periodReturn(closes, 60),
      avgVolume: ticker.volume,
    },
    signal,
    news: newsRows.map((n) => ({
      id: n.id,
      day: n.day,
      kind: n.kind,
      headline: n.headline,
      summary: n.summary,
      symbol: n.symbol,
      sector: n.sector,
      sentiment: n.sentiment,
      impact: n.impact,
    })),
    position,
    cash: accountRow.cash,
    market: {
      day: marketRow.day,
      epoch: marketRow.epoch,
      startDay: WARMUP_DAYS,
      indexLevel: round2(marketRow.indexLevel),
      indexChange: round2(marketRow.indexLevel - marketRow.prevIndexLevel),
      indexChangePct: marketRow.prevIndexLevel ? marketRow.indexLevel / marketRow.prevIndexLevel - 1 : 0,
      regime: marketRow.regime,
      regimeLabel: REGIME_META[marketRow.regime as Regime]?.label ?? marketRow.regime,
      regimeBlurb: REGIME_META[marketRow.regime as Regime]?.blurb ?? "",
      speed: marketRow.speed,
      lastTickAt: marketRow.lastTickAt.toISOString(),
    },
    sentiment,
  };
}

export async function portfolioRiskSnapshot() {
  const snapshot = await buildSnapshot();
  const params = portfolioParams(
    snapshot.holdings.map((h) => ({
      symbol: h.symbol,
      shares: h.shares,
      price: h.price,
      beta: h.beta,
      vol: snapshot.tickers.find((t) => t.symbol === h.symbol)?.vol ?? 0.28,
      drift: 0.09,
    })),
  );
  return { snapshot, params };
}

export function quantileExport(sorted: number[], q: number) {
  return quantile(sorted, q);
}
