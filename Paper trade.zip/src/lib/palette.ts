export const UP = "#3e9365";
export const DOWN = "#c75b58";
export const ACCENT = "#448c5a";
export const VIOLET = "#a292ba";
export const WARN = "#c5a369";
export const PALETTE = ["#43865c", "#9dbc87", "#c0cfaa", "#c3b4d7", "#f0d69b", "#94b6b8", "#d5aba0", "#97a9c9"];
const brandColors: Record<string, string> = { AAPL: "#52605b", MSFT: "#5f85aa", NVDA: "#689737", TSLA: "#bc625a", AMZN: "#b18d40", GOOGL: "#6680ae", META: "#6a8db4", JPM: "#7d718b", LLY: "#b47d83" };
export function symbolColor(symbol: string) { if (brandColors[symbol]) return brandColors[symbol]; let h = 0; for (const c of symbol) h = (h * 31 + c.charCodeAt(0)) % 9973; return PALETTE[h % PALETTE.length]; }
export function sentimentTone(value: number): "up" | "down" | "neutral" { return value > .12 ? "up" : value < -.12 ? "down" : "neutral"; }
export function sentimentLabel(value: number) { return value > .12 ? "Positive" : value < -.12 ? "Negative" : "Balanced"; }
export function riskTone(label: string): "up" | "warn" | "down" | "neutral" { return label === "Low" ? "up" : label === "Moderate" ? "warn" : label === "High" ? "down" : "neutral"; }
