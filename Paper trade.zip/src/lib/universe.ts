export type SeedTicker = {
  symbol: string;
  name: string;
  sector: string;
  description: string;
  price: number;
  drift: number;
  vol: number;
  beta: number;
  dividendYield: number;
};

export const SECTORS = [
  "Technology",
  "Consumer",
  "Health Care",
  "Financials",
  "Communication",
  "Energy",
  "Industrials",
] as const;

export const UNIVERSE: SeedTicker[] = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    sector: "Technology",
    description:
      "Consumer hardware and services giant. iPhone, Mac, wearables and a high-margin digital services ecosystem.",
    price: 232,
    drift: 0.11,
    vol: 0.24,
    beta: 1.05,
    dividendYield: 0.005,
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corp.",
    sector: "Technology",
    description: "Cloud infrastructure (Azure), enterprise productivity suite and applied AI platform.",
    price: 468,
    drift: 0.13,
    vol: 0.22,
    beta: 1.0,
    dividendYield: 0.008,
  },
  {
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    sector: "Technology",
    description: "Accelerated computing, GPU architectures and AI datacenter networking leader.",
    price: 152,
    drift: 0.22,
    vol: 0.48,
    beta: 1.72,
    dividendYield: 0.0005,
  },
  {
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    sector: "Consumer",
    description: "Global e-commerce logistics network, AWS cloud leader and high-margin ad business.",
    price: 224,
    drift: 0.14,
    vol: 0.3,
    beta: 1.28,
    dividendYield: 0,
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    sector: "Communication",
    description: "Global search, YouTube video platform, Android and Google Cloud infrastructure.",
    price: 208,
    drift: 0.12,
    vol: 0.27,
    beta: 1.12,
    dividendYield: 0.004,
  },
  {
    symbol: "META",
    name: "Meta Platforms",
    sector: "Communication",
    description: "Global social platforms and AI-powered ad monetization with open-weight AI models.",
    price: 612,
    drift: 0.15,
    vol: 0.34,
    beta: 1.35,
    dividendYield: 0.003,
  },
  {
    symbol: "AMD",
    name: "Advanced Micro Devices",
    sector: "Technology",
    description: "High-performance datacenter CPUs, AI accelerators and adaptive computing silicon.",
    price: 168,
    drift: 0.16,
    vol: 0.44,
    beta: 1.62,
    dividendYield: 0,
  },
  {
    symbol: "ORCL",
    name: "Oracle Corp.",
    sector: "Technology",
    description: "Enterprise database software and rapidly expanding sovereign & AI cloud regions.",
    price: 188,
    drift: 0.12,
    vol: 0.28,
    beta: 1.06,
    dividendYield: 0.009,
  },
  {
    symbol: "CRM",
    name: "Salesforce Inc.",
    sector: "Technology",
    description: "Enterprise CRM cloud platform expanding into autonomous agent workflows.",
    price: 342,
    drift: 0.08,
    vol: 0.31,
    beta: 1.2,
    dividendYield: 0.001,
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    sector: "Consumer",
    description: "Electric vehicles, grid-scale battery storage and autonomous driving neural networks.",
    price: 288,
    drift: 0.1,
    vol: 0.55,
    beta: 1.85,
    dividendYield: 0,
  },
  {
    symbol: "NKE",
    name: "Nike Inc.",
    sector: "Consumer",
    description: "Global athletic footwear and apparel brand rebuilding direct and wholesale momentum.",
    price: 82,
    drift: 0.05,
    vol: 0.29,
    beta: 1.0,
    dividendYield: 0.018,
  },
  {
    symbol: "SBUX",
    name: "Starbucks Corp.",
    sector: "Consumer",
    description: "Global specialty coffee retail footprint with high-frequency digital loyalty.",
    price: 104,
    drift: 0.06,
    vol: 0.26,
    beta: 0.95,
    dividendYield: 0.022,
  },
  {
    symbol: "COST",
    name: "Costco Wholesale",
    sector: "Consumer",
    description: "Membership warehouse club with industry-leading renewal rates and inventory turns.",
    price: 942,
    drift: 0.12,
    vol: 0.2,
    beta: 0.82,
    dividendYield: 0.005,
  },
  {
    symbol: "WMT",
    name: "Walmart Inc.",
    sector: "Consumer",
    description: "Omnichannel grocery and retail giant with fast-growing digital ad and membership revenue.",
    price: 96,
    drift: 0.1,
    vol: 0.19,
    beta: 0.65,
    dividendYield: 0.011,
  },
  {
    symbol: "KO",
    name: "Coca-Cola Co.",
    sector: "Consumer",
    description: "Defensive global beverage franchise with pricing power and reliable dividend growth.",
    price: 68,
    drift: 0.055,
    vol: 0.16,
    beta: 0.55,
    dividendYield: 0.029,
  },
  {
    symbol: "JNJ",
    name: "Johnson & Johnson",
    sector: "Health Care",
    description: "Diversified innovative medicines and medtech franchise. Defensive healthcare anchor.",
    price: 158,
    drift: 0.06,
    vol: 0.17,
    beta: 0.6,
    dividendYield: 0.031,
  },
  {
    symbol: "PFE",
    name: "Pfizer Inc.",
    sector: "Health Care",
    description: "Global biopharma with oncology and specialty therapeutics pipeline. High dividend yield.",
    price: 30,
    drift: 0.04,
    vol: 0.25,
    beta: 0.7,
    dividendYield: 0.056,
  },
  {
    symbol: "LLY",
    name: "Eli Lilly & Co.",
    sector: "Health Care",
    description: "Metabolic, obesity and neuroscience therapeutics leader with rapid top-line growth.",
    price: 812,
    drift: 0.17,
    vol: 0.3,
    beta: 0.72,
    dividendYield: 0.007,
  },
  {
    symbol: "UNH",
    name: "UnitedHealth Group",
    sector: "Health Care",
    description: "Integrated health benefits and Optum care services platform.",
    price: 522,
    drift: 0.08,
    vol: 0.27,
    beta: 0.72,
    dividendYield: 0.015,
  },
  {
    symbol: "JPM",
    name: "JPMorgan Chase",
    sector: "Financials",
    description: "Largest US money-center bank across consumer banking, markets and wealth management.",
    price: 248,
    drift: 0.1,
    vol: 0.24,
    beta: 1.12,
    dividendYield: 0.021,
  },
  {
    symbol: "GS",
    name: "Goldman Sachs",
    sector: "Financials",
    description: "Global investment banking, M&A advisory, trading and asset management powerhouse.",
    price: 598,
    drift: 0.11,
    vol: 0.27,
    beta: 1.28,
    dividendYield: 0.02,
  },
  {
    symbol: "V",
    name: "Visa Inc.",
    sector: "Financials",
    description: "Global electronic payments network collecting high-margin volume fees worldwide.",
    price: 312,
    drift: 0.1,
    vol: 0.19,
    beta: 0.9,
    dividendYield: 0.007,
  },
  {
    symbol: "XOM",
    name: "Exxon Mobil",
    sector: "Energy",
    description: "Integrated oil, gas and refining supermajor with disciplined capital returns.",
    price: 118,
    drift: 0.07,
    vol: 0.28,
    beta: 0.85,
    dividendYield: 0.034,
  },
  {
    symbol: "CAT",
    name: "Caterpillar Inc.",
    sector: "Industrials",
    description: "Heavy construction, mining and power generation equipment tied to global capex.",
    price: 388,
    drift: 0.09,
    vol: 0.29,
    beta: 1.18,
    dividendYield: 0.015,
  },
  {
    symbol: "DIS",
    name: "Walt Disney Co.",
    sector: "Communication",
    description: "Theme parks, global entertainment franchises, ESPN and profitable streaming.",
    price: 112,
    drift: 0.075,
    vol: 0.28,
    beta: 1.05,
    dividendYield: 0.008,
  },
  {
    symbol: "NFLX",
    name: "Netflix Inc.",
    sector: "Communication",
    description: "Global streaming leader scaling ad-supported tiers and live sports events.",
    price: 912,
    drift: 0.15,
    vol: 0.33,
    beta: 1.25,
    dividendYield: 0,
  },
];

export const TICKER_BY_SYMBOL: Record<string, SeedTicker> = Object.fromEntries(
  UNIVERSE.map((t) => [t.symbol, t]),
);

export type NewsTemplate = {
  kind: "market" | "company" | "event";
  scope: "market" | "sector" | "symbol";
  headline: string;
  summary: string;
  sentiment: [number, number];
  impact: [number, number];
  sectors?: string[];
};

export const NEWS_TEMPLATES: NewsTemplate[] = [
  {
    kind: "company",
    scope: "symbol",
    headline: "{name} smashes quarterly earnings as operating margins expand",
    summary:
      "Revenue beat consensus by 7% and management raised full-year guidance. Institutional desks rushed to lift price targets.",
    sentiment: [0.55, 0.95],
    impact: [0.03, 0.095],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "{name} cuts full-year guidance; shares gap lower on volume",
    summary:
      "Management cited slower enterprise renewals and FX headwinds, prompting multiple downgrades across Wall Street.",
    sentiment: [-0.95, -0.45],
    impact: [-0.095, -0.028],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "Wall Street upgrades {symbol} to Strong Buy with 25% upside target",
    summary:
      "Analysts highlighted accelerating free cash flow conversion and underappreciated pricing power over the next 12 months.",
    sentiment: [0.4, 0.85],
    impact: [0.015, 0.055],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "{name} authorizes $20B share repurchase and 12% dividend hike",
    summary:
      "The board signaled strong balance-sheet confidence, retiring roughly 3% of float at current market prices.",
    sentiment: [0.35, 0.8],
    impact: [0.012, 0.045],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "Antitrust regulators launch formal investigation into {name}",
    summary:
      "Lawmakers requested internal pricing and distribution records, creating a multi-quarter valuation overhang.",
    sentiment: [-0.88, -0.4],
    impact: [-0.07, -0.018],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "{name} unveils breakthrough flagship platform ahead of schedule",
    summary:
      "Early customer commitments exceeded internal targets, sparking heavy call-option volume across weekly expiries.",
    sentiment: [0.45, 0.92],
    impact: [0.02, 0.075],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "Unexpected component bottleneck delays {name} Q3 deliveries",
    summary:
      "Tier-one supplier constraints will push shipments into next quarter, pressuring near-term gross margins.",
    sentiment: [-0.82, -0.35],
    impact: [-0.06, -0.015],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "Activist hedge fund discloses 6% stake in {name}, demands spin-off",
    summary:
      "The fund published a 60-page presentation arguing a breakup would unlock 35% trapped sum-of-the-parts value.",
    sentiment: [0.35, 0.88],
    impact: [0.025, 0.08],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "Sudden CEO departure at {name} rattles institutional holders",
    summary:
      "The board appointed an interim chief executive while launching an external search, triggering volatility.",
    sentiment: [-0.72, -0.15],
    impact: [-0.055, -0.01],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "{name} wins landmark multi-year federal & enterprise contract",
    summary:
      "The contract adds high-visibility recurring backlog and validates {symbol}'s next-generation architecture.",
    sentiment: [0.45, 0.9],
    impact: [0.018, 0.065],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "Short-seller dossier targets {name} channel inventory practices",
    summary:
      "{name} rejected the allegations as inaccurate, though shares remained volatile amid heavy institutional hedging.",
    sentiment: [-0.95, -0.5],
    impact: [-0.11, -0.025],
  },
  {
    kind: "event",
    scope: "market",
    headline: "Federal Reserve delivers surprise 50 bps rate cut to support growth",
    summary:
      "Policymakers pivoted aggressively as inflation cooled, igniting a broad risk-on rally across growth and cyclicals.",
    sentiment: [0.65, 1.0],
    impact: [0.022, 0.052],
  },
  {
    kind: "event",
    scope: "market",
    headline: "Hot CPI inflation shock sends Treasury yields surging",
    summary:
      "Core inflation re-accelerated above estimates, forcing traders to price out rate cuts and sell high-multiple stocks.",
    sentiment: [-0.92, -0.45],
    impact: [-0.048, -0.016],
  },
  {
    kind: "event",
    scope: "market",
    headline: "Geopolitical flashpoint triggers global risk-off flight to safety",
    summary:
      "Equities tumbled worldwide as volatility spiked, while energy and defensive staples outperformed.",
    sentiment: [-0.96, -0.55],
    impact: [-0.065, -0.024],
  },
  {
    kind: "market",
    scope: "market",
    headline: "Blockbuster payrolls & productivity data fuel soft-landing rally",
    summary:
      "Nonfarm payrolls beat forecasts without wage inflation, lifting breadth to multi-month highs.",
    sentiment: [0.4, 0.85],
    impact: [0.014, 0.038],
  },
  {
    kind: "event",
    scope: "market",
    headline: "Hyperscalers raise AI infrastructure capex by $60B",
    summary:
      "Massive datacenter commitments sparked an immediate surge across semiconductors, cloud software and power grids.",
    sentiment: [0.6, 1.0],
    impact: [0.022, 0.058],
  },
  {
    kind: "event",
    scope: "market",
    headline: "Flash liquidity crunch hits algorithmic desks intraday",
    summary:
      "Forced systematic deleveraging briefly swept order books before bargain hunters stepped in near the close.",
    sentiment: [-0.88, -0.4],
    impact: [-0.055, -0.02],
  },
  {
    kind: "market",
    scope: "market",
    headline: "Consumer spending & retail sales top consensus across categories",
    summary:
      "Strong household balance sheets kept discretionary and payments names bid throughout the session.",
    sentiment: [0.3, 0.78],
    impact: [0.01, 0.03],
  },
  {
    kind: "event",
    scope: "market",
    headline: "Crude oil jumps 14% after maritime chokepoint disruption",
    summary:
      "Supply fears lifted energy producers sharply while transportation and consumer margins came under pressure.",
    sentiment: [-0.45, 0.35],
    impact: [-0.025, 0.028],
  },
  {
    kind: "market",
    scope: "sector",
    headline: "{sector} ETFs record largest weekly institutional inflow of the year",
    summary:
      "Systematic and discretionary funds rotated aggressively into {sector} leaders as relative strength broke out.",
    sentiment: [0.4, 0.85],
    impact: [0.014, 0.04],
    sectors: ["Technology", "Health Care", "Financials", "Energy", "Industrials", "Consumer"],
  },
  {
    kind: "market",
    scope: "sector",
    headline: "Profit-taking hits crowded {sector} names after multi-month run",
    summary:
      "Portfolio managers locked in gains and rebalanced toward undervalued defensives.",
    sentiment: [-0.78, -0.3],
    impact: [-0.038, -0.01],
    sectors: ["Technology", "Health Care", "Financials", "Energy", "Industrials", "Consumer"],
  },
  {
    kind: "company",
    scope: "symbol",
    headline: "Cluster of C-suite insiders buy {symbol} shares on open market",
    summary:
      "Form 4 filings showed the CEO and CFO purchasing stock following a 15% pullback.",
    sentiment: [0.25, 0.68],
    impact: [0.008, 0.032],
  },
];

export const STRESS_SCENARIOS = [
  {
    id: "crash",
    label: "2008-Style Systemic Crash",
    description: "Severe liquidity shock; high-beta growth stocks drop sharpest",
    marketShock: -0.24,
  },
  {
    id: "stagflation",
    label: "Stagflation & Rate Spike",
    description: "Inflation resurgence compresses valuation multiples",
    marketShock: -0.14,
  },
  {
    id: "correction",
    label: "10% Healthy Pullback",
    description: "Standard mid-cycle drawdown clearing excess leverage",
    marketShock: -0.1,
  },
  {
    id: "melt-up",
    label: "AI & Liquidity Melt-Up",
    description: "Broad risk-on expansion with short-covering momentum",
    marketShock: 0.18,
  },
  {
    id: "soft-landing",
    label: "Goldilocks Expansion",
    description: "Steady earnings growth and easing monetary policy",
    marketShock: 0.11,
  },
] as const;
