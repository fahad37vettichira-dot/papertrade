export function fmtMoney(value: number, decimals = 2): string {
  if (!Number.isFinite(value)) return "$0.00";
  const sign = value < 0 ? "-" : "";
  const abs = Math.abs(value);
  return `${sign}$${abs.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
}

export function fmtSignedMoney(value: number, decimals = 2): string {
  if (!Number.isFinite(value)) return "$0.00";
  return `${value > 0 ? "+" : value < 0 ? "-" : ""}$${Math.abs(value).toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}`;
}

export function fmtCompact(value: number): string {
  const abs = Math.abs(value);
  const sign = value < 0 ? "-" : "";
  if (abs >= 1_000_000_000) return `${sign}$${(abs / 1_000_000_000).toFixed(2)}B`;
  if (abs >= 1_000_000) return `${sign}$${(abs / 1_000_000).toFixed(2)}M`;
  if (abs >= 10_000) return `${sign}$${(abs / 1_000).toFixed(1)}K`;
  return `${sign}$${abs.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}

export function fmtPct(fraction: number, decimals = 2): string {
  if (!Number.isFinite(fraction)) return "0.00%";
  return `${(fraction * 100).toFixed(decimals)}%`;
}

export function fmtSignedPct(fraction: number, decimals = 2): string {
  if (!Number.isFinite(fraction)) return "0.00%";
  return `${fraction > 0 ? "+" : ""}${(fraction * 100).toFixed(decimals)}%`;
}

export function fmtNum(value: number, decimals = 0): string {
  return Number(value).toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function fmtShares(shares: number): string {
  if (!Number.isFinite(shares)) return "0";
  if (Math.abs(shares - Math.round(shares)) < 1e-6) return Math.round(shares).toLocaleString("en-US");
  return shares.toLocaleString("en-US", { maximumFractionDigits: 4 });
}

export function fmtCompactNum(value: number): string {
  if (Math.abs(value) >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(1)}B`;
  if (Math.abs(value) >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (Math.abs(value) >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return value.toFixed(0);
}

export type Tone = "up" | "down" | "flat" | "accent" | "warn" | "violet";

export function toneOf(value: number, epsilon = 1e-9): Tone {
  if (value > epsilon) return "up";
  if (value < -epsilon) return "down";
  return "flat";
}

export function toneClass(value: number, epsilon = 1e-9): string {
  const tone = toneOf(value, epsilon);
  return tone === "up" ? "up" : tone === "down" ? "down" : "flat";
}

export function fmtDuration(days: number): string {
  if (days < 5) return `${days} session${days === 1 ? "" : "s"}`;
  if (days < 21) return `${Math.round(days / 5)} week${days < 10 ? "" : "s"}`;
  if (days < 252) return `${(days / 21).toFixed(1)} months`;
  return `${(days / 252).toFixed(1)} years`;
}
