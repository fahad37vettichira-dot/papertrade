import { TICKER_BY_SYMBOL } from "@/lib/universe";

export type RealCandle = {
  date: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  adjustedClose: number;
  volume: number;
};

export type ForecastHorizonKey = "1D" | "1W" | "1M" | "3M";
export const FORECAST_HORIZONS: Array<{ key: ForecastHorizonKey; label: string; days: number }> = [
  { key: "1D", label: "Next day", days: 1 },
  { key: "1W", label: "Next week", days: 5 },
  { key: "1M", label: "Next month", days: 21 },
  { key: "3M", label: "Next 3 months", days: 63 },
];

export type ForecastPoint = {
  low: number;
  median: number;
  high: number;
  probabilityUp: number;
};

export type ModelForecast = {
  id: "monte-carlo" | "linear-regression" | "random-forest" | "arima" | "garch" | "time-series";
  name: string;
  method: string;
  accuracy5d: number | null;
  validationSamples: number;
  forecasts: Record<ForecastHorizonKey, ForecastPoint>;
};

export type IndicatorReading = {
  value: number | null;
  signal: "Bullish" | "Bearish" | "Neutral" | "Unavailable";
  explanation: string;
};

export type RealMarketAnalysis = {
  symbol: string;
  companyName: string;
  currency: string;
  source: "Yahoo Finance historical chart";
  sourceType: "unofficial daily historical feed; may be delayed";
  latestDate: string;
  latestClose: number;
  coverageStart: string;
  barsReturned: number;
  history: RealCandle[];
  forecasts: ModelForecast[];
  indicators: {
    rsi14: IndicatorReading;
    macd: IndicatorReading;
    movingAverages: IndicatorReading;
    bollinger: IndicatorReading;
    vwap20: IndicatorReading;
    stochasticRsi: IndicatorReading;
    adx14: IndicatorReading;
    supertrend: IndicatorReading;
    volume: IndicatorReading;
    support: number;
    resistance: number;
    atr14: number;
    fibLevels: Array<{ label: string; price: number }>;
    trend: string;
    pattern: string;
    annualizedVolatility: number;
    averageDailyVolume20: number;
  };
  signal: {
    label: "Strong Buy" | "Buy" | "Hold" | "Sell" | "Strong Sell";
    score: number;
    suggestedEntry: number;
    target: number;
    stopLoss: number;
    riskReward: number;
    expectedRangeLow: number;
    expectedRangeHigh: number;
    modelAgreement: number;
    indicatorSummary: string[];
    reasons: string[];
    horizon: "3M";
  };
  validation: {
    method: string;
    window: "5 trading days";
    startDate: string;
    endDate: string;
    warning: string;
  };
};

type YahooChart = {
  chart?: {
    error?: { description?: string; code?: string } | null;
    result?: Array<{
      meta?: { symbol?: string; currency?: string; exchangeTimezoneName?: string };
      timestamp?: number[];
      indicators?: {
        quote?: Array<{
          open?: Array<number | null>;
          high?: Array<number | null>;
          low?: Array<number | null>;
          close?: Array<number | null>;
          volume?: Array<number | null>;
        }>;
        adjclose?: Array<{ adjclose?: Array<number | null> }>;
      };
    }> | null;
  };
};

const HISTORY_TTL_MS = 15 * 60 * 1000;
const historyCache = new Map<string, { expiresAt: number; history: RealCandle[]; currency: string }>();
const inFlight = new Map<string, Promise<{ history: RealCandle[]; currency: string }>>();
const analysisCache = new Map<string, { expiresAt: number; analysis: RealMarketAnalysis }>();
const analysisInFlight = new Map<string, Promise<RealMarketAnalysis>>();
const DAY_MS = 86_400_000;
const YEAR_DAYS = 252;
const NORMAL_Z90 = 1.6448536269514722;
const round2 = (x: number) => Math.round(x * 100) / 100;
const average = (values: number[]) => values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
const variance = (values: number[]) => {
  if (values.length < 2) return 0;
  const m = average(values);
  return values.reduce((s, v) => s + (v - m) ** 2, 0) / (values.length - 1);
};
const standardDeviation = (values: number[]) => Math.sqrt(Math.max(0, variance(values)));

function normalCdf(value: number): number {
  // Abramowitz–Stegun approximation; sufficient for labelled model probabilities.
  const x = Math.abs(value);
  const t = 1 / (1 + 0.2316419 * x);
  const density = 0.3989422804014327 * Math.exp(-0.5 * x * x);
  const tail = density * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
  return value >= 0 ? 1 - tail : tail;
}

function validateSymbol(value: string): string {
  const symbol = value.trim().toUpperCase();
  if (!TICKER_BY_SYMBOL[symbol]) throw new Error("This ticker is not in the supported practice-stock list.");
  return symbol;
}

/**
 * Retrieves actual, daily Yahoo Finance chart data server-side.
 * This unofficial public feed is not an exchange entitlement or a guaranteed service.
 * Response is cached per server process to avoid repeatedly hitting the public endpoint.
 */
export async function getRealHistory(rawSymbol: string): Promise<{ history: RealCandle[]; currency: string }> {
  const symbol = validateSymbol(rawSymbol);
  const cached = historyCache.get(symbol);
  if (cached && cached.expiresAt > Date.now()) return { history: cached.history, currency: cached.currency };
  const pending = inFlight.get(symbol);
  if (pending) return pending;

  const request = (async () => {
    const url = new URL(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}`);
    url.searchParams.set("range", "10y");
    url.searchParams.set("interval", "1d");
    url.searchParams.set("events", "div,splits");
    url.searchParams.set("includeAdjustedClose", "true");

    let response: Response;
    try {
      response = await fetch(url, {
        headers: {
          accept: "application/json",
          "user-agent": "Mozilla/5.0 (compatible; PaperTrade/1.0; educational market history)",
        },
        cache: "no-store",
        signal: AbortSignal.timeout(15_000),
      });
    } catch {
      throw new Error("The public historical-price feed is temporarily unavailable. Your practice prices have not changed.");
    }
    if (!response.ok) throw new Error(`The market-history provider returned HTTP ${response.status}. Try again later.`);

    const payload = (await response.json()) as YahooChart;
    const result = payload.chart?.result?.[0];
    if (payload.chart?.error || !result || !result.timestamp?.length) {
      const reason = payload.chart?.error?.description;
      throw new Error(reason ? `Historical data unavailable: ${reason}` : "No daily history is available for this ticker.");
    }
    if (result.meta?.symbol?.toUpperCase() !== symbol) {
      throw new Error("The data provider returned a different ticker. Historical data was rejected.");
    }

    const q = result.indicators?.quote?.[0];
    if (!q?.close || !q.open || !q.high || !q.low) throw new Error("The data provider returned incomplete daily candles.");
    const adjusted = result.indicators?.adjclose?.[0]?.adjclose;
    const history: RealCandle[] = [];
    for (let i = 0; i < result.timestamp.length; i++) {
      const open = q.open[i], high = q.high[i], low = q.low[i], close = q.close[i];
      const volume = q.volume?.[i] ?? 0;
      if (![open, high, low, close].every(v => typeof v === "number" && Number.isFinite(v) && v > 0)) continue;
      const timestamp = result.timestamp[i];
      const date = new Date(timestamp * 1000).toISOString().slice(0, 10);
      const adjustedValue = adjusted?.[i];
      const adjustedClose = typeof adjustedValue === "number" && Number.isFinite(adjustedValue) ? adjustedValue : close!;
      history.push({ date, timestamp, open: open!, high: high!, low: low!, close: close!, adjustedClose, volume: typeof volume === "number" && Number.isFinite(volume) ? volume : 0 });
    }
    history.sort((a, b) => a.timestamp - b.timestamp);
    if (history.length < 70) throw new Error("The provider returned fewer than 70 valid daily candles. Predictions need more history.");

    const data = { history, currency: result.meta?.currency || "USD" };
    historyCache.set(symbol, { ...data, expiresAt: Date.now() + HISTORY_TTL_MS });
    return data;
  })();

  inFlight.set(symbol, request);
  try {
    return await request;
  } finally {
    inFlight.delete(symbol);
  }
}

function ema(values: number[], period: number): number[] {
  if (!values.length) return [];
  const alpha = 2 / (period + 1);
  const output = [values[0]];
  for (let i = 1; i < values.length; i++) output.push(alpha * values[i] + (1 - alpha) * output[i - 1]);
  return output;
}

function sma(values: number[], period: number): number | null {
  if (values.length < period) return null;
  return average(values.slice(-period));
}

function rsiSeries(closes: number[], period = 14): Array<number | null> {
  const output: Array<number | null> = Array(closes.length).fill(null);
  if (closes.length <= period) return output;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const move = closes[i] - closes[i - 1];
    if (move > 0) gain += move;
    else loss -= move;
  }
  gain /= period;
  loss /= period;
  const calculate = () => loss <= 1e-12 ? (gain <= 1e-12 ? 50 : 100) : 100 - 100 / (1 + gain / loss);
  output[period] = calculate();
  for (let i = period + 1; i < closes.length; i++) {
    const move = closes[i] - closes[i - 1];
    gain = (gain * (period - 1) + Math.max(move, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-move, 0)) / period;
    output[i] = calculate();
  }
  return output;
}

function atrSeries(bars: RealCandle[], period = 14): Array<number | null> {
  const trs: number[] = [];
  for (let i = 0; i < bars.length; i++) {
    const prevClose = bars[i - 1]?.close ?? bars[i].close;
    trs.push(Math.max(bars[i].high - bars[i].low, Math.abs(bars[i].high - prevClose), Math.abs(bars[i].low - prevClose)));
  }
  const output: Array<number | null> = Array(bars.length).fill(null);
  if (trs.length < period) return output;
  let value = average(trs.slice(0, period));
  output[period - 1] = value;
  for (let i = period; i < trs.length; i++) {
    value = ((period - 1) * value + trs[i]) / period;
    output[i] = value;
  }
  return output;
}

function adxValue(bars: RealCandle[], period = 14): { adx: number | null; plusDi: number | null; minusDi: number | null } {
  if (bars.length < period * 2 + 2) return { adx: null, plusDi: null, minusDi: null };
  const tr: number[] = [], plus: number[] = [], minus: number[] = [];
  for (let i = 1; i < bars.length; i++) {
    const up = bars[i].high - bars[i - 1].high;
    const down = bars[i - 1].low - bars[i].low;
    plus.push(up > down && up > 0 ? up : 0);
    minus.push(down > up && down > 0 ? down : 0);
    tr.push(Math.max(bars[i].high - bars[i].low, Math.abs(bars[i].high - bars[i - 1].close), Math.abs(bars[i].low - bars[i - 1].close)));
  }
  const dx: number[] = [];
  for (let end = period - 1; end < tr.length; end++) {
    const trSum = tr.slice(end - period + 1, end + 1).reduce((a, b) => a + b, 0);
    const pSum = plus.slice(end - period + 1, end + 1).reduce((a, b) => a + b, 0);
    const mSum = minus.slice(end - period + 1, end + 1).reduce((a, b) => a + b, 0);
    const pdi = trSum ? (100 * pSum) / trSum : 0;
    const mdi = trSum ? (100 * mSum) / trSum : 0;
    dx.push(pdi + mdi ? (100 * Math.abs(pdi - mdi)) / (pdi + mdi) : 0);
  }
  const tail = dx.slice(-period);
  const adx = average(tail);
  const trSum = tr.slice(-period).reduce((a, b) => a + b, 0);
  const plusDi = trSum ? (100 * plus.slice(-period).reduce((a, b) => a + b, 0)) / trSum : 0;
  const minusDi = trSum ? (100 * minus.slice(-period).reduce((a, b) => a + b, 0)) / trSum : 0;
  return { adx, plusDi, minusDi };
}

function supertrendValue(bars: RealCandle[], atrs: Array<number | null>, period = 10, multiplier = 3): { line: number | null; bullish: boolean } {
  if (bars.length < period + 2) return { line: null, bullish: false };
  let finalUpper = 0, finalLower = 0, bullish = true;
  for (let i = period; i < bars.length; i++) {
    const atr = atrs[i] ?? 0;
    const mid = (bars[i].high + bars[i].low) / 2;
    const upper = mid + multiplier * atr, lower = mid - multiplier * atr;
    if (i === period) {
      finalUpper = upper;
      finalLower = lower;
      bullish = bars[i].close >= mid;
    } else {
      const priorClose = bars[i - 1].close;
      finalUpper = upper < finalUpper || priorClose > finalUpper ? upper : finalUpper;
      finalLower = lower > finalLower || priorClose < finalLower ? lower : finalLower;
      bullish = bars[i].close > finalUpper ? true : bars[i].close < finalLower ? false : bullish;
    }
  }
  return { line: bullish ? finalLower : finalUpper, bullish };
}

function linearFit(values: number[]): { intercept: number; slope: number; residualSigma: number } {
  const n = values.length;
  if (n < 3) return { intercept: values.at(-1) ?? 0, slope: 0, residualSigma: 0 };
  const xMean = (n - 1) / 2, yMean = average(values);
  let covariance = 0, xVariance = 0;
  for (let i = 0; i < n; i++) {
    covariance += (i - xMean) * (values[i] - yMean);
    xVariance += (i - xMean) ** 2;
  }
  const slope = xVariance ? covariance / xVariance : 0;
  const intercept = yMean - slope * xMean;
  const residuals = values.map((v, i) => v - (intercept + slope * i));
  return { intercept, slope, residualSigma: Math.sqrt(residuals.reduce((s, r) => s + r * r, 0) / Math.max(1, n - 2)) };
}

function getReturns(bars: RealCandle[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < bars.length; i++) {
    const a = bars[i - 1].adjustedClose, b = bars[i].adjustedClose;
    if (a > 0 && b > 0) out.push(Math.log(b / a));
  }
  return out;
}

function arimaFit(returns: number[]): { mean: number; phi: number; innovationSigma: number; last: number } {
  const tail = returns.slice(-252);
  const mean = average(tail);
  let numerator = 0, denominator = 0;
  for (let i = 1; i < tail.length; i++) {
    numerator += (tail[i - 1] - mean) * (tail[i] - mean);
    denominator += (tail[i - 1] - mean) ** 2;
  }
  const phi = Math.max(-0.95, Math.min(0.95, denominator ? numerator / denominator : 0));
  const residuals = tail.slice(1).map((r, i) => r - mean - phi * (tail[i] - mean));
  return { mean, phi, innovationSigma: Math.max(1e-5, standardDeviation(residuals)), last: tail.at(-1) ?? mean };
}

function arimaPoint(current: number, model: ReturnType<typeof arimaFit>, days: number): ForecastPoint {
  let last = model.last, logReturn = 0, oneStepVariance = model.innovationSigma ** 2, totalVariance = 0;
  for (let i = 0; i < days; i++) {
    const forecastReturn = model.mean + model.phi * (last - model.mean);
    logReturn += forecastReturn;
    last = forecastReturn;
    oneStepVariance = model.innovationSigma ** 2 + model.phi ** 2 * oneStepVariance;
    totalVariance += oneStepVariance;
  }
  const median = current * Math.exp(logReturn);
  const radius = NORMAL_Z90 * Math.sqrt(totalVariance);
  return { low: median * Math.exp(-radius), median, high: median * Math.exp(radius), probabilityUp: normalCdf(logReturn / Math.max(1e-9, Math.sqrt(totalVariance))) };
}

function garchFit(returns: number[]) {
  const data = returns.slice(-252);
  const unconditional = Math.max(variance(data), 1e-8);
  let best = { alpha: 0.08, beta: 0.88, omega: unconditional * 0.04, variance: unconditional, loss: Infinity };
  for (let ai = 1; ai <= 8; ai++) {
    const alpha = ai * 0.025;
    for (let bi = 10; bi <= 19; bi++) {
      const beta = bi * 0.05;
      if (alpha + beta >= 0.99) continue;
      const omega = unconditional * (1 - alpha - beta);
      let h = unconditional, loss = 0;
      for (const r of data) {
        h = Math.max(1e-10, omega + alpha * r * r + beta * h);
        loss += Math.log(h) + (r * r) / h;
      }
      if (loss < best.loss) best = { alpha, beta, omega, variance: h, loss };
    }
  }
  return best;
}

function garchPoint(current: number, meanDaily: number, lastReturn: number, fit: ReturnType<typeof garchFit>, days: number): ForecastPoint {
  let forecastVariance = fit.omega + fit.alpha * lastReturn ** 2 + fit.beta * fit.variance;
  let totalVariance = 0;
  const longRun = fit.omega / Math.max(1e-6, 1 - fit.alpha - fit.beta);
  for (let i = 0; i < days; i++) {
    if (i > 0) forecastVariance = fit.omega + (fit.alpha + fit.beta) * forecastVariance;
    forecastVariance = Math.max(1e-10, forecastVariance);
    totalVariance += forecastVariance;
    if (i > 0 && forecastVariance < longRun * 0.5) forecastVariance = longRun;
  }
  const median = current * Math.exp(meanDaily * days);
  const radius = NORMAL_Z90 * Math.sqrt(totalVariance);
  return { low: median * Math.exp(-radius), median, high: median * Math.exp(radius), probabilityUp: normalCdf(Math.log(median / current) / Math.max(1e-9, Math.sqrt(totalVariance))) };
}

type TrainingSample = { x: number[]; y: number };
type Tree = number | { feature: number; threshold: number; left: Tree; right: Tree };

function seededRandom(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function buildFeatures(bars: RealCandle[], closeIndex: number, returns = getReturns(bars)): number[] | null {
  if (closeIndex < 25) return null;
  const endReturnIndex = closeIndex - 1;
  const recent = returns.slice(Math.max(0, endReturnIndex - 19), endReturnIndex + 1);
  const closes = bars.slice(0, closeIndex + 1).map(b => b.adjustedClose);
  const average20 = sma(closes, 20) ?? closes.at(-1)!;
  const rsis = rsiSeries(closes, 14);
  const currentRsi = rsis.at(-1) ?? 50;
  const volumes = bars.slice(Math.max(0, closeIndex - 19), closeIndex + 1).map(b => b.volume).filter(v => v > 0);
  const avgVol = average(volumes);
  const currentVol = bars[closeIndex].volume;
  const lagReturns = [1, 2, 3, 4, 5].map(lag => returns[endReturnIndex - lag + 1] ?? 0);
  return [
    ...lagReturns,
    average(recent.slice(-5)),
    average(recent),
    standardDeviation(recent),
    average20 ? closes.at(-1)! / average20 - 1 : 0,
    currentRsi / 100 - 0.5,
    avgVol ? Math.log(Math.max(0.01, currentVol / avgVol)) : 0,
  ];
}

function trainingSamples(bars: RealCandle[]): TrainingSample[] {
  const returns = getReturns(bars);
  const out: TrainingSample[] = [];
  for (let i = 25; i < bars.length - 5; i++) {
    const x = buildFeatures(bars, i, returns);
    if (!x) continue;
    const y = Math.log(bars[i + 5].adjustedClose / bars[i].adjustedClose);
    if (Number.isFinite(y)) out.push({ x, y });
  }
  return out;
}

function trainTree(samples: TrainingSample[], random: () => number, maxDepth = 4, minLeaf = 9): Tree {
  const meanY = average(samples.map(s => s.y));
  if (samples.length < minLeaf * 2 || maxDepth <= 0) return meanY;
  const featureCount = samples[0]?.x.length ?? 0;
  const featureIds = Array.from({ length: featureCount }, (_, i) => i);
  for (let i = featureIds.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [featureIds[i], featureIds[j]] = [featureIds[j], featureIds[i]];
  }
  const candidates = featureIds.slice(0, Math.max(2, Math.ceil(Math.sqrt(featureCount))));
  let best: { feature: number; threshold: number; loss: number; left: TrainingSample[]; right: TrainingSample[] } | null = null;
  const baseline = samples.reduce((sum, s) => sum + (s.y - meanY) ** 2, 0);
  for (const feature of candidates) {
    const sorted = samples.map(s => s.x[feature]).sort((a, b) => a - b);
    for (const q of [0.2, 0.4, 0.6, 0.8]) {
      const threshold = sorted[Math.floor(q * (sorted.length - 1))];
      const left = samples.filter(s => s.x[feature] <= threshold);
      const right = samples.filter(s => s.x[feature] > threshold);
      if (left.length < minLeaf || right.length < minLeaf) continue;
      const lm = average(left.map(s => s.y)), rm = average(right.map(s => s.y));
      const loss = left.reduce((sum, s) => sum + (s.y - lm) ** 2, 0) + right.reduce((sum, s) => sum + (s.y - rm) ** 2, 0);
      if (loss < baseline && (!best || loss < best.loss)) best = { feature, threshold, loss, left, right };
    }
  }
  if (!best) return meanY;
  return { feature: best.feature, threshold: best.threshold, left: trainTree(best.left, random, maxDepth - 1, minLeaf), right: trainTree(best.right, random, maxDepth - 1, minLeaf) };
}

function predictTree(tree: Tree, values: number[]): number {
  if (typeof tree === "number") return tree;
  return predictTree(values[tree.feature] <= tree.threshold ? tree.left : tree.right, values);
}

function fitForest(samples: TrainingSample[], seed: number, treeCount: number, maxSamples: number) {
  const training = samples.slice(-maxSamples);
  const random = seededRandom(seed);
  const trees: Tree[] = [];
  for (let t = 0; t < treeCount; t++) {
    const boot: TrainingSample[] = [];
    for (let i = 0; i < training.length; i++) boot.push(training[Math.floor(random() * training.length)]);
    trees.push(trainTree(boot, random));
  }
  return (x: number[]) => trees.map(tree => predictTree(tree, x));
}

function forestForecast(bars: RealCandle[], horizonDays: Record<ForecastHorizonKey, number>, seed: number) {
  const samples = trainingSamples(bars);
  const current = bars.at(-1)!.adjustedClose;
  const latestX = buildFeatures(bars, bars.length - 1);
  const treeReturns: number[] = [];
  let accuracy = 0, validated = 0, rmse = 0;
  if (samples.length >= 60 && latestX) {
    const split = Math.max(40, Math.floor(samples.length * 0.8));
    const train = samples.slice(0, split), test = samples.slice(split);
    const validationPredict = fitForest(train, seed + 17, 16, 400);
    const errors = test.map(sample => {
      const pred = average(validationPredict(sample.x));
      if (Math.abs(sample.y) > 0.001) {
        validated++;
        if (Math.sign(pred) === Math.sign(sample.y)) accuracy++;
      }
      return sample.y - pred;
    });
    rmse = Math.max(0.0007, Math.sqrt(average(errors.map(e => e * e))));
    treeReturns.push(...fitForest(samples, seed, 28, 500)(latestX));
  } else {
    treeReturns.push(average(getReturns(bars).slice(-20)) * 5);
    rmse = standardDeviation(getReturns(bars).slice(-60)) * Math.sqrt(5);
  }
  const fiveDayMedian = average(treeReturns);
  const uncertainty = Math.max(rmse, standardDeviation(treeReturns), 0.001);
  const forecasts = Object.fromEntries(FORECAST_HORIZONS.map(({ key, days }) => {
    const median = current * Math.exp(fiveDayMedian * days / 5);
    const radius = NORMAL_Z90 * uncertainty * Math.sqrt(days / 5);
    return [key, { low: median * Math.exp(-radius), median, high: median * Math.exp(radius), probabilityUp: median > current ? 0.6 : median < current ? 0.4 : 0.5 }];
  })) as Record<ForecastHorizonKey, ForecastPoint>;
  return { forecasts, accuracy5d: validated ? accuracy / validated : null, validationSamples: validated };
}

function monteCarloForecast(bars: RealCandle[], horizonDays: Record<ForecastHorizonKey, number>, seed: number, runCount = 2000) {
  const returns = getReturns(bars).slice(-252);
  const drift = average(returns);
  const vol = Math.max(0.0005, standardDeviation(returns));
  const current = bars.at(-1)!.adjustedClose;
  const random = seededRandom(seed);
  const endpoints = new Map<ForecastHorizonKey, number[]>();
  for (const { key } of FORECAST_HORIZONS) endpoints.set(key, []);
  const runs = Math.max(100, Math.min(2000, Math.round(runCount)));
  const maxDays = Math.max(...Object.values(horizonDays));
  for (let p = 0; p < runs; p++) {
    let price = current;
    let u1 = Math.max(random(), 1e-9), u2 = random();
    let spare = Math.sqrt(-2 * Math.log(u1)) * Math.sin(2 * Math.PI * u2);
    for (let d = 1; d <= maxDays; d++) {
      const z = spare;
      u1 = Math.max(random(), 1e-9); u2 = random();
      spare = Math.sqrt(-2 * Math.log(u1)) * Math.sin(2 * Math.PI * u2);
      price = Math.max(0.01, price * Math.exp(drift + vol * z));
      for (const { key, days } of FORECAST_HORIZONS) if (d === horizonDays[key] && days === d) endpoints.get(key)!.push(price);
    }
  }
  const forecasts = Object.fromEntries(FORECAST_HORIZONS.map(({ key }) => {
    const values = endpoints.get(key)!.sort((a, b) => a - b);
    if (!values.length) throw new Error(`Monte Carlo path did not reach ${key}.`);
    const at = (q: number) => values[Math.min(values.length - 1, Math.floor(q * (values.length - 1)))];
    return [key, { low: at(0.05), median: at(0.5), high: at(0.95), probabilityUp: values.filter(v => v > current).length / values.length }];
  })) as Record<ForecastHorizonKey, ForecastPoint>;
  return { forecasts, runCount: runs };
}

function regressionForecast(bars: RealCandle[], horizonDays: Record<ForecastHorizonKey, number>) {
  const current = bars.at(-1)!.adjustedClose;
  const logClose = bars.slice(-126).map(b => Math.log(b.adjustedClose));
  const fit = linearFit(logClose);
  const forecasts = Object.fromEntries(FORECAST_HORIZONS.map(({ key, days }) => [key, forecastFromLinear(fit, current, logClose.length, horizonDays[key] ?? days)])) as Record<ForecastHorizonKey, ForecastPoint>;
  return { forecasts, fit };
}

function recentTrendForecast(bars: RealCandle[], horizonDays: Record<ForecastHorizonKey, number>) {
  const returns = getReturns(bars);
  const current = bars.at(-1)!.adjustedClose;
  const dailyDrift = average(returns.slice(-20));
  const dailyVol = Math.max(0.0005, standardDeviation(returns.slice(-60)));
  return Object.fromEntries(FORECAST_HORIZONS.map(({ key }) => {
    const h = horizonDays[key];
    const median = current * Math.exp(dailyDrift * h);
    const radius = NORMAL_Z90 * dailyVol * Math.sqrt(h);
    return [key, { low: median * Math.exp(-radius), median, high: median * Math.exp(radius), probabilityUp: normalCdf(Math.log(median / current) / Math.max(1e-9, radius / NORMAL_Z90)) }];
  })) as Record<ForecastHorizonKey, ForecastPoint>;
}

function walkForwardAccuracy(bars: RealCandle[], seed: number) {
  const start = Math.max(90, bars.length - 100);
  const names = ["monte-carlo", "linear-regression", "random-forest", "arima", "time-series"] as const;
  const wins: Record<(typeof names)[number], number> = { "monte-carlo": 0, "linear-regression": 0, "random-forest": 0, arima: 0, "time-series": 0 };
  const counts = { ...wins };
  const origins: number[] = [];
  for (let i = start; i + 5 < bars.length; i += 5) origins.push(i);
  for (const [j, i] of origins.entries()) {
    const train = bars.slice(0, i + 1);
    const current = train.at(-1)!.adjustedClose;
    const actual = Math.log(bars[i + 5].adjustedClose / current);
    if (Math.abs(actual) < 0.001) continue;
    const returns = getReturns(train).slice(-252);
    const mcDirection = average(returns);
    const regression = linearFit(train.slice(-126).map(b => Math.log(b.adjustedClose)));
    const lrDirection = regression.slope;
    const arima = arimaFit(returns);
    const arimaDirection = arima.mean + arima.phi * (arima.last - arima.mean);
    const tsDirection = average(returns.slice(-20));
    const feature = buildFeatures(train, train.length - 1);
    let rfDirection = 0;
    if (feature) {
      const samples = trainingSamples(train);
      if (samples.length >= 40) rfDirection = average(fitForest(samples, seed + j * 31 + i, 8, 220)(feature)) / 5;
    }
    const estimates: Record<(typeof names)[number], number> = {
      "monte-carlo": mcDirection,
      "linear-regression": lrDirection,
      "random-forest": rfDirection,
      arima: arimaDirection,
      "time-series": tsDirection,
    };
    for (const name of names) {
      if (Math.abs(estimates[name]) < 0.00001) continue;
      counts[name]++;
      if (Math.sign(estimates[name]) === Math.sign(actual)) wins[name]++;
    }
  }
  return Object.fromEntries(names.map(name => [name, { accuracy5d: counts[name] ? wins[name] / counts[name] : null, validationSamples: counts[name] }])) as Record<(typeof names)[number], { accuracy5d: number | null; validationSamples: number }>;
}

function indicatorSignal(value: number | null, signal: IndicatorReading["signal"], explanation: string): IndicatorReading {
  return { value, signal: value === null ? "Unavailable" : signal, explanation };
}

function analyzeIndicators(bars: RealCandle[]) {
  const closes = bars.map(b => b.adjustedClose);
  const latest = bars.at(-1)!;
  const current = latest.adjustedClose;
  const sma20 = sma(closes, 20), sma50 = sma(closes, 50), sma200 = sma(closes, 200);
  const rsiValues = rsiSeries(closes, 14);
  const rsi = rsiValues.at(-1) ?? null;
  const ema12 = ema(closes, 12), ema26 = ema(closes, 26);
  const macdLine = ema12.map((v, i) => v - ema26[i]);
  const macdSignal = ema(macdLine, 9).at(-1) ?? null;
  const macd = macdLine.at(-1) ?? null;
  const macdHistogram = macd !== null && macdSignal !== null ? macd - macdSignal : null;
  const last20 = bars.slice(-20);
  const bollingerMiddle = sma(closes, 20);
  const bbStd = standardDeviation(closes.slice(-20));
  const bollingerLower = bollingerMiddle === null ? null : bollingerMiddle - 2 * bbStd;
  const bollingerUpper = bollingerMiddle === null ? null : bollingerMiddle + 2 * bbStd;
  const volumeSum = last20.reduce((s, b) => s + b.volume, 0);
  const averageVolume20 = volumeSum / Math.max(1, last20.length);
  const vwap20 = volumeSum ? last20.reduce((s, b) => s + ((b.high + b.low + b.close) / 3) * b.volume, 0) / volumeSum : null;
  const recentRsi = rsiValues.slice(-14).filter((v): v is number => v !== null);
  const minRsi = Math.min(...recentRsi), maxRsi = Math.max(...recentRsi);
  const stochRsi = recentRsi.length >= 5 && maxRsi !== minRsi ? ((rsi ?? 50) - minRsi) / (maxRsi - minRsi) * 100 : null;
  const adx = adxValue(bars, 14);
  const atrs = atrSeries(bars, 14);
  const atr14 = atrs.at(-1) ?? 0;
  const supertrend = supertrendValue(bars, atrs);
  const yearBars = bars.slice(-252);
  const yearHigh = Math.max(...yearBars.map(b => b.high));
  const yearLow = Math.min(...yearBars.map(b => b.low));
  const pivotLows = bars.slice(-126).filter((b, i, arr) => i > 1 && i < arr.length - 2 && b.low <= arr[i - 1].low && b.low <= arr[i - 2].low && b.low < arr[i + 1].low && b.low < arr[i + 2].low).map(b => b.low);
  const pivotHighs = bars.slice(-126).filter((b, i, arr) => i > 1 && i < arr.length - 2 && b.high >= arr[i - 1].high && b.high >= arr[i - 2].high && b.high > arr[i + 1].high && b.high > arr[i + 2].high).map(b => b.high);
  const support = pivotLows.filter(v => v < current).sort((a, b) => b - a)[0] ?? Math.min(...bars.slice(-60).map(b => b.low));
  const resistance = pivotHighs.filter(v => v > current).sort((a, b) => a - b)[0] ?? Math.max(...bars.slice(-60).map(b => b.high));
  const old = bars.slice(-40, -20), fresh = bars.slice(-20);
  const higherHigh = Math.max(...fresh.map(b => b.high)) > Math.max(...old.map(b => b.high));
  const higherLow = Math.min(...fresh.map(b => b.low)) > Math.min(...old.map(b => b.low));
  const lowerHigh = Math.max(...fresh.map(b => b.high)) < Math.max(...old.map(b => b.high));
  const lowerLow = Math.min(...fresh.map(b => b.low)) < Math.min(...old.map(b => b.low));
  const previous20High = Math.max(...bars.slice(-21, -1).map(b => b.high));
  const previous20Low = Math.min(...bars.slice(-21, -1).map(b => b.low));
  const pattern = current > previous20High ? "20-day high breakout" : current < previous20Low ? "20-day low breakdown" : higherHigh && higherLow ? "Higher highs and higher lows" : lowerHigh && lowerLow ? "Lower highs and lower lows" : "No clear 20-day price pattern";
  const trend = current > (sma20 ?? current) && (sma20 ?? current) > (sma50 ?? current) ? "Uptrend" : current < (sma20 ?? current) && (sma20 ?? current) < (sma50 ?? current) ? "Downtrend" : "Mixed trend";
  const volumeRatio = averageVolume20 ? latest.volume / averageVolume20 : null;
  const returns = getReturns(bars).slice(-252);
  const volatility = standardDeviation(returns) * Math.sqrt(YEAR_DAYS);
  const fib = [0.236, 0.382, 0.5, 0.618, 0.786].map(ratio => ({ label: `${(ratio * 100).toFixed(1)}%`, price: yearHigh - (yearHigh - yearLow) * ratio }));

  return {
    rsi14: indicatorSignal(rsi, rsi === null ? "Unavailable" : rsi < 35 ? "Bullish" : rsi > 70 ? "Bearish" : "Neutral", rsi === null ? "Need 15 daily prices." : rsi < 35 ? "Below 35; historically associated with selling pressure. Not a timing guarantee." : rsi > 70 ? "Above 70; recent gains are extended." : "Between 35 and 70."),
    macd: indicatorSignal(macdHistogram, macdHistogram === null ? "Unavailable" : macdHistogram > 0 ? "Bullish" : macdHistogram < 0 ? "Bearish" : "Neutral", macdHistogram === null ? "Need more daily history." : `MACD ${macd!.toFixed(2)}; signal ${macdSignal!.toFixed(2)}.`),
    movingAverages: indicatorSignal(sma20 && sma50 ? current / sma20 - 1 : null, sma20 && sma50 ? (current > sma20 && sma20 > sma50 ? "Bullish" : current < sma20 && sma20 < sma50 ? "Bearish" : "Neutral") : "Unavailable", sma20 && sma50 ? `20-day ${sma20.toFixed(2)}; 50-day ${sma50.toFixed(2)}; 200-day ${sma200?.toFixed(2) ?? "not available"}.` : "Need more daily history."),
    bollinger: indicatorSignal(bollingerUpper ? (current - bollingerMiddle!) / (2 * bbStd || 1) : null, bollingerUpper ? current > bollingerUpper ? "Bearish" : current < bollingerLower! ? "Bullish" : "Neutral" : "Unavailable", bollingerUpper ? `20-day range ${bollingerLower!.toFixed(2)}–${bollingerUpper.toFixed(2)}.` : "Need 20 daily prices."),
    vwap20: indicatorSignal(vwap20, vwap20 ? current >= vwap20 ? "Bullish" : "Bearish" : "Unavailable", vwap20 ? `20-session volume-weighted average: ${vwap20.toFixed(2)}.` : "No usable volume."),
    stochasticRsi: indicatorSignal(stochRsi, stochRsi === null ? "Unavailable" : stochRsi < 20 ? "Bullish" : stochRsi > 80 ? "Bearish" : "Neutral", stochRsi === null ? "Need more RSI observations." : `Stochastic RSI ${stochRsi.toFixed(0)} (0–100).`),
    adx14: indicatorSignal(adx.adx, adx.adx === null ? "Unavailable" : adx.adx >= 25 ? adx.plusDi! > adx.minusDi! ? "Bullish" : "Bearish" : "Neutral", adx.adx === null ? "Need more daily history." : `ADX ${adx.adx.toFixed(1)}; +DI ${adx.plusDi!.toFixed(1)}, −DI ${adx.minusDi!.toFixed(1)}. ADX measures trend strength, not direction.`),
    supertrend: indicatorSignal(supertrend.line, supertrend.line === null ? "Unavailable" : supertrend.bullish ? "Bullish" : "Bearish", supertrend.line === null ? "Need more daily history." : `ATR-based level: ${supertrend.line.toFixed(2)}.`),
    volume: indicatorSignal(volumeRatio, volumeRatio === null ? "Unavailable" : volumeRatio > 1.5 && latest.close >= latest.open ? "Bullish" : volumeRatio > 1.5 && latest.close < latest.open ? "Bearish" : "Neutral", volumeRatio === null ? "Volume was not supplied." : `Latest volume is ${volumeRatio.toFixed(2)}× the 20-day average.`),
    support: Math.min(current, support),
    resistance: Math.max(current, resistance),
    atr14,
    fibLevels: fib,
    trend,
    pattern,
    annualizedVolatility: volatility,
    averageDailyVolume20: averageVolume20,
  };
}

function forecastFromLinear(fit: ReturnType<typeof linearFit>, current: number, closeCount: number, horizon: number): ForecastPoint {
  const median = Math.exp(fit.intercept + fit.slope * (closeCount - 1 + horizon));
  const radius = NORMAL_Z90 * Math.max(0.001, fit.residualSigma) * Math.sqrt(horizon);
  return { low: median * Math.exp(-radius), median, high: median * Math.exp(radius), probabilityUp: normalCdf(Math.log(median / current) / Math.max(1e-9, radius / NORMAL_Z90)) };
}

function forecastFromTimeSeries(returns: number[], current: number, horizon: number): ForecastPoint {
  const recent = returns.slice(-20), dailyDrift = average(recent), sigma = Math.max(0.0005, standardDeviation(returns.slice(-60)));
  const median = current * Math.exp(dailyDrift * horizon), radius = NORMAL_Z90 * sigma * Math.sqrt(horizon);
  return { low: median * Math.exp(-radius), median, high: median * Math.exp(radius), probabilityUp: normalCdf(Math.log(median / current) / Math.max(1e-9, radius / NORMAL_Z90)) };
}

function modelSignalScore(models: ModelForecast[], indicators: ReturnType<typeof analyzeIndicators>, current: number) {
  let score = 0;
  const values = [indicators.rsi14.signal, indicators.macd.signal, indicators.movingAverages.signal, indicators.bollinger.signal, indicators.vwap20.signal, indicators.stochasticRsi.signal, indicators.adx14.signal, indicators.supertrend.signal, indicators.volume.signal];
  for (const value of values) score += value === "Bullish" ? 1 : value === "Bearish" ? -1 : 0;
  const threeMonth = models.map(m => m.forecasts["3M"]).filter((x): x is ForecastPoint => Boolean(x) && Number.isFinite(x.median));
  const votes = threeMonth.slice(0, 5).map(p => Math.sign(p.median - current));
  for (const vote of votes) score += vote;
  return Math.max(-100, Math.min(100, score / (values.length + votes.length) * 100));
}

export function analyzeRealMarket(symbol: string, input: { history: RealCandle[]; currency: string }): RealMarketAnalysis {
  const { history, currency } = input;
  if (history.length < 70) throw new Error("At least 70 real daily prices are needed for a meaningful comparison.");
  const def = TICKER_BY_SYMBOL[symbol];
  if (!def) throw new Error("This ticker is not supported.");
  const latest = history.at(-1)!;
  const close = latest.adjustedClose;
  const horizonDays = Object.fromEntries(FORECAST_HORIZONS.map(h => [h.key, h.days])) as Record<ForecastHorizonKey, number>;
  const returns = getReturns(history);
  const currentFit = arimaFit(returns);
  const mcSeed = symbol.split("").reduce((s, c) => s * 31 + c.charCodeAt(0), 17) + latest.timestamp;
  const mc = monteCarloForecast(history, horizonDays, mcSeed);
  const linear = regressionForecast(history, horizonDays);
  const forest = forestForecast(history, horizonDays, mcSeed + 101);
  const trend = recentTrendForecast(history, horizonDays);
  const garch = garchFit(returns);
  const indicators = analyzeIndicators(history);
  const validation = walkForwardAccuracy(history, mcSeed);
  const modelForecasts: ModelForecast[] = [
    { id: "monte-carlo", name: "Monte Carlo", method: `2,000 simulated paths; daily drift and volatility fitted to the last ${Math.min(252, returns.length)} actual daily returns.`, accuracy5d: validation["monte-carlo"].accuracy5d, validationSamples: validation["monte-carlo"].validationSamples, forecasts: mc.forecasts },
    { id: "linear-regression", name: "Linear regression", method: "Least-squares regression on the last 126 split/dividend-adjusted closes; interval expands with historical residuals.", accuracy5d: validation["linear-regression"].accuracy5d, validationSamples: validation["linear-regression"].validationSamples, forecasts: linear.forecasts },
    { id: "random-forest", name: "Random forest", method: "28 bootstrapped regression trees trained on lagged real returns, realized volatility, RSI, moving-average distance, and volume; 20% chronological hold-out.", accuracy5d: forest.accuracy5d, validationSamples: forest.validationSamples, forecasts: forest.forecasts },
    { id: "arima", name: "ARIMA (1,1,0)", method: "AR(1) fitted to the last 252 daily log returns (equivalent to ARIMA(1,1,0) on log prices); innovation variance is forecast recursively.", accuracy5d: validation.arima.accuracy5d, validationSamples: validation.arima.validationSamples, forecasts: Object.fromEntries(FORECAST_HORIZONS.map(h => [h.key, arimaPoint(close, currentFit, h.days)])) as Record<ForecastHorizonKey, ForecastPoint> },
    { id: "time-series", name: "Recent time-series trend", method: "The last 20 actual daily log returns, with a 60-day realized-volatility range. This simple baseline is not machine learning.", accuracy5d: validation["time-series"].accuracy5d, validationSamples: validation["time-series"].validationSamples, forecasts: trend },
    { id: "garch", name: "GARCH (1,1) volatility", method: "Gaussian quasi-maximum-likelihood grid fit to the last 252 actual returns; forecasts changing conditional variance, not a market direction.", accuracy5d: null, validationSamples: 0, forecasts: Object.fromEntries(FORECAST_HORIZONS.map(h => [h.key, garchPoint(close, average(returns.slice(-252)), returns.at(-1) ?? 0, garch, h.days)])) as Record<ForecastHorizonKey, ForecastPoint> },
  ];

  const threeMonthModels = modelForecasts.filter(m => m.id !== "garch");
  const score = modelSignalScore(threeMonthModels, indicators, close);
  const label = score >= 48 ? "Strong Buy" : score >= 17 ? "Buy" : score <= -48 ? "Strong Sell" : score <= -17 ? "Sell" : "Hold";
  const agreement = Math.round(100 * threeMonthModels.filter(m => m.forecasts["3M"].median > close).length / Math.max(1, threeMonthModels.length));
  const consensus = threeMonthModels.reduce((sum, m) => sum + m.forecasts["3M"].median, 0) / Math.max(1, threeMonthModels.length);
  const rangeLow = mc.forecasts["3M"].low, rangeHigh = mc.forecasts["3M"].high;
  const stopLoss = Math.max(0.01, Math.min(indicators.support, close - Math.max(indicators.atr14 * 2, close * 0.04)));
  const suggestedTarget = consensus > close ? consensus : mc.forecasts["3M"].high;
  const bearishSignal = score <= -17;
  const protection = Math.max(indicators.atr14 * 2, close * 0.04);
  const signalStop = bearishSignal ? Math.max(indicators.resistance, close + protection) : stopLoss;
  const directionalTarget = bearishSignal ? Math.min(consensus, mc.forecasts["3M"].low) : suggestedTarget;
  const riskReward = bearishSignal
    ? (close - directionalTarget) / Math.max(0.01, signalStop - close)
    : (directionalTarget - close) / Math.max(0.01, close - signalStop);
  const reasons = [
    `Daily history says ${indicators.trend.toLowerCase()}: price ${close >= (sma(history.map(b => b.adjustedClose), 50) ?? close) ? "is" : "is not"} above its 50-day average.`,
    `RSI(14) is ${indicators.rsi14.value?.toFixed(1) ?? "unavailable"}; MACD is ${indicators.macd.signal.toLowerCase()}.`,
    `${threeMonthModels.filter(m => m.forecasts["3M"].median > close).length} of ${threeMonthModels.length} data-based price models project a higher 3-month median.`,
    `20-day volume is ${(history.at(-1)!.volume / Math.max(1, indicators.averageDailyVolume20)).toFixed(2)}× its recent average.`,
  ];
  const indicatorSummary = [indicators.movingAverages, indicators.macd, indicators.rsi14, indicators.volume].map(i => `${i.signal}: ${i.explanation}`);
  const meta = TICKER_BY_SYMBOL[symbol];
  return {
    symbol,
    companyName: meta.name,
    currency,
    source: "Yahoo Finance historical chart",
    sourceType: "unofficial daily historical feed; may be delayed",
    latestDate: latest.date,
    latestClose: latest.adjustedClose,
    coverageStart: history[0].date,
    barsReturned: history.length,
    history,
    forecasts: modelForecasts,
    indicators,
    signal: { label, score, suggestedEntry: close, target: round2(directionalTarget), stopLoss: round2(signalStop), riskReward: Math.max(0, riskReward), expectedRangeLow: round2(rangeLow), expectedRangeHigh: round2(rangeHigh), modelAgreement: agreement, indicatorSummary, reasons, horizon: "3M" },
    validation: {
      method: "Chronological walk-forward: refit every 5 sessions on earlier candles, then compare the predicted next-5-session direction with the actual next-5-session direction. Random forest also reports its chronological hold-out accuracy.",
      window: "5 trading days",
      startDate: history[Math.max(0, history.length - 105)].date,
      endDate: latest.date,
      warning: "These are historical test results, not a guarantee of live model accuracy. Models have not been validated for trading profits.",
    },
  };
}

export async function getRealMarketAnalysis(rawSymbol: string): Promise<RealMarketAnalysis> {
  const symbol = validateSymbol(rawSymbol);
  const cached = analysisCache.get(symbol);
  if (cached && cached.expiresAt > Date.now()) return cached.analysis;
  const pending = analysisInFlight.get(symbol);
  if (pending) return pending;
  const request = (async () => {
    const data = await getRealHistory(symbol);
    const analysis = analyzeRealMarket(symbol, data);
    analysisCache.set(symbol, { analysis, expiresAt: Date.now() + HISTORY_TTL_MS });
    return analysis;
  })();
  analysisInFlight.set(symbol, request);
  try {
    return await request;
  } finally {
    analysisInFlight.delete(symbol);
  }
}


export type RealScreenerSummary = {
  symbol: string;
  companyName: string;
  latestDate: string;
  latestClose: number;
  signal: RealMarketAnalysis["signal"]["label"];
  score: number;
  modelAgreement: number;
  rsi14: number | null;
  trend: string;
  volumeRatio: number | null;
  threeMonthRange: { low: number; median: number; high: number };
};

/** A lighter on-demand scan; full Random Forest, ARIMA and GARCH comparisons load on a stock detail. */
export async function getRealMarketSummary(rawSymbol: string): Promise<RealScreenerSummary> {
  const symbol = validateSymbol(rawSymbol);
  const { history } = await getRealHistory(symbol);
  const latest = history.at(-1)!;
  const indicators = analyzeIndicators(history);
  const returns = getReturns(history);
  const seed = symbol.split("").reduce((s, c) => s * 31 + c.charCodeAt(0), 19) + latest.timestamp;
  const days = { "1D": 1, "1W": 5, "1M": 21, "3M": 63 } satisfies Record<ForecastHorizonKey, number>;
  const mc = monteCarloForecast(history, days, seed, 350);
  const lr = regressionForecast(history, days);
  const arimaFitResult = arimaFit(returns);
  const arimaForecasts = Object.fromEntries(FORECAST_HORIZONS.map(h => [h.key, arimaPoint(latest.adjustedClose, arimaFitResult, h.days)])) as Record<ForecastHorizonKey, ForecastPoint>;
  const trend = recentTrendForecast(history, days);
  const models = [mc, lr, { forecasts: arimaForecasts }, { forecasts: trend }] as unknown as ModelForecast[];
  const score = modelSignalScore(models, indicators, latest.adjustedClose);
  const label = score >= 48 ? "Strong Buy" : score >= 17 ? "Buy" : score <= -48 ? "Strong Sell" : score <= -17 ? "Sell" : "Hold";
  const directional = [mc.forecasts["3M"], lr.forecasts["3M"], arimaForecasts["3M"], trend["3M"]];
  return {
    symbol,
    companyName: TICKER_BY_SYMBOL[symbol].name,
    latestDate: latest.date,
    latestClose: latest.adjustedClose,
    signal: label,
    score,
    modelAgreement: Math.round(100 * directional.filter(item => item.median > latest.adjustedClose).length / directional.length),
    rsi14: indicators.rsi14.value,
    trend: indicators.trend,
    volumeRatio: indicators.volume.value,
    threeMonthRange: { low: mc.forecasts["3M"].low, median: mc.forecasts["3M"].median, high: mc.forecasts["3M"].high },
  };
}

export async function getPortfolioActualReturns(positions: Array<{ symbol: string; weight: number }>) {
  if (positions.length > 26 || positions.some(p => !TICKER_BY_SYMBOL[p.symbol] || !Number.isFinite(p.weight) || p.weight < 0)) throw new Error("Portfolio projection contains an unsupported stock or weight.");
  const cleaned = positions.filter(p => p.weight > 0);
  const totalWeight = cleaned.reduce((s, p) => s + p.weight, 0);
  if (totalWeight > 1.0001) throw new Error("Portfolio weights cannot add up to more than 100%.");
  if (!cleaned.length) return { latestDate: new Date().toISOString().slice(0, 10), returns: [], dataSymbols: [], investedWeight: 0 };
  const histories = await Promise.all(cleaned.map(async position => ({ position, ...(await getRealHistory(position.symbol)) })));
  const maps = histories.map(({ position, history }) => ({ position, map: new Map(history.slice(-1261).map((b, i, arr) => [b.date, i > 0 ? Math.log(b.adjustedClose / arr[i - 1].adjustedClose) : 0])) }));
  const commonDates = [...maps[0].map.keys()].filter(date => maps.every(m => m.map.has(date))).sort();
  const returns: number[] = [];
  for (let i = 1; i < commonDates.length; i++) {
    const date = commonDates[i];
    returns.push(maps.reduce((sum, m) => sum + m.position.weight * (m.map.get(date) ?? 0), 0));
  }
  if (returns.length < 60) throw new Error("There is not enough overlapping real history for this portfolio. Try again later.");
  return { latestDate: commonDates.at(-1)!, returns, dataSymbols: cleaned.map(p => p.symbol), investedWeight: totalWeight };
}

export function makePortfolioProjection(input: { returns: number[]; startValue: number; horizonDays: number; seed: number; monthlyContribution?: number }) {
  const { returns, startValue, horizonDays } = input;
  const monthlyContribution = Math.max(0, Math.min(100_000, input.monthlyContribution ?? 0));
  const data = returns.slice(-252);
  const dailyMean = average(data), dailyVol = standardDeviation(data);
  const random = seededRandom(input.seed);
  const output: Array<{ day: number; p5: number; p25: number; p50: number; p75: number; p95: number }> = [];
  const stepEvery = Math.max(1, Math.round(horizonDays / 84));
  const samples = Array.from({ length: horizonDays + 1 }, () => [] as number[]);
  const runCount = 2000;
  for (let run = 0; run < runCount; run++) {
    let value = startValue;
    samples[0].push(value);
    for (let day = 1; day <= horizonDays; day++) {
      const z1 = Math.max(random(), 1e-9), z2 = random();
      const z = Math.sqrt(-2 * Math.log(z1)) * Math.cos(2 * Math.PI * z2);
      value = Math.max(0, value * Math.exp(dailyMean + dailyVol * z));
      if (monthlyContribution > 0 && day % 21 === 0) value += monthlyContribution;
      if (day % stepEvery === 0 || day === horizonDays) samples[day].push(value);
    }
  }
  const days = Array.from({ length: Math.floor(horizonDays / stepEvery) + 1 }, (_, i) => Math.min(i * stepEvery, horizonDays));
  if (days.at(-1) !== horizonDays) days.push(horizonDays);
  for (const day of [...new Set(days)]) {
    const values = samples[day].sort((a, b) => a - b);
    if (!values.length) continue;
    const q = (ratio: number) => values[Math.min(values.length - 1, Math.floor(ratio * (values.length - 1)))];
    output.push({ day, p5: q(0.05), p25: q(0.25), p50: q(0.5), p75: q(0.75), p95: q(0.95) });
  }
  const terminalValues = samples[horizonDays].sort((a, b) => a - b);
  const totalContributed = startValue + Math.floor(horizonDays / 21) * monthlyContribution;
  const terminalAt = (ratio: number) => terminalValues[Math.min(terminalValues.length - 1, Math.floor(ratio * (terminalValues.length - 1)))];
  const probProfit = terminalValues.filter(value => value > totalContributed).length / Math.max(1, terminalValues.length);
  return {
    bands: output,
    runCount,
    startValue,
    horizonDays,
    monthlyContribution,
    totalContributed,
    probProfit,
    terminal: { p5: terminalAt(0.05), p25: terminalAt(0.25), p50: terminalAt(0.5), p75: terminalAt(0.75), p95: terminalAt(0.95), mean: average(terminalValues) },
    annualizedHistoricalVolatility: dailyVol * Math.sqrt(YEAR_DAYS),
    annualizedHistoricalReturn: dailyMean * YEAR_DAYS,
  };
}

export async function getStockActualProjection(symbol: string, startValue: number, horizonDays: number, monthlyContribution: number) {
  const { history } = await getRealHistory(symbol);
  const returns = getReturns(history);
  const seed = symbol.split("").reduce((s, c) => s * 31 + c.charCodeAt(0), 27) + Math.round(startValue * 100) + horizonDays + Math.round(monthlyContribution * 100);
  return {
    ...makePortfolioProjection({ returns, startValue, horizonDays, monthlyContribution, seed }),
    latestHistoryDate: history.at(-1)!.date,
    dataSymbols: [symbol],
    source: "Yahoo Finance historical chart",
    sourceType: "Unofficial daily historical feed; may be delayed.",
    method: "2,000 Monte Carlo paths sampled from this ticker’s last year of actual daily returns. Monthly additions are invested in the same stock every 21 sessions.",
  };
}
