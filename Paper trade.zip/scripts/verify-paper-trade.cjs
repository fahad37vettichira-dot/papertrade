const { chromium, expect } = require('@playwright/test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:3000';

(async () => {
  await fs.mkdir('artifacts', { recursive: true });
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 1440, height: 1050 }, reducedMotion: 'reduce' });
  const page = await context.newPage();
  page.setDefaultTimeout(20000);
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  const state = async () => {
    const r = await context.request.get(`${base}/api/state`);
    assert.equal(r.status(), 200, 'State API must succeed');
    return r.json();
  };
  const noOverflow = async p => assert(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `Page must fit viewport: ${p.url()}`);
  try {
    await page.goto(base, { waitUntil: 'networkidle' });
    await expect(page.getByRole('heading', { name: 'Your portfolio, at a glance.' })).toBeVisible();
    await expect(page.getByText('Cash to invest', { exact: true })).toBeVisible();
    await noOverflow(page);
    await page.screenshot({ path: 'artifacts/overview-desktop.png', fullPage: true });
    const initial = await state();
    if (initial.market.speed) await context.request.post(`${base}/api/settings`, { data: { speed: 0 } });

    const realResponse = await context.request.get(`${base}/api/market-data/AAPL`);
    assert.equal(realResponse.status(), 200, 'Actual daily history and real-data model comparison must be available');
    const real = await realResponse.json();
    assert.equal(real.symbol, 'AAPL');
    assert.equal(real.source, 'Yahoo Finance historical chart');
    assert(real.barsReturned >= 70 && real.history.length >= 70, 'Actual historical chart has sufficient daily bars');
    assert(real.latestClose > 0 && real.latestDate, 'Actual data has a real close and provider date');
    assert.deepEqual(real.forecasts.map(m => m.id), ['monte-carlo', 'linear-regression', 'random-forest', 'arima', 'time-series', 'garch']);
    for (const model of real.forecasts) for (const horizon of ['1D', '1W', '1M', '3M']) {
      const p = model.forecasts[horizon];
      assert(Number.isFinite(p.low) && Number.isFinite(p.median) && Number.isFinite(p.high) && p.low <= p.median && p.median <= p.high, `${model.name} ${horizon} has a valid forecast range`);
    }
    assert(real.signal.riskReward >= 0 && real.signal.stopLoss > 0 && real.signal.suggestedEntry > 0);
    assert(real.predictionHistory.length >= 24, 'The real forecast history is persisted in PostgreSQL');
    const badSymbol = await context.request.get(`${base}/api/market-data/FAKE`);
    assert.equal(badSymbol.status(), 404, 'Unsupported ticker has no invented data');

    const singleForecastResponse = await context.request.post(`${base}/api/market-data/AAPL/projection`, { data: { startValue: 5000, horizonDays: 63, monthlyContribution: 100 } });
    const singleForecast = await singleForecastResponse.json();
    assert.equal(singleForecastResponse.status(), 200);
    assert.equal(singleForecast.runCount, 2000);
    assert.equal(singleForecast.totalContributed, 5300);
    assert(singleForecast.bands.length > 2 && Number.isFinite(singleForecast.terminal.p50));

    const candidate = initial.tickers.find(t => !t.shares && t.symbol.length >= 3 && t.price < 10000);
    assert(candidate, 'Need one unowned stock for a reversible practice trade');
    const symbol = candidate.symbol;

    await page.getByRole('link', { name: 'Explore stocks', exact: true }).first().click();
    await expect(page.getByLabel('Search stocks')).toBeVisible();
    await page.getByLabel('Search stocks').fill(symbol);
    const initialWatchLabel = `${candidate.watched ? 'Remove' : 'Add'} ${symbol} ${candidate.watched ? 'from' : 'to'} watchlist`;
    const nextWatchLabel = `${candidate.watched ? 'Add' : 'Remove'} ${symbol} ${candidate.watched ? 'to' : 'from'} watchlist`;
    await page.getByRole('button', { name: initialWatchLabel, exact: true }).click();
    await expect(page.getByRole('button', { name: nextWatchLabel, exact: true })).toBeVisible();
    await page.getByRole('button', { name: nextWatchLabel, exact: true }).click();
    await expect(page.getByRole('button', { name: initialWatchLabel, exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Scan market signals', exact: true }).click();
    await expect(page.getByText(/\d+ actual-data signals/)).toBeVisible({ timeout: 90000 });
    await expect(page.getByLabel('Filter actual signals')).toBeVisible();
    await noOverflow(page);
    await page.getByRole('button', { name: 'Buy', exact: true }).click();
    let dialog = page.getByRole('dialog');
    await dialog.locator(`#trade-amount-${symbol}`).fill('100');
    await dialog.getByRole('button', { name: 'Review order', exact: true }).click();
    await expect(dialog.getByRole('button', { name: 'Confirm virtual purchase', exact: true })).toBeVisible();
    await dialog.getByRole('button', { name: 'Confirm virtual purchase', exact: true }).click();
    await expect(dialog.getByRole('heading', { name: 'Nicely done!' })).toBeVisible();
    const purchased = await state();
    const qty = purchased.holdings.find(h => h.symbol === symbol)?.shares;
    assert(qty > 0, 'Purchase must create a holding in PostgreSQL');
    await dialog.getByRole('button', { name: 'Done', exact: true }).click();

    await page.goto(`${base}/portfolio`, { waitUntil: 'networkidle' });
    await expect(page.getByRole('heading', { name: 'What you own', exact: true })).toBeVisible();
    await page.getByRole('row').filter({ hasText: symbol }).getByRole('button', { name: 'Sell', exact: true }).click();
    dialog = page.getByRole('dialog');
    await dialog.locator(`#trade-amount-${symbol}`).fill(String(qty));
    await dialog.getByRole('button', { name: 'Review order', exact: true }).click();
    await dialog.getByRole('button', { name: 'Confirm virtual sale', exact: true }).click();
    await expect(dialog.getByRole('heading', { name: 'Nicely done!' })).toBeVisible();
    await dialog.getByRole('button', { name: 'Done', exact: true }).click();
    const sold = await state();
    assert(!sold.holdings.some(h => h.symbol === symbol), 'Sell must remove the new position');
    assert(Math.abs(sold.account.cash - initial.account.cash) < .02, 'Buy/sell at unchanged price should return cash');

    await page.getByRole('button', { name: 'Add funds', exact: true }).click();
    dialog = page.getByRole('dialog');
    await dialog.locator('#fund-amount').fill('100');
    await dialog.getByRole('button', { name: 'Add $100.00 in virtual cash', exact: true }).click();
    await expect(dialog).toHaveCount(0);
    assert.equal((await state()).account.cash, sold.account.cash + 100);
    await page.goto(`${base}/activity`, { waitUntil: 'networkidle' });
    await page.getByRole('button', { name: 'Withdraw', exact: true }).click();
    dialog = page.getByRole('dialog');
    await dialog.locator('#fund-amount').fill('100');
    await dialog.getByRole('button', { name: 'Withdraw $100.00', exact: true }).click();
    await expect(dialog).toHaveCount(0);
    const withdrawn = await state();
    assert.equal(withdrawn.account.cash, sold.account.cash);
    assert.equal(withdrawn.account.netDeposits, sold.account.netDeposits);
    assert.equal(withdrawn.account.withdrawals, sold.account.withdrawals + 100);
    assert.equal(withdrawn.account.totalDeposits, sold.account.totalDeposits + 100);
    const csv = await context.request.get(`${base}/api/transactions/export`);
    assert.equal(csv.status(), 200);
    assert((await csv.text()).includes('"Cash flow"'));

    const invalidTime = await context.request.post(`${base}/api/tick`, { data: { days: 'not-a-number' } });
    assert.equal(invalidTime.status(), 400);
    const tooLong = await context.request.post(`${base}/api/tick`, { data: { days: 1261 } });
    assert.equal(tooLong.status(), 400);
    const badTrade = await context.request.post(`${base}/api/trade`, { data: { symbol, side: 'buy', qty: 999999999, orderType: 'market' } });
    assert.equal(badTrade.status(), 400);

    await page.goto(base, { waitUntil: 'networkidle' });
    await page.locator('#time-card').selectOption('1260');
    await page.getByRole('button', { name: 'Skip ahead', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Yes, skip 5 years', exact: true })).toBeVisible();
    assert.equal((await state()).market.day, initial.market.day, 'Five-year jump must wait for confirmation');
    await page.getByRole('button', { name: 'Cancel', exact: true }).click();
    await page.locator('#time-card').selectOption('1');
    const tick = page.waitForResponse(r => r.url().endsWith('/api/tick') && r.request().method() === 'POST');
    await page.getByRole('button', { name: 'Skip ahead', exact: true }).click();
    assert.equal((await tick).status(), 200);
    assert.equal((await state()).market.day, initial.market.day + 1);

    await page.goto(`${base}/markets/AAPL`, { waitUntil: 'networkidle' });
    await expect(page.getByRole('heading', { name: 'Real market history & model outlook' })).toBeVisible();
    await page.locator('summary').filter({ hasText: 'Compare prediction methods' }).click();
    await expect(page.getByRole('table').getByText('Random forest', { exact: true })).toBeVisible();
    await page.locator('summary').filter({ hasText: 'Previous model forecasts vs. actual closes' }).click();
    await expect(page.getByText('Forecast tracking starts today.')).toBeVisible();

    await page.goto(base, { waitUntil: 'networkidle' });
    await page.getByRole('button', { name: 'Future growth' }).click();
    await page.getByRole('button', { name: 'Build my future growth graph' }).click();
    await expect(page.getByText('Middle estimate', { exact: true })).toBeVisible({ timeout: 45000 });
    assert(!(await page.locator('main').innerText()).includes('NaN'));
    await page.getByRole('button', { name: '5 years', exact: true }).click();
    await page.getByRole('button', { name: 'Build my future growth graph' }).click();
    await expect(page.getByText('Middle estimate', { exact: true })).toBeVisible({ timeout: 45000 });

    await page.goto(`${base}/simulations`, { waitUntil: 'networkidle' });
    await expect(page.locator('#forecast-horizon')).toBeVisible();
    await page.locator('#forecast-horizon').selectOption('1260');
    await page.locator('#forecast-amount').fill('5000');
    await page.getByRole('button', { name: 'Show possible futures' }).click();
    await expect(page.getByText('Typical outcome', { exact: true })).toBeVisible({ timeout: 30000 });
    assert(!(await page.locator('main').innerText()).includes('NaN'));
    await page.screenshot({ path: 'artifacts/simulator-desktop.png', fullPage: true });
    await page.locator('summary').filter({ hasText: 'More ways to experiment' }).click();
    await expect(page.getByRole('button', { name: 'Compare strategies' })).toBeVisible();
    await page.getByRole('button', { name: 'Compare strategies' }).click();
    await expect(page.getByText('Comparison for AAPL')).toBeVisible();

    for (const path of ['/markets/AAPL', '/news', '/activity', '/portfolio']) {
      await page.goto(`${base}${path}`, { waitUntil: 'networkidle' });
      await expect(page.locator('main h1')).toBeVisible();
      await noOverflow(page);
    }

    const mobileContext = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, reducedMotion: 'reduce' });
    const mobile = await mobileContext.newPage();
    mobile.on('pageerror', e => errors.push(e.message));
    for (const path of ['/', '/markets', '/markets/AAPL', '/portfolio', '/activity', '/simulations', '/news']) {
      await mobile.goto(`${base}${path}`, { waitUntil: 'networkidle' });
      await expect(mobile.locator('main h1')).toBeVisible();
      await noOverflow(mobile);
      if (path === '/') await mobile.screenshot({ path: 'artifacts/overview-mobile.png', fullPage: true });
    }
    await mobile.goto(`${base}/markets`, { waitUntil: 'networkidle' });
    await mobile.getByLabel('Search stocks').fill(symbol);
    const mobileBuy = mobile.getByRole('button', { name: 'Buy', exact: true });
    await expect(mobileBuy).toBeInViewport();
    await mobileBuy.click();
    await mobile.getByRole('dialog').locator(`#trade-amount-${symbol}`).fill('100');
    await mobile.getByRole('dialog').getByRole('button', { name: 'Review order', exact: true }).click();
    await expect(mobile.getByRole('dialog').getByRole('button', { name: 'Confirm virtual purchase', exact: true })).toBeVisible();
    await mobile.getByRole('button', { name: 'Close dialog' }).click();
    await mobile.goto(`${base}/markets/AAPL`, { waitUntil: 'networkidle' });
    await expect(mobile.getByRole('button', { name: 'Buy / sell', exact: true })).toBeInViewport();
    await mobile.getByRole('button', { name: 'Add funds', exact: true }).click();
    await expect(mobile.getByRole('dialog')).toBeVisible();
    await noOverflow(mobile);
    await mobile.getByRole('button', { name: 'Close dialog' }).click();
    await mobile.getByRole('button', { name: 'More', exact: true }).click();
    await expect(mobile.getByRole('dialog')).toBeVisible();
    await mobile.getByRole('dialog').getByRole('link', { name: 'Market news', exact: true }).click();
    await expect(mobile.getByRole('dialog')).toHaveCount(0);
    await expect(mobile.locator('main h1')).toHaveText('A little context for your next move.');
    assert.deepEqual(errors, [], 'No browser runtime errors');
    assert.equal((await context.request.get(`${base}/api/health`)).status(), 200);
    console.log('PASS: actual 10-year history, six actual-data models, five-level signal, stored forecast log, 2k-path single-stock and portfolio forecasts, actual-data stock screener, verified DCA backtest, real buy/review/sell, cash, watchlist, CSV, time warp, and desktop/mobile routes.');
    console.log('Screenshots saved in artifacts/. Existing account and holdings were not reset.');
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
